using GateAuto.Core.Models;
using Microsoft.Playwright;

namespace GateAuto.Automation.Tests;

/// <summary>
/// 详情读取服务的测试：真实 Chromium + 内联 HTML，覆盖关务物流与云富通两种详情页结构，
/// 以及纯映射逻辑（厂商代码 / 包装件数 / 申请编号 / 来源单号正则提取 / 件数≠数量）。
/// </summary>
public sealed class OrderDetailReaderTests : IAsyncLifetime
{
    private static readonly string? BrowserChannel = DetectChannel();

    private IPlaywright? _playwright;
    private IBrowser? _browser;
    private IPage? _page;

    public async Task InitializeAsync()
    {
        if (BrowserChannel is null)
        {
            return;
        }

        _playwright = await Playwright.CreateAsync();
        _browser = await _playwright.Chromium.LaunchAsync(new()
        {
            Channel = BrowserChannel,
            Headless = true,
        });
        _page = await _browser.NewPageAsync();
    }

    public async Task DisposeAsync()
    {
        if (_browser is not null)
        {
            await _browser.DisposeAsync();
        }

        _playwright?.Dispose();
    }

    [Fact]
    public async Task 關務詳情_讀出廠商代碼包裝件數申請編號與來源單號()
    {
        if (_page is null)
        {
            return;
        }

        await _page.SetContentAsync(CustomsDetailHtml());

        var info = await OrderDetailReader.ReadAsync(_page, OrderPlatform.CustomsLogistics, "JCL20241118001");

        Assert.Equal("JCL20241118001", info.ApplyNo);
        Assert.Equal("TGFC016005", info.VendorCode);

        // 件数取「包装件数」，绝不能取「数量」（数量是 93.0 PCS/SET）。
        Assert.Equal(5, info.PackageCount);

        Assert.Equal(12.5m, info.GrossWeightKg);
        Assert.Equal(10.0m, info.NetWeightKg);
        Assert.Equal("22-纸制或纤维板制装盒/箱", info.PackingMethod);
        Assert.Equal("富晋精密工业（晋城）有限公司", info.Consignee);

        Assert.Equal(2, info.SourceNos.Count);
        Assert.Contains("5CS-QB0081", info.SourceNos);
        Assert.Contains("UCJ-123456", info.SourceNos);

        // 装货地址从备注「存放地点」正则兜底提取。
        Assert.Equal("C1库房", info.LoadingAddress);
    }

    [Fact]
    public async Task 雲富通詳情_讀出單號廠商代碼包裝件數與來源單號()
    {
        if (_page is null)
        {
            return;
        }

        await _page.SetContentAsync(YunFuTongDetailHtml());

        var info = await OrderDetailReader.ReadAsync(_page, OrderPlatform.YunFuTong, "XJ20241118001");

        Assert.Equal("XJ20241118001", info.ApplyNo);
        Assert.Equal("V00123456", info.VendorCode);
        Assert.Equal(3, info.PackageCount);
        Assert.Equal(2, info.SourceNos.Count);
        Assert.Contains("5CS-QB0081", info.SourceNos);
        Assert.Contains("UCN-888888", info.SourceNos);
    }

    [Fact]
    public void 映射_件數取包裝件數而非數量()
    {
        var raw = new OrderDetailResult(
            "http://example",
            new Dictionary<string, string>
            {
                ["applyNo"] = "JCL0001",
                ["vendorCode"] = "TGFC016005",
                ["packageCount"] = "5",
                ["grossWeightKg"] = "12.5 kg",
                ["netWeightKg"] = "10.0 kg",
                ["packingMethod"] = "22-盒",
            },
            new Dictionary<string, IReadOnlyList<string>>
            {
                ["sourceNos"] = ["5CS-QB0081", "UCJ-123456"],
                ["loadingAddressText"] = ["C1库房"],
            });

        var info = OrderDetailReader.Map(raw, OrderPlatform.CustomsLogistics, "JCL0001");

        Assert.Equal("JCL0001", info.ApplyNo);
        Assert.Equal("TGFC016005", info.VendorCode);
        Assert.Equal(5, info.PackageCount);
        Assert.Equal(12.5m, info.GrossWeightKg);
        Assert.Equal(10.0m, info.NetWeightKg);
        Assert.Equal(2, info.SourceNos.Count);
        Assert.Contains("5CS-QB0081", info.SourceNos);
        Assert.Contains("UCJ-123456", info.SourceNos);
        Assert.Equal("C1库房", info.LoadingAddress);
    }

    private static string CustomsDetailHtml() => """
        <html><body>
        <table>
          <tr><td>需求单号</td><td>JCL20241118001</td></tr>
          <tr><td>厂商代码</td><td>TGFC016005</td></tr>
          <tr><td>收货方</td><td>富晋精密工业（晋城）有限公司</td></tr>
          <tr><td>包装方式</td><td>22-纸制或纤维板制装盒/箱</td></tr>
          <tr><td>包装件数</td><td>5</td></tr>
          <tr><td>数量</td><td>93.0</td></tr>
          <tr><td>毛重</td><td>12.5 kg</td></tr>
          <tr><td>净重</td><td>10.0 kg</td></tr>
          <tr><td>备注</td><td>来源单号 5CS-QB0081, UCJ-123456；存放地点 C1库房</td></tr>
        </table>
        </body></html>
        """;

    private static string YunFuTongDetailHtml() => """
        <html><body>
        <table>
          <tr><td>单号</td><td>XJ20241118001</td></tr>
          <tr><td>厂商代码</td><td>V00123456</td></tr>
          <tr><td>包装件数</td><td>3</td></tr>
          <tr><td>数量</td><td>20.0</td></tr>
          <tr><td>备注</td><td>5CS-QB0081, UCN-888888</td></tr>
        </table>
        </body></html>
        """;

    private static string? DetectChannel()
    {
        (string Path, string Channel)[] candidates =
        [
            (@"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe", "msedge"),
            (@"C:\Program Files\Microsoft\Edge\Application\msedge.exe", "msedge"),
            (@"C:\Program Files\Google\Chrome\Application\chrome.exe", "chrome"),
            (@"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe", "chrome"),
        ];

        foreach (var (path, channel) in candidates)
        {
            if (File.Exists(path))
            {
                return channel;
            }
        }

        return null;
    }
}

using GateAuto.Automation.Workflows;
using GateAuto.Core.Models;
using GateAuto.Core.Rules;
using GateAuto.Data;
using Microsoft.Playwright;

namespace GateAuto.Automation.Tests;

/// <summary>
/// 建单与改车牌的端到端测试：真实 Chromium + 本地 fixture，覆盖
/// 新增 → 填表 → 有來源添加 → 保存（含確認框）→ 取 LQE → 入库 → 待派车。
/// </summary>
public sealed class CreateOrderAutomationTests : IAsyncLifetime
{
    private static readonly string? BrowserChannel = DetectChannel();

    private IPlaywright? _playwright;
    private IBrowser? _browser;
    private IPage? _page;
    private string? _databasePath;

    public async Task InitializeAsync()
    {
        if (BrowserChannel is null)
        {
            return;
        }

        _playwright = await Playwright.CreateAsync();
        _browser = await _playwright.Chromium.LaunchAsync(new()
        {
            Channel = BrowserChannel,
            Headless = true,
        });
        _page = await _browser.NewPageAsync();
    }

    public async Task DisposeAsync()
    {
        if (_browser is not null)
        {
            await _browser.DisposeAsync();
        }

        _playwright?.Dispose();

        // SQLite 连接池会一直占用文件句柄，清理后再删除临时库。
        Microsoft.Data.Sqlite.SqliteConnection.ClearAllPools();

        if (_databasePath is not null && File.Exists(_databasePath))
        {
            File.Delete(_databasePath);
        }
    }

    [Fact]
    public async Task 完整建單流程_填寫固定與動態欄位並取得新的LQE()
    {
        if (_page is null)
        {
            return;
        }

        var page = _page;
        var engine = new RuleEngine(RuleTableLoader.Default);
        var evaluation = engine.Evaluate(CreateOrder());

        Assert.True(evaluation.IsValid, string.Join("；", evaluation.Errors));

        var service = new EGateService(page, FastSelectors(), FixtureUri());
        var result = await service.CreateShipmentAsync(evaluation);

        Assert.Equal("LQE-261132999", result.LqeNo);
        Assert.Equal(2, result.SourceRowCount);

        Assert.Equal("貨物", await page.InputValueAsync("#decl-type"));
        Assert.Equal("公路運輸", await page.InputValueAsync("#transport-mode"));
        Assert.Equal("087-不返廠貨樣", await page.InputValueAsync("#exit-type"));
        Assert.Equal("非保稅", await page.InputValueAsync("#goods-nature"));
        Assert.Equal("N", await page.InputValueAsync("#vendor-code"));
        Assert.Equal("集團國內", await page.InputValueAsync("#vendor-type"));
        Assert.Equal("晉城園區-B區", await page.InputValueAsync("#unloading-zone"));
        Assert.Equal("C1", await page.InputValueAsync("#loading-address"));
        Assert.Equal("3", await page.InputValueAsync("#pkg-count"));
        Assert.Equal("11.5", await page.InputValueAsync("#gross-weight"));
        Assert.Equal("8", await page.InputValueAsync("#net-weight"));
        Assert.Equal("5CS-QB0081,UCJ-123456", await page.InputValueAsync("#source-no"));
        Assert.True(await page.Locator("input[value='外销']").IsCheckedAsync());
    }

    [Fact]
    public async Task 欄位標籤不存在時給出可調整配置的錯誤()
    {
        if (_page is null)
        {
            return;
        }

        var selectors = FastSelectors();
        selectors.FieldLabels[EGateField.VendorCode] = "廠商代碼X";
        selectors.FieldLabelAliases[EGateField.VendorCode] = [];

        var engine = new RuleEngine(RuleTableLoader.Default);
        var evaluation = engine.Evaluate(CreateOrder());

        var service = new EGateService(_page, selectors, FixtureUri());

        var ex = await Assert.ThrowsAsync<EGateAutomationException>(
            () => service.CreateShipmentAsync(evaluation));

        Assert.Contains("廠商代碼X", ex.Message);
        Assert.Contains("FieldLabels", ex.Message);
    }

    [Fact]
    public async Task 建單工作流_成功後寫入已建單狀態與待派車清單()
    {
        if (_page is null)
        {
            return;
        }

        var database = CreateDatabase();
        var orders = new OrderRepository(database);
        var plateTasks = new PlateTaskRepository(database);
        var engine = new RuleEngine(RuleTableLoader.Default);
        var gate = new EGateService(_page, FastSelectors(), FixtureUri());
        var workflow = new OrderCreationWorkflow(engine, orders, plateTasks, gate);

        var order = CreateOrder();
        var outcome = await workflow.CreateAsync(order);

        Assert.True(outcome.Success, outcome.Error);
        Assert.Equal("LQE-261132999", outcome.LqeNo);

        var savedOrder = orders.GetByApplyNo(order.Platform, order.ApplyNo);
        Assert.NotNull(savedOrder);
        Assert.Equal(OrderStatus.Created, savedOrder!.Status);
        Assert.Equal("LQE-261132999", savedOrder.LqeNo);

        var tasks = plateTasks.ListAll();
        var task = Assert.Single(tasks);
        Assert.Equal("LQE-261132999", task.LqeNo);
        Assert.Equal(PlateTaskStatus.Pending, task.Status);
        Assert.Equal(3, task.PackageCount);
    }

    [Fact]
    public async Task 建單工作流_規則不通過時不開瀏覽器且不寫入資料庫()
    {
        if (_page is null)
        {
            return;
        }

        var database = CreateDatabase();
        var orders = new OrderRepository(database);
        var plateTasks = new PlateTaskRepository(database);
        var engine = new RuleEngine(RuleTableLoader.Default);

        var gate = new EGateService(_page, FastSelectors(), FixtureUri());

        var workflow = new OrderCreationWorkflow(engine, orders, plateTasks, gate);

        var order = new OrderInfo
        {
            ApplyNo = "T-INVALID",
            SourceNos = [],
            DeliveryAddress = "晉城園區B區",
            PackageCount = 1,
            GrossWeightKg = 1,
            PackingMethod = string.Empty,
            VendorCode = "TGB005",
            LoadingAddress = "C1",
        };

        var outcome = await workflow.CreateAsync(order);

        Assert.False(outcome.Success);
        Assert.Contains("來源單號", outcome.Error);
        Assert.False(orders.Exists(order.Platform, "T-INVALID"));
    }

    [Fact]
    public async Task 改車牌工作流_成功後更新資料庫狀態()
    {
        if (_page is null)
        {
            return;
        }

        var database = CreateDatabase();
        var plateTasks = new PlateTaskRepository(database);

        plateTasks.Add(new PlateTask
        {
            LqeNo = "LQE-261132362",
            Destination = "深圳",
            PackageCount = 1,
            WeightKg = 11,
            Status = PlateTaskStatus.Pending,
        });

        var gate = new EGateService(_page, FastSelectors(), FixtureUri());
        var workflow = new PlateUpdateWorkflow(plateTasks, gate);

        var outcome = await workflow.UpdateAsync("LQE-261132362", "晉EC6106");

        Assert.True(outcome.Success, outcome.Error);

        var task = plateTasks.GetByLqeNo("LQE-261132362");
        Assert.NotNull(task);
        Assert.Equal("晉EC6106", task!.PlateNo);
        Assert.Equal(PlateTaskStatus.Updated, task.Status);
    }

    private GateAutoDatabase CreateDatabase()
    {
        _databasePath = Path.Combine(Path.GetTempPath(), $"gateauto-{Guid.NewGuid():N}.db");
        var database = new GateAutoDatabase(_databasePath);
        database.Initialize();
        return database;
    }

    private static EGateSelectors FastSelectors() => new()
    {
        Timeout = TimeSpan.FromSeconds(5),
        QueryTimeout = TimeSpan.FromSeconds(5),
        LqeTimeout = TimeSpan.FromSeconds(5),
        FormLoadTimeout = TimeSpan.FromSeconds(5),
    };

    private static OrderInfo CreateOrder() => new()
    {
        ApplyNo = "APP-20261117-001",
        SourceNos = SourceNoParser.Parse("5CS-QB0081,UCJ-123456"),
        DeliveryAddress = "晉城園區-B區",
        PackageCount = 3,
        GrossWeightKg = 11.5m,
        NetWeightKg = 8m,
        PackingMethod = "22-紙製或纖維板製裝盒/箱",
        VendorCode = "TGB005",
        LoadingAddress = "C1",
        Consignee = "深圳富士康",
    };

    private static string FixtureUri(string query = "")
        => new Uri(Path.Combine(AppContext.BaseDirectory, "fixtures", "gate.html")).AbsoluteUri + query;

    private static string? DetectChannel()
    {
        (string Path, string Channel)[] candidates =
        [
            (@"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe", "msedge"),
            (@"C:\Program Files\Microsoft\Edge\Application\msedge.exe", "msedge"),
            (@"C:\Program Files\Google\Chrome\Application\chrome.exe", "chrome"),
            (@"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe", "chrome"),
        ];

        foreach (var (path, channel) in candidates)
        {
            if (File.Exists(path))
            {
                return channel;
            }
        }

        return null;
    }
}

using Microsoft.Playwright;

namespace GateAuto.Automation.Tests;

/// <summary>
/// 用真实的 Chromium（本机已安装的 Edge / Chrome）跑两个弹窗的完整流程。
/// 页面为本地 fixture，结构与真实系统一致：弹窗 + 输入框 + 查询后出现明细行。
/// </summary>
public sealed class DialogAutomationTests : IAsyncLifetime
{
    private static readonly string? BrowserChannel = DetectChannel();

    private static readonly EGateSelectors FastSelectors = new()
    {
        Timeout = TimeSpan.FromSeconds(5),
        QueryTimeout = TimeSpan.FromSeconds(5),
    };

    private IPlaywright? _playwright;
    private IBrowser? _browser;
    private IPage? _page;

    public async Task InitializeAsync()
    {
        if (BrowserChannel is null)
        {
            return;
        }

        _playwright = await Playwright.CreateAsync();
        _browser = await _playwright.Chromium.LaunchAsync(new()
        {
            Channel = BrowserChannel,
            Headless = true,
        });
        _page = await _browser.NewPageAsync();
    }

    public async Task DisposeAsync()
    {
        if (_browser is not null)
        {
            await _browser.DisposeAsync();
        }

        _playwright?.Dispose();
    }

    [Fact]
    public async Task 有來源添加_填單號查詢後出現明細並確定關閉()
    {
        if (_page is null)
        {
            return;
        }

        var page = _page;
        await page.GotoAsync(FixtureUri());

        var dialog = await SourceAddDialog.OpenAsync(page, FastSelectors);
        var rowCount = await dialog.SubmitAsync(["5CS-QB0081", "UCJ-123456"]);

        Assert.Equal(2, rowCount);
        Assert.False(await page.Locator("#dlg-source").IsVisibleAsync());
        Assert.True(await page.Locator("input[value='外销']").IsCheckedAsync());
    }

    [Fact]
    public async Task 多筆來源單號以英文逗號拼接後填入()
    {
        if (_page is null)
        {
            return;
        }

        var page = _page;
        await page.GotoAsync(FixtureUri());

        var dialog = await SourceAddDialog.OpenAsync(page, FastSelectors);
        var filled = await dialog.FillSourceNosAsync(["5CS-QB0081", "UCN-888888"]);

        Assert.Equal("5CS-QB0081,UCN-888888", filled);
        Assert.Equal(filled, await page.InputValueAsync("#source-no"));
    }

    [Fact]
    public async Task 查詢無明細時報錯且彈窗保持開啟()
    {
        if (_page is null)
        {
            return;
        }

        var page = _page;
        await page.GotoAsync(FixtureUri("?empty=1"));

        var selectors = new EGateSelectors
        {
            Timeout = TimeSpan.FromSeconds(5),
            QueryTimeout = TimeSpan.FromSeconds(1),
        };

        var dialog = await SourceAddDialog.OpenAsync(page, selectors);
        await dialog.FillSourceNosAsync(["ABC-0001"]);

        var ex = await Assert.ThrowsAsync<EGateAutomationException>(() => dialog.QueryAsync());

        Assert.Contains("明細", ex.Message);
        Assert.True(await page.Locator("#dlg-source").IsVisibleAsync());
    }

    [Fact]
    public async Task 修改車牌_按放行單號定位後填入並確定()
    {
        if (_page is null)
        {
            return;
        }

        var page = _page;
        await page.GotoAsync(FixtureUri());

        var dialog = await PlateEditDialog.OpenFromRowAsync(page, "LQE-261132362", FastSelectors);
        await dialog.UpdatePlateAsync("晉EC6106");

        Assert.False(await page.Locator("#dlg-plate").IsVisibleAsync());
        Assert.Equal("晉EC6106", await page.Locator("#plate-no").GetAttributeAsync("data-saved"));
    }

    [Fact]
    public async Task 車牌為空時拒絕提交()
    {
        if (_page is null)
        {
            return;
        }

        var page = _page;
        await page.GotoAsync(FixtureUri());
        await page.Locator("#shipments").GetByText("修改車牌").ClickAsync();

        var dialog = await PlateEditDialog.AttachAsync(page, FastSelectors);

        await Assert.ThrowsAsync<EGateAutomationException>(() => dialog.UpdatePlateAsync("   "));
    }

    [Fact]
    public async Task 找不到放行單號時給出明確錯誤()
    {
        if (_page is null)
        {
            return;
        }

        var page = _page;
        await page.GotoAsync(FixtureUri());

        var ex = await Assert.ThrowsAsync<EGateAutomationException>(
            () => PlateEditDialog.OpenFromRowAsync(page, "LQE-NOT-EXIST", FastSelectors));

        Assert.Contains("LQE-NOT-EXIST", ex.Message);
    }

    [Fact]
    public async Task 簡體界面用同一套流程可完成兩個彈窗()
    {
        if (_page is null)
        {
            return;
        }

        var page = _page;
        await page.GotoAsync(FixtureUri("?lang=cn"));

        var simplified = new EGateSelectors
        {
            TextVariant = EGateTextVariant.Simplified,
            Timeout = TimeSpan.FromSeconds(5),
            QueryTimeout = TimeSpan.FromSeconds(5),
        };

        var sourceDialog = await SourceAddDialog.OpenAsync(page, simplified);
        var rowCount = await sourceDialog.SubmitAsync(["UCJ-123456"]);
        Assert.Equal(1, rowCount);
        Assert.True(await page.Locator("input[value='外销']").IsCheckedAsync());

        var plateDialog = await PlateEditDialog.OpenFromRowAsync(page, "LQE-261132362", simplified);
        await plateDialog.UpdatePlateAsync("粵B12345");
        Assert.Equal("粵B12345", await page.Locator("#plate-no").GetAttributeAsync("data-saved"));
    }

    [Fact]
    public async Task 找不到外銷選項時在查詢前就報錯()
    {
        if (_page is null)
        {
            return;
        }

        var page = _page;
        await page.GotoAsync(FixtureUri());

        var selectors = new EGateSelectors
        {
            Timeout = TimeSpan.FromSeconds(5),
            QueryTimeout = TimeSpan.FromSeconds(5),
            SourceTypeOptionText = "不存在的類型",
            SourceTypeOptionAliases = [],
        };

        var dialog = await SourceAddDialog.OpenAsync(page, selectors);

        var ex = await Assert.ThrowsAsync<EGateAutomationException>(
            () => dialog.SubmitAsync(["UCJ-123456"]));

        Assert.Contains("來源類型", ex.Message);
        Assert.True(await page.Locator("#dlg-source").IsVisibleAsync());
        Assert.Equal(string.Empty, await page.InputValueAsync("#source-no"));
    }

    private static string FixtureUri(string query = "")
        => new Uri(Path.Combine(AppContext.BaseDirectory, "fixtures", "gate.html")).AbsoluteUri + query;

    private static string? DetectChannel()
    {
        (string Path, string Channel)[] candidates =
        [
            (@"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe", "msedge"),
            (@"C:\Program Files\Microsoft\Edge\Application\msedge.exe", "msedge"),
            (@"C:\Program Files\Google\Chrome\Application\chrome.exe", "chrome"),
            (@"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe", "chrome"),
        ];

        foreach (var (path, channel) in candidates)
        {
            if (File.Exists(path))
            {
                return channel;
            }
        }

        return null;
    }
}

using GateAuto.Core.Models;
using Microsoft.Playwright;

namespace GateAuto.Automation.Tests;

/// <summary>
/// 列表识别骨架的端到端测试：真实 Chromium + 内联 HTML，覆盖关务物流（原生表格）
/// 与云富通（Ext 网格）两种列表结构。只验证「读列表」，不涉及点击或详情字段。
/// </summary>
public sealed class OrderListReaderTests : IAsyncLifetime
{
    private static readonly string? BrowserChannel = DetectChannel();

    private IPlaywright? _playwright;
    private IBrowser? _browser;
    private IPage? _page;

    public async Task InitializeAsync()
    {
        if (BrowserChannel is null)
        {
            return;
        }

        _playwright = await Playwright.CreateAsync();
        _browser = await _playwright.Chromium.LaunchAsync(new()
        {
            Channel = BrowserChannel,
            Headless = true,
        });
        _page = await _browser.NewPageAsync();
    }

    public async Task DisposeAsync()
    {
        if (_browser is not null)
        {
            await _browser.DisposeAsync();
        }

        _playwright?.Dispose();
    }

    [Fact]
    public async Task 關務列表_識別表頭申請編號與每一行()
    {
        if (_page is null)
        {
            return;
        }

        await _page.SetContentAsync(CustomsHtml());

        var result = await OrderListReader.ReadAsync(_page, OrderPlatform.CustomsLogistics);

        Assert.Null(result.Warning);
        Assert.Equal(2, result.TotalRows);
        Assert.Equal(2, result.Rows.Count);
        Assert.Contains("申請編號", result.Headers);

        var first = result.Rows[0];
        Assert.Equal(1, first.RowIndex);
        Assert.Equal("CIQ20241118001", first.ApplyNo);
        Assert.Equal("CIQ20241118001", first.DetailLinkText);
        Assert.Equal("採購一部", first.Columns["部門名稱"]);
        Assert.Equal("HZJC", first.Columns["廠區代碼"]);

        Assert.Equal("CIQ20241118002", result.Rows[1].ApplyNo);
    }

    [Fact]
    public async Task 關務列表_跳過無數據佔位行()
    {
        if (_page is null)
        {
            return;
        }

        await _page.SetContentAsync(CustomsHtml(includePlaceholder: true));

        var result = await OrderListReader.ReadAsync(_page, OrderPlatform.CustomsLogistics);

        Assert.Null(result.Warning);
        Assert.Equal(2, result.TotalRows);
        Assert.Equal(2, result.Rows.Count);
    }

    [Fact]
    public async Task 關務列表_找不到表格時回傳警告()
    {
        if (_page is null)
        {
            return;
        }

        await _page.SetContentAsync("<html><body><div>沒有表格</div></body></html>");

        var result = await OrderListReader.ReadAsync(_page, OrderPlatform.CustomsLogistics);

        Assert.NotNull(result.Warning);
        Assert.Contains("#task_rw", result.Warning);
        Assert.Equal(0, result.TotalRows);
    }

    [Fact]
    public async Task 雲富通列表_識別Ext網格行並回傳待映射警告()
    {
        if (_page is null)
        {
            return;
        }

        await _page.SetContentAsync(YunFuTongHtml());

        var result = await OrderListReader.ReadAsync(_page, OrderPlatform.YunFuTong);

        Assert.NotNull(result.Warning);
        Assert.Contains("Ext", result.Warning);
        Assert.Equal(2, result.TotalRows);
        Assert.Empty(result.Rows);
    }

    private static string CustomsHtml(bool includePlaceholder = false) => $"""
        <html><body>
        <table id="task_rw">
          <thead><tr>
            <th><input type="checkbox" id="headBox"></th>
            <th>序號</th><th>申請編號</th><th>部門名稱</th><th>費用代碼</th>
            <th>申請日期</th><th>表單類型</th><th>表單狀態</th><th>廠區代碼</th><th>姓名</th>
          </tr></thead>
          <tbody>
            <tr><td><input type="checkbox"></td><td>1</td><td><a href="#">CIQ20241118001</a></td><td>採購一部</td><td>FC001</td><td>2024-11-18</td><td>出口</td><td>待審核</td><td>HZJC</td><td>張三</td></tr>
            <tr><td><input type="checkbox"></td><td>2</td><td><a href="#">CIQ20241118002</a></td><td>採購二部</td><td>FC002</td><td>2024-11-18</td><td>出口</td><td>待審核</td><td>HZJC</td><td>李四</td></tr>
            {(includePlaceholder ? "<tr><td colspan=\"10\"><font color=\"red\">無簽核任務！</font></td><td></td></tr>" : "")}
          </tbody>
        </table>
        </body></html>
        """;

    private static string YunFuTongHtml() => """
        <html><body>
        <div class="x-grid-row"><div class="x-grid-cell">CIQ001</div><div class="x-grid-cell">採購部</div></div>
        <div class="x-grid-row"><div class="x-grid-cell">CIQ002</div><div class="x-grid-cell">倉儲部</div></div>
        </body></html>
        """;

    private static string? DetectChannel()
    {
        (string Path, string Channel)[] candidates =
        [
            (@"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe", "msedge"),
            (@"C:\Program Files\Microsoft\Edge\Application\msedge.exe", "msedge"),
            (@"C:\Program Files\Google\Chrome\Application\chrome.exe", "chrome"),
            (@"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe", "chrome"),
        ];

        foreach (var (path, channel) in candidates)
        {
            if (File.Exists(path))
            {
                return channel;
            }
        }

        return null;
    }
}

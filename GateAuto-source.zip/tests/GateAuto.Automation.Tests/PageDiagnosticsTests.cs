using System.Text;
using Microsoft.Playwright;

namespace GateAuto.Automation.Tests;

/// <summary>固定只读诊断命令的真实浏览器测试。</summary>
public sealed class PageDiagnosticsTests : IAsyncLifetime
{
    private const string DiagnosticHtml = """
        <!doctype html>
        <html><head><title>operator01 的订单列表</title></head><body>
          <form id="order-form">
            <label for="apply">申请单号</label>
            <input id="apply" name="applyNo" value="UCJ-123456" placeholder="申请单号">
            <input id="account" name="account" value="operator01">
            <input id="password" name="password" type="password" value="p@ss-word">
            <input id="api-token" name="api_token" value="token-value" authorization="attribute-secret">
          </form>
          <div id="actions">
            <button id="read">读取订单</button>
            <button id="disabled" disabled>不可用按钮</button>
          </div>
          <table id="orders" class="order-table">
            <thead><tr><th>申请单号</th><th>来源单号</th><th>LQE</th></tr></thead>
            <tbody>
              <tr><td>UCJ-123456</td><td>UCJ-SOURCE-01</td><td>LQE-261132999</td></tr>
              <tr><td>5CS-0001</td><td>5CS-SOURCE-02</td><td>LQE-261133000</td></tr>
            </tbody>
          </table>
          <a id="details" href="/orders/UCJ-123456?token=url-secret&amp;from=list">打开订单</a>
        </body></html>
        """;

    private static readonly string? BrowserChannel = DetectChannel();

    private readonly string _directory = Path.Combine(
        Path.GetTempPath(),
        "GateAuto.PageDiagnosticsTests",
        Guid.NewGuid().ToString("N"));

    private IPlaywright? _playwright;
    private IBrowser? _browser;
    private IPage? _page;

    public async Task InitializeAsync()
    {
        if (BrowserChannel is null)
        {
            return;
        }

        _playwright = await Playwright.CreateAsync();
        _browser = await _playwright.Chromium.LaunchAsync(new()
        {
            Channel = BrowserChannel,
            Headless = true,
        });
        _page = await _browser.NewPageAsync();
    }

    public async Task DisposeAsync()
    {
        if (_browser is not null)
        {
            await _browser.DisposeAsync();
        }

        _playwright?.Dispose();
        if (Directory.Exists(_directory))
        {
            Directory.Delete(_directory, true);
        }
    }

    [Fact]
    public async Task 常用命令_讀取訂單結構且不改變頁面()
    {
        if (_page is null)
        {
            return;
        }

        var page = _page;
        await page.SetContentAsync(DiagnosticHtml);
        var originalUrl = page.Url;
        var originalDom = await page.Locator("body").EvaluateAsync<string>("body => body.outerHTML");
        var originalValue = await page.InputValueAsync("#apply");

        var summary = await ExecuteAsync(page, "page");
        Assert.Contains("operator01 的订单列表", summary.Content);
        Assert.Contains("打開頁數: 1", summary.Content);

        var text = await ExecuteAsync(page, "text #orders");
        Assert.Contains("UCJ-123456", text.Content);
        Assert.Contains("LQE-261132999", text.Content);

        var fields = await ExecuteAsync(page, "fields #order-form");
        Assert.Contains("label=申请单号", fields.Content);
        Assert.Contains("value=UCJ-123456", fields.Content);
        Assert.Contains("value=***", fields.Content);
        Assert.DoesNotContain("p@ss-word", fields.Content);
        Assert.DoesNotContain("token-value", fields.Content);

        var buttons = await ExecuteAsync(page, "buttons #actions");
        Assert.Contains("text=读取订单", buttons.Content);
        Assert.Contains("enabled=True", buttons.Content);
        Assert.Contains("text=不可用按钮", buttons.Content);
        Assert.Contains("enabled=False", buttons.Content);

        var tables = await ExecuteAsync(page, "tables #orders");
        Assert.Contains("表頭: 申请单号 | 来源单号 | LQE", tables.Content);
        Assert.Contains("列 1: UCJ-123456 | UCJ-SOURCE-01 | LQE-261132999", tables.Content);
        Assert.Contains("rows=2/2", tables.Content);

        var links = await ExecuteAsync(page, "links #details");
        Assert.Contains("text=打开订单", links.Content);
        Assert.Contains("UCJ-123456", links.Content);
        Assert.Contains("token=***", links.Content);
        Assert.DoesNotContain("url-secret", links.Content);

        var html = await ExecuteAsync(page, "html #order-form");
        Assert.Contains("id=\"order-form\"", html.Content);
        Assert.Contains("UCJ-123456", html.Content);
        Assert.DoesNotContain("p@ss-word", html.Content);
        Assert.DoesNotContain("token-value", html.Content);
        Assert.DoesNotContain("attribute-secret", html.Content);

        Assert.Equal(originalUrl, page.Url);
        Assert.Equal(originalDom, await page.Locator("body").EvaluateAsync<string>("body => body.outerHTML"));
        Assert.Equal(originalValue, await page.InputValueAsync("#apply"));
    }

    [Fact]
    public async Task 快照與CSS作用域_只讀指定區域並拒絕非法輸入()
    {
        if (_page is null)
        {
            return;
        }

        var page = _page;
        await page.SetContentAsync(DiagnosticHtml);

        var snapshot = await ExecuteAsync(page, "snapshot #order-form");
        Assert.Contains("作用域: #order-form", snapshot.Content);
        Assert.Contains("UCJ-123456", snapshot.Content);
        Assert.Contains("===== fields =====", snapshot.Content);
        Assert.Contains("===== buttons =====", snapshot.Content);
        Assert.Contains("===== tables =====", snapshot.Content);
        Assert.Contains("===== links =====", snapshot.Content);
        Assert.DoesNotContain("读取订单", snapshot.Content);

        var invalidCommand = await Assert.ThrowsAsync<ArgumentException>(() => ExecuteAsync(page, "eval alert(1)"));
        Assert.Contains("未知命令", invalidCommand.Message);

        var invalidCss = await Assert.ThrowsAsync<ArgumentException>(() => ExecuteAsync(page, "fields ["));
        Assert.Contains("無效 CSS", invalidCss.Message);

        var missingCss = await Assert.ThrowsAsync<ArgumentException>(() => ExecuteAsync(page, "fields #missing"));
        Assert.Contains("找不到元素", missingCss.Message);

        var extraArgument = await Assert.ThrowsAsync<ArgumentException>(() => ExecuteAsync(page, "page body"));
        Assert.Contains("不接受", extraArgument.Message);

        var help = await ExecuteAsync(page, "help");
        Assert.Equal(PageDiagnostics.HelpText, help.Content);
    }

    [Fact]
    public async Task 脫敏_隱藏帳號密碼權杖但保留業務單號()
    {
        if (_page is null)
        {
            return;
        }

        var page = _page;
        await page.RouteAsync("https://diagnostics.test/**", route => route.FulfillAsync(new()
        {
            Status = 200,
            ContentType = "text/html; charset=utf-8",
            Body = DiagnosticHtml,
        }));
        await page.GotoAsync("https://diagnostics.test/orders?token=url-secret&apply=UCJ-123456");

        var summary = await ExecuteAsync(page, "page", ["operator01"]);
        Assert.Contains("token=***", summary.Content);
        Assert.Contains("apply=UCJ-123456", summary.Content);
        Assert.DoesNotContain("url-secret", summary.Content);
        Assert.DoesNotContain("operator01", summary.Content);

        var fields = await ExecuteAsync(page, "fields", ["operator01"]);
        Assert.DoesNotContain("operator01", fields.Content);
        Assert.DoesNotContain("p@ss-word", fields.Content);
        Assert.DoesNotContain("token-value", fields.Content);
        Assert.Contains("UCJ-123456", fields.Content);

        var html = await ExecuteAsync(page, "html", ["operator01"]);
        Assert.DoesNotContain("operator01", html.Content);
        Assert.DoesNotContain("p@ss-word", html.Content);
        Assert.DoesNotContain("token-value", html.Content);
        Assert.DoesNotContain("attribute-secret", html.Content);
        Assert.Contains("UCJ-123456", html.Content);
        Assert.Contains("LQE-261132999", html.Content);
        Assert.Contains("UCJ-SOURCE-01", html.Content);
    }

    [Fact]
    public async Task 輸出限制_限制項目數單值總長度與介面預覽()
    {
        if (_page is null)
        {
            return;
        }

        var page = _page;
        var inputs = string.Concat(Enumerable.Range(0, 103).Select(index =>
            $"<input id='f{index}' value='{index}'>"));
        await page.SetContentAsync($"<body>{inputs}<input id='long' value='{new string('x', 2100)}'></body>");

        var fields = await ExecuteAsync(page, "fields");
        Assert.Contains("項目: 100 / 104", fields.Content);
        Assert.Contains("另有 4 項未顯示", fields.Content);

        var longValue = await ExecuteAsync(page, "fields #long");
        Assert.Contains("已截斷，原始 2,100 字元", longValue.Content);

        var hugeCell = new string('z', 1800);
        var hugeHtml = new StringBuilder("<table id='huge'><tbody>");
        for (var row = 0; row < 100; row++)
        {
            hugeHtml.Append("<tr>");
            for (var column = 0; column < 12; column++)
            {
                hugeHtml.Append("<td>").Append(hugeCell).Append("</td>");
            }

            hugeHtml.Append("</tr>");
        }

        hugeHtml.Append("</tbody></table>");
        await page.SetContentAsync(hugeHtml.ToString());
        var huge = await ExecuteAsync(page, "tables #huge");
        Assert.Equal(2 * 1024 * 1024, huge.Content.Length);
        Assert.Contains("已截斷，原始", huge.Content);

        var preview = PageDiagnostics.Preview(new string('p', 40_000));
        Assert.Equal(32 * 1024, preview.Length);
        Assert.Contains("已截斷，原始 40,000 字元", preview);
    }

    [Fact]
    public async Task 截圖_生成包含目標名稱的PNG且不改變密碼()
    {
        if (_page is null)
        {
            return;
        }

        var page = _page;
        await page.SetContentAsync(DiagnosticHtml);

        var result = await PageDiagnostics.ExecuteAsync(
            page,
            "screenshot",
            _directory,
            target: "customs");

        Assert.NotNull(result.ScreenshotPath);
        Assert.True(File.Exists(result.ScreenshotPath));
        Assert.Contains("customs", Path.GetFileName(result.ScreenshotPath));
        Assert.Contains(result.ScreenshotPath, result.Content);
        var bytes = await File.ReadAllBytesAsync(result.ScreenshotPath);
        Assert.True(bytes.Length > 8);
        Assert.Equal(new byte[] { 137, 80, 78, 71, 13, 10, 26, 10 }, bytes[..8]);
        Assert.Equal("p@ss-word", await page.InputValueAsync("#password"));
    }

    [Fact]
    public async Task 保存HTML_整頁與指定區域各自存檔且脫敏()
    {
        if (_page is null)
        {
            return;
        }

        var page = _page;
        await page.SetContentAsync(DiagnosticHtml);
        var originalDom = await page.Locator("body").EvaluateAsync<string>("body => body.outerHTML");

        var full = await PageDiagnostics.ExecuteAsync(
            page,
            "savehtml",
            _directory,
            ["operator01"],
            target: "customs");

        Assert.NotNull(full.SavedHtmlPath);
        Assert.True(File.Exists(full.SavedHtmlPath));
        Assert.Contains("customs", Path.GetFileName(full.SavedHtmlPath));
        Assert.Contains("full", Path.GetFileName(full.SavedHtmlPath));
        Assert.Contains(full.SavedHtmlPath, full.Content);

        var fullHtml = await File.ReadAllTextAsync(full.SavedHtmlPath);
        Assert.Contains("<!DOCTYPE html>", fullHtml);
        Assert.Contains("id=\"order-form\"", fullHtml);
        Assert.Contains("UCJ-123456", fullHtml);
        Assert.Contains("LQE-261132999", fullHtml);
        Assert.DoesNotContain("operator01", fullHtml);
        Assert.DoesNotContain("p@ss-word", fullHtml);
        Assert.DoesNotContain("token-value", fullHtml);
        Assert.DoesNotContain("attribute-secret", fullHtml);

        var scoped = await PageDiagnostics.ExecuteAsync(
            page,
            "savehtml #orders",
            _directory,
            target: "customs");

        Assert.NotNull(scoped.SavedHtmlPath);
        var scopedHtml = await File.ReadAllTextAsync(scoped.SavedHtmlPath);
        Assert.StartsWith("<table", scopedHtml);
        Assert.DoesNotContain("<!DOCTYPE html>", scopedHtml);
        Assert.Contains("LQE-261133000", scopedHtml);

        var invalidCss = await Assert.ThrowsAsync<ArgumentException>(() => ExecuteAsync(page, "savehtml ["));
        Assert.Contains("無效 CSS", invalidCss.Message);

        var missingCss = await Assert.ThrowsAsync<ArgumentException>(() => ExecuteAsync(page, "savehtml #missing"));
        Assert.Contains("找不到元素", missingCss.Message);

        Assert.Equal(originalDom, await page.Locator("body").EvaluateAsync<string>("body => body.outerHTML"));
        Assert.Equal("p@ss-word", await page.InputValueAsync("#password"));
    }

    [Fact]
    public async Task 頁面關閉_返回可重試錯誤()
    {
        if (_page is null)
        {
            return;
        }

        var page = _page;
        await page.SetContentAsync(DiagnosticHtml);
        await page.CloseAsync();

        var ex = await Assert.ThrowsAsync<InvalidOperationException>(() => ExecuteAsync(page, "text"));
        Assert.Contains("頁面已關閉或正在跳轉", ex.Message);
    }

    private Task<PageDiagnosticResult> ExecuteAsync(
        IPage page,
        string command,
        IReadOnlyList<string>? sensitiveValues = null)
        => PageDiagnostics.ExecuteAsync(page, command, _directory, sensitiveValues);

    private static string? DetectChannel()
    {
        (string Path, string Channel)[] candidates =
        [
            (@"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe", "msedge"),
            (@"C:\Program Files\Microsoft\Edge\Application\msedge.exe", "msedge"),
            (@"C:\Program Files\Google\Chrome\Application\chrome.exe", "chrome"),
            (@"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe", "chrome"),
        ];

        foreach (var (path, channel) in candidates)
        {
            if (File.Exists(path))
            {
                return channel;
            }
        }

        return null;
    }
}

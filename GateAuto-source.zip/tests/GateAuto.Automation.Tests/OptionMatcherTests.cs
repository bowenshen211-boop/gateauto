using GateAuto.Automation;
using Xunit;

namespace GateAuto.Automation.Tests;

public class OptionMatcherTests
{
    [Fact]
    public void 带编号前缀的简体选项可以匹配繁体候选()
    {
        var options = new[] { "請選擇", "1-货物", "2-勞務" };

        Assert.Equal(1, OptionMatcher.FindBestIndex(options, "貨物"));
    }

    [Fact]
    public void 候选与选项都带编号时仍可匹配()
    {
        var options = new[] { "087-不返厂货样", "021-保税" };

        Assert.Equal(0, OptionMatcher.FindBestIndex(options, "087-不返廠貨樣"));
    }

    [Fact]
    public void 完全相同的选项优先于去前缀相同()
    {
        var options = new[] { "货物", "1-货物" };

        Assert.Equal(0, OptionMatcher.FindBestIndex(options, "貨物"));
    }

    [Fact]
    public void 去前缀相同优先于包含匹配()
    {
        var options = new[] { "1-货物运输", "1-货物" };

        Assert.Equal(1, OptionMatcher.FindBestIndex(options, "貨物"));
    }

    [Fact]
    public void 没有编号时使用包含匹配()
    {
        var options = new[] { "公路运输", "铁路运输" };

        Assert.Equal(0, OptionMatcher.FindBestIndex(options, "公路"));
    }

    [Fact]
    public void 繁体候选可以匹配简体选项()
    {
        var options = new[] { "外销", "内销" };

        Assert.Equal(0, OptionMatcher.FindBestIndex(options, "外銷"));
    }

    [Fact]
    public void 多个候选按顺序取第一个能匹配的()
    {
        var options = new[] { "1-货物" };

        Assert.Equal(0, OptionMatcher.FindBestIndex(options, new[] { "不存在的值", "貨物" }));
    }

    [Fact]
    public void 找不到时返回负一()
    {
        var options = new[] { "1-货物" };

        Assert.Equal(-1, OptionMatcher.FindBestIndex(options, "快递"));
    }

    [Fact]
    public void 空白候选不参与匹配()
    {
        var options = new[] { "1-货物" };

        Assert.Equal(-1, OptionMatcher.FindBestIndex(options, "   "));
    }
}

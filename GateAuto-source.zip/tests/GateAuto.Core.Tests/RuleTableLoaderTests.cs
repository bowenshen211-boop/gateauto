using GateAuto.Core.Rules;

namespace GateAuto.Core.Tests;

/// <summary>规则表加载与校验。</summary>
public sealed class RuleTableLoaderTests
{
    [Fact]
    public void 内嵌规则表包含全部已确认规则()
    {
        var table = RuleTableLoader.Default;

        Assert.Equal(
            ["R001", "R002", "R003", "R004", "R005", "R006"],
            table.ExitTypeRules.Select(r => r.Id));
        Assert.Contains(table.CargoTypeRules, r => r.Id == "R007");
        Assert.Contains(table.VendorCodeRules, r => r.Id == "R009");
    }

    [Fact]
    public void 缺少兜底规则时拒绝加载()
    {
        const string json = """
            {
              "exitTypeRules": [
                { "id": "R001", "prefix": "5CS", "code": "087" }
              ]
            }
            """;

        var ex = Assert.Throws<InvalidOperationException>(() => RuleTableLoader.Parse(json));
        Assert.Contains("兜底", ex.Message);
    }

    [Fact]
    public void 货物性质正则非法时拒绝加载()
    {
        const string json = """
            {
              "exitTypeRules": [ { "id": "R006", "prefix": "*", "code": "051" } ],
              "cargoTypeRules": [ { "id": "R007", "pattern": "[A-Z", "cargoType": "保稅" } ]
            }
            """;

        var ex = Assert.Throws<InvalidOperationException>(() => RuleTableLoader.Parse(json));
        Assert.Contains("R007", ex.Message);
    }

    [Fact]
    public void 可按优先级新增来源单号规则()
    {
        const string json = """
            {
              "exitTypeRules": [
                { "id": "R100", "priority": 5, "prefix": "ABC", "code": "099", "name": "新增類別" },
                { "id": "R006", "priority": 999, "prefix": "*", "code": "051" }
              ]
            }
            """;

        var engine = new RuleEngine(RuleTableLoader.Parse(json));
        var result = engine.Evaluate(TestOrder.Create("ABC-0001"));

        Assert.Equal("099", result.ExitTypeCode);
        Assert.Equal("099-新增類別", result.ExitTypeDisplay);
    }
}

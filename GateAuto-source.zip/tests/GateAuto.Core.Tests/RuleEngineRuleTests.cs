using GateAuto.Core.Rules;

namespace GateAuto.Core.Tests;

/// <summary>出闸类别、货物性质、厂商代码规则（R001~R009）。</summary>
public sealed class RuleEngineRuleTests
{
    [Theory]
    // R001：5CS 不分大小写 → 087 / 非保税 / 厂商代码 N
    [InlineData("5CS-QB0081", "087", "不返廠貨樣", "非保稅", "N")]
    [InlineData("5cs-QB0081", "087", "不返廠貨樣", "非保稅", "N")]
    [InlineData("5Cs-QB0081", "087", "不返廠貨樣", "非保稅", "N")]
    [InlineData("5cS-QB0081", "087", "不返廠貨樣", "非保稅", "N")]
    // R002 / R003：全大写 UCJ / UCN → 021 / 保税
    [InlineData("UCJ-123456", "021", "銷貨(報關出口)", "保稅", "V001")]
    [InlineData("UCN-888888", "021", "銷貨(報關出口)", "保稅", "V001")]
    // R004 / R005：非全大写 → 051 / 非保税
    [InlineData("Ucj-123456", "051", "快遞銷貨(不報關)", "非保稅", "V001")]
    [InlineData("Ucn-888888", "051", "快遞銷貨(不報關)", "非保稅", "V001")]
    // 中间态：只要不是全大写，一律走 051
    [InlineData("UCj-123456", "051", "快遞銷貨(不報關)", "非保稅", "V001")]
    [InlineData("uCJ-123456", "051", "快遞銷貨(不報關)", "非保稅", "V001")]
    [InlineData("ucj-123456", "051", "快遞銷貨(不報關)", "非保稅", "V001")]
    // R006：其他来源单号
    [InlineData("ABC-0001", "051", "快遞銷貨(不報關)", "保稅", "V001")]
    [InlineData("XYZ-0001", "051", "快遞銷貨(不報關)", "保稅", "V001")]
    [InlineData("A5C-0001", "051", "快遞銷貨(不報關)", "非保稅", "V001")]
    public void 规则表对来源单号给出正确的出闸类别与货物性质(
        string sourceNo,
        string expectedExitCode,
        string expectedExitName,
        string expectedCargoType,
        string expectedVendorCode)
    {
        var result = TestOrder.Evaluate(TestOrder.Create(sourceNo));

        Assert.True(result.IsValid, string.Join("; ", result.Errors));
        Assert.Equal(expectedExitCode, result.ExitTypeCode);
        Assert.Equal(expectedExitName, result.ExitTypeName);
        Assert.Equal(expectedCargoType, result.CargoType);
        Assert.Equal(expectedVendorCode, result.VendorCode);
    }

    [Theory]
    [InlineData("5CS-QB0081", "5CS")]
    [InlineData("UCJ-123456", "UCJ")]
    [InlineData("Ucj-123456", "Ucj")]
    public void 判定使用来源单号前三位(string sourceNo, string expectedPrefix)
    {
        var result = TestOrder.Evaluate(TestOrder.Create(sourceNo));

        Assert.Equal(expectedPrefix, result.MatchedPrefix);
    }

    [Fact]
    public void 出闸类别显示值带代码前缀()
    {
        var result = TestOrder.Evaluate(TestOrder.Create("5CS-QB0081"));

        Assert.Equal("087-不返廠貨樣", result.ExitTypeDisplay);
    }

    [Fact]
    public void 非5CS来源保留订单自带厂商代码()
    {
        var result = TestOrder.Evaluate(TestOrder.Create("UCJ-123456", vendorCode: "8899"));

        Assert.Equal("8899", result.VendorCode);
    }

    [Fact]
    public void 缺失厂商代码时报错()
    {
        var result = TestOrder.Evaluate(TestOrder.Create("UCJ-123456", vendorCode: ""));

        Assert.False(result.IsValid);
        Assert.Contains(result.Errors, e => e.Contains("廠商代碼"));
    }
}

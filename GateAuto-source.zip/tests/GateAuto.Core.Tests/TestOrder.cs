using GateAuto.Core.Models;
using GateAuto.Core.Rules;

namespace GateAuto.Core.Tests;

internal static class TestOrder
{
    public const string DomesticAddress = "華北-晉城市-晉城園區-B區-C1";

    public const string OutsideAddress = "廣東省深圳市寶安區福永街道";

    public static OrderInfo Create(
        string sourceNo,
        string deliveryAddress = OutsideAddress,
        string vendorCode = "V001",
        string loadingAddress = "C1",
        string packingMethod = "22-紙製或纖維板製裝盒/箱",
        string unloadAddress = "")
        => new()
        {
            ApplyNo = "APP-20261117-001",
            SourceNos = SourceNoParser.Parse(sourceNo),
            DeliveryAddress = deliveryAddress,
            PackageCount = 1,
            GrossWeightKg = 11m,
            NetWeightKg = 10m,
            PackingMethod = packingMethod,
            VendorCode = vendorCode,
            LoadingAddress = loadingAddress,
            Consignee = "深圳富士康",
            UnloadAddress = unloadAddress,
        };

    public static RuleEvaluation Evaluate(OrderInfo order) => new RuleEngine(RuleTableLoader.Default).Evaluate(order);
}

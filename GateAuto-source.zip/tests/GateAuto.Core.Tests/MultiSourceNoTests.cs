using GateAuto.Core.Rules;

namespace GateAuto.Core.Tests;

/// <summary>多来源单号的拆分、拼接与不一致提示。</summary>
public sealed class MultiSourceNoTests
{
    [Theory]
    [InlineData("5CS-QB0081,UCJ-123456,UCN-888888", "5CS-QB0081,UCJ-123456,UCN-888888")]
    [InlineData("5CS-QB0081，UCJ-123456", "5CS-QB0081,UCJ-123456")]
    [InlineData(" 5CS-QB0081 ,  UCJ-123456  ", "5CS-QB0081,UCJ-123456")]
    public void 支持中英文逗号并可拼接粘贴(string raw, string expected)
    {
        var result = TestOrder.Evaluate(TestOrder.Create(raw));

        Assert.Equal(expected, result.SourceNosText);
    }

    [Fact]
    public void 多来源单号出闸类别不一致时给出警告并以第一笔为准()
    {
        var result = TestOrder.Evaluate(TestOrder.Create("5CS-QB0081,UCJ-123456"));

        Assert.Equal("087", result.ExitTypeCode);
        Assert.Contains(result.Warnings, w => w.Contains("出閘類別不一致") && w.Contains("5CS-QB0081"));
    }

    [Fact]
    public void 多来源单号类别一致时不产生警告()
    {
        var result = TestOrder.Evaluate(TestOrder.Create("UCJ-123456,UCN-888888"));

        Assert.Equal("021", result.ExitTypeCode);
        Assert.Empty(result.Warnings);
    }

    [Fact]
    public void 多来源单号混合大小写时货物性质冲突给出警告()
    {
        var result = TestOrder.Evaluate(TestOrder.Create("UCJ-123456,Ucj-123456"));

        Assert.Equal("保稅", result.CargoType);
        Assert.Contains(result.Warnings, w => w.Contains("貨物性質不一致"));
    }

    [Fact]
    public void 缺少来源单号时报错()
    {
        var result = TestOrder.Evaluate(TestOrder.Create(""));

        Assert.False(result.IsValid);
        Assert.Contains(result.Errors, e => e.Contains("來源單號"));
        Assert.Equal(string.Empty, result.SourceNosText);
    }

    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData("   ")]
    public void 空白输入解析为空列表(string? raw)
    {
        Assert.Empty(SourceNoParser.Parse(raw));
    }

    [Theory]
    [InlineData("A，B,C", 3)]
    [InlineData("A,,B", 2)]
    public void 解析时忽略空项(string raw, int expectedCount)
    {
        Assert.Equal(expectedCount, SourceNoParser.Parse(raw).Count);
    }

    [Theory]
    [InlineData("U", "U")]
    [InlineData("UC", "UC")]
    [InlineData("UCJ", "UCJ")]
    [InlineData("UCJ-123456", "UCJ")]
    public void 前缀最多取三位(string sourceNo, string expectedPrefix)
    {
        Assert.Equal(expectedPrefix, SourceNoParser.PrefixOf(sourceNo));
    }
}

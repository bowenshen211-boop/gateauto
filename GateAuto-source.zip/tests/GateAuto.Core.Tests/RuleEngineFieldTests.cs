using GateAuto.Core.Rules;

namespace GateAuto.Core.Tests;

/// <summary>厂商类型、落货园区、装货地址、包装方式与固定字段。</summary>
public sealed class RuleEngineFieldTests
{
    [Theory]
    [InlineData("華北-晉城市-晉城園區-B區-C1")]
    [InlineData("晉城園區A區")]
    [InlineData("晉城園區C區")]
    [InlineData("晉城園區D區")]
    public void 送货地址命中园区时为集团国内并填写落货园区(string address)
    {
        var result = TestOrder.Evaluate(TestOrder.Create("UCJ-123456", deliveryAddress: address));

        Assert.Equal("集團國內", result.VendorType);
        Assert.Equal(address, result.UnloadingPark);
    }

    [Theory]
    [InlineData("廣東省深圳市寶安區福永街道")]
    [InlineData("江蘇省昆山市玉山鎮")]
    public void 送货地址未命中园区时为集团外且落货园区留空(string address)
    {
        var result = TestOrder.Evaluate(TestOrder.Create("UCJ-123456", deliveryAddress: address));

        Assert.Equal("集團外", result.VendorType);
        Assert.Null(result.UnloadingPark);
    }

    [Theory]
    [InlineData("A1")]
    [InlineData("B1")]
    [InlineData("C1")]
    [InlineData("D1")]
    [InlineData("E1")]
    public void 装货地址从订单读取且不写死(string loadingAddress)
    {
        var result = TestOrder.Evaluate(TestOrder.Create("UCJ-123456", loadingAddress: loadingAddress));

        Assert.Equal(loadingAddress, result.LoadingAddress);
    }

    [Fact]
    public void 缺失装货地址时报错()
    {
        var result = TestOrder.Evaluate(TestOrder.Create("UCJ-123456", loadingAddress: "  "));

        Assert.False(result.IsValid);
        Assert.Contains(result.Errors, e => e.Contains("裝貨地址"));
    }

    [Fact]
    public void 包装方式直接带入()
    {
        var result = TestOrder.Evaluate(TestOrder.Create("UCJ-123456", packingMethod: "22-紙製或纖維板製裝盒/箱"));

        Assert.Equal("22-紙製或纖維板製裝盒/箱", result.PackingMethod);
    }

    [Fact]
    public void 缺失包装方式时报错()
    {
        var result = TestOrder.Evaluate(TestOrder.Create("UCJ-123456", packingMethod: ""));

        Assert.False(result.IsValid);
        Assert.Contains(result.Errors, e => e.Contains("包裝方式"));
    }

    [Fact]
    public void 落货地址优先使用云付通提供值()
    {
        var result = TestOrder.Evaluate(TestOrder.Create("UCJ-123456", unloadAddress: "深圳市龍華區倉庫"));

        Assert.Equal("深圳市龍華區倉庫", result.UnloadingAddress);
    }

    [Fact]
    public void 落货地址缺省时回退到送货地址()
    {
        var result = TestOrder.Evaluate(TestOrder.Create("UCJ-123456", unloadAddress: ""));

        Assert.Equal(TestOrder.OutsideAddress, result.UnloadingAddress);
    }

    [Fact]
    public void 固定字段来自规则表()
    {
        var result = TestOrder.Evaluate(TestOrder.Create("UCJ-123456"));

        Assert.Equal("貨物", result.FixedFields.DeclarationType);
        Assert.Equal("1405930037-富晋精密工业（晋城）有限公司", result.FixedFields.LegalEntity);
        Assert.Equal("TGB005-Fundamental&Connection", result.FixedFields.ApplyDepartment);
        Assert.Equal("公路運輸", result.FixedFields.TransportMode);
        Assert.Equal("華北-晉城市-晉城園區-B區-C1", result.FixedFields.LoadingPark);
        Assert.Equal("外銷", result.FixedFields.SourceType);
    }
}

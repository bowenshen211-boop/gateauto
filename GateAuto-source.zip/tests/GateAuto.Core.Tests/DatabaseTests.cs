using GateAuto.Core.Models;
using GateAuto.Data;
using Microsoft.Data.Sqlite;

namespace GateAuto.Core.Tests;

internal sealed class TempDatabase : IDisposable
{
    public TempDatabase()
    {
        RootPath = Path.Combine(Path.GetTempPath(), "GateAutoTests", Guid.NewGuid().ToString("N"));
        Database = new GateAutoDatabase(Path.Combine(RootPath, "gateauto.db"));
        Database.Initialize();
    }

    public string RootPath { get; }

    public GateAutoDatabase Database { get; }

    public OrderRepository Orders => new(Database);

    public PlateTaskRepository PlateTasks => new(Database);

    public void Dispose()
    {
        try
        {
            Directory.Delete(RootPath, recursive: true);
        }
        catch (IOException)
        {
            // 测试收尾失败不影响结论。
        }
        catch (UnauthorizedAccessException)
        {
        }
    }
}

public sealed class DatabaseTests
{
    [Fact]
    public void 初始化后Orders与PlateTasks表存在()
    {
        using var temp = new TempDatabase();

        using var connection = temp.Database.OpenConnection();
        using var command = connection.CreateCommand();
        command.CommandText = "SELECT name FROM sqlite_master WHERE type = 'table' ORDER BY name;";

        using var reader = command.ExecuteReader();
        var tables = new List<string>();
        while (reader.Read())
        {
            tables.Add(reader.GetString(0));
        }

        Assert.Contains("Orders", tables);
        Assert.Contains("PlateTasks", tables);
    }

    [Fact]
    public void 同一申请编号重复写入不会产生重复记录()
    {
        using var temp = new TempDatabase();
        var repository = temp.Orders;

        var firstId = repository.Save(NewOrder("5CS-QB0081", "N"));
        var secondId = repository.Save(NewOrder("5CS-QB0081", "N"));

        Assert.Equal(firstId, secondId);
        Assert.Equal(firstId, repository.GetByApplyNo(OrderPlatform.CustomsLogistics, "APP-001")!.Id);
    }

    [Fact]
    public void 旧版数据库升级后补充平台列并以平台加申请编号为唯一键()
    {
        var root = Path.Combine(Path.GetTempPath(), "GateAutoTests", Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(root);
        var database = new GateAutoDatabase(Path.Combine(root, "legacy.db"));

        using (var connection = database.OpenConnection())
        using (var command = connection.CreateCommand())
        {
            command.CommandText = """
                CREATE TABLE Orders (
                    Id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    ApplyNo     TEXT NOT NULL,
                    SourceNo    TEXT NOT NULL,
                    ExitType    TEXT NOT NULL DEFAULT '',
                    CargoType   TEXT NOT NULL DEFAULT '',
                    VendorCode  TEXT NOT NULL DEFAULT '',
                    LqeNo       TEXT NULL,
                    PlateNo     TEXT NULL,
                    Status      TEXT NOT NULL DEFAULT '待建單',
                    CreatedAt   TEXT NOT NULL
                );
                CREATE UNIQUE INDEX IX_Orders_ApplyNo ON Orders (ApplyNo);
                INSERT INTO Orders (ApplyNo, SourceNo, Status, CreatedAt)
                VALUES ('APP-LEGACY', 'UCJ-1', '待建單', '2026-01-01T00:00:00.0000000+08:00');
                """;
            command.ExecuteNonQuery();
        }

        database.Initialize();

        var repository = new OrderRepository(database);
        var legacy = repository.GetByApplyNo(OrderPlatform.CustomsLogistics, "APP-LEGACY");
        Assert.NotNull(legacy);
        Assert.Equal(OrderPlatform.CustomsLogistics, legacy!.Platform);

        repository.Save(new OrderRecord
        {
            Platform = OrderPlatform.YunFuTong,
            ApplyNo = "APP-LEGACY",
            SourceNo = "5CS-1",
            Status = OrderStatus.Pending,
            CreatedAt = DateTimeOffset.Now,
        });

        Assert.Equal(OrderPlatform.YunFuTong, repository.GetByApplyNo(OrderPlatform.YunFuTong, "APP-LEGACY")!.Platform);
        Assert.Equal("UCJ-1", repository.GetByApplyNo(OrderPlatform.CustomsLogistics, "APP-LEGACY")!.SourceNo);

        SqliteConnection.ClearAllPools();
        Directory.Delete(root, recursive: true);
    }

    [Fact]
    public void 两个平台相同申请编号互不覆盖()
    {
        using var temp = new TempDatabase();
        var repository = temp.Orders;

        var customsId = repository.Save(NewOrder("UCJ-123456", "8899"));
        var yftRecord = NewOrder("5CS-QB0081", "N");
        var yftId = repository.Save(new OrderRecord
        {
            Platform = OrderPlatform.YunFuTong,
            ApplyNo = yftRecord.ApplyNo,
            SourceNo = yftRecord.SourceNo,
            ExitType = yftRecord.ExitType,
            CargoType = yftRecord.CargoType,
            VendorCode = yftRecord.VendorCode,
            Status = yftRecord.Status,
            CreatedAt = yftRecord.CreatedAt,
        });

        Assert.NotEqual(customsId, yftId);

        var customs = repository.GetByApplyNo(OrderPlatform.CustomsLogistics, "APP-001")!;
        var yft = repository.GetByApplyNo(OrderPlatform.YunFuTong, "APP-001")!;

        Assert.Equal("UCJ-123456", customs.SourceNo);
        Assert.Equal("5CS-QB0081", yft.SourceNo);
        Assert.Equal(OrderPlatform.YunFuTong, yft.Platform);
    }

    [Fact]
    public void 建单成功后回写LQE放行单号()
    {
        using var temp = new TempDatabase();
        var repository = temp.Orders;
        repository.Save(NewOrder("UCJ-123456", "8899"));

        Assert.True(repository.MarkCreated(OrderPlatform.CustomsLogistics, "APP-001", "LQE-261132362"));

        var saved = repository.GetByApplyNo(OrderPlatform.CustomsLogistics, "APP-001")!;
        Assert.Equal("LQE-261132362", saved.LqeNo);
        Assert.Equal(OrderStatus.Created, saved.Status);
    }

    [Fact]
    public void 建单失败时更新状态()
    {
        using var temp = new TempDatabase();
        var repository = temp.Orders;
        repository.Save(NewOrder("UCJ-123456", "8899"));

        Assert.True(repository.MarkFailed(OrderPlatform.CustomsLogistics, "APP-001"));
        Assert.Equal(OrderStatus.Failed, repository.GetByApplyNo(OrderPlatform.CustomsLogistics, "APP-001")!.Status);
    }

    [Fact]
    public void 待派车清单写入后车牌为空且状态待派车()
    {
        using var temp = new TempDatabase();
        var repository = temp.PlateTasks;

        repository.Add(NewPlateTask());

        var task = repository.GetByLqeNo("LQE-261132362")!;
        Assert.Equal("深圳", task.Destination);
        Assert.Equal(1, task.PackageCount);
        Assert.Equal("11KG", task.WeightText);
        Assert.Equal(PlateTaskStatus.Pending, task.Status);
        Assert.False(task.HasPlate);
    }

    [Fact]
    public void 修改车牌后状态变为已更新()
    {
        using var temp = new TempDatabase();
        var repository = temp.PlateTasks;
        repository.Add(NewPlateTask());

        Assert.True(repository.UpdatePlate("LQE-261132362", "晉EC6106"));

        var task = repository.GetByLqeNo("LQE-261132362")!;
        Assert.Equal("晉EC6106", task.PlateNo);
        Assert.Equal(PlateTaskStatus.Updated, task.Status);
        Assert.NotNull(task.UpdatedAt);
        Assert.True(task.HasPlate);
    }

    [Fact]
    public void 更新不存在的放行单号返回false()
    {
        using var temp = new TempDatabase();

        Assert.False(temp.PlateTasks.UpdatePlate("LQE-NOT-EXIST", "晉EC6106"));
    }

    [Fact]
    public void 同一放行单号重复写入不会重复派车任务()
    {
        using var temp = new TempDatabase();
        var repository = temp.PlateTasks;

        repository.Add(NewPlateTask());
        repository.Add(NewPlateTask());

        Assert.Single(repository.ListAll());
    }

    private static OrderRecord NewOrder(string sourceNo, string vendorCode) => new()
    {
        ApplyNo = "APP-001",
        SourceNo = sourceNo,
        ExitType = "087",
        CargoType = "非保稅",
        VendorCode = vendorCode,
        Status = OrderStatus.Pending,
        CreatedAt = DateTimeOffset.Now,
    };

    private static PlateTask NewPlateTask() => new()
    {
        LqeNo = "LQE-261132362",
        Destination = "深圳",
        PackageCount = 1,
        WeightKg = 11m,
        CreatedAt = DateTimeOffset.Now,
    };
}

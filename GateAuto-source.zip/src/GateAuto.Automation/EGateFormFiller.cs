using System.Text.Json;
using Microsoft.Playwright;

namespace GateAuto.Automation;

/// <summary>
/// 建单表单的通用填写器。
///
/// 电子闸口前端是 Element Plus（Vue 3），但不同模块的表单结构并不完全一致，
/// 因此这里不依赖任何元素 ID / class 组合，而是用「标签文字」定位：
/// 1. 在页面上找到文字等于（或以单位后缀结尾）标签的元素；
/// 2. 向上找最近的 form-item / td / 容器；
/// 3. 在容器内找输入框、原生 select 或 Element Plus 的 select 外壳；
/// 4. 给目标打上临时属性 data-gateauto，再用标准 CSS 属性选择器操作。
///
/// 这样无论是 Element Plus 还是普通 HTML 表格表单，都能用同一套流程填写。
/// </summary>
public static class EGateFormFiller
{
    private const string MarkerAttribute = "data-gateauto";

    private const string FindFieldScript = """
        (args) => {
          const norm = s => (s || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
          const labels = (args.labels || []).map(norm).filter(Boolean);
          if (labels.length === 0) {
            return { found: false, kind: null, tag: null, error: '未設定欄位標籤' };
          }

          const root = args.scope ? document.querySelector(args.scope) : document;
          if (!root) {
            return { found: false, kind: null, tag: null, error: '找不到指定的搜尋範圍' };
          }

          const visible = el => !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);

          const scoreText = (text) => {
            for (const l of labels) {
              if (text === l) return 2;
              if (!text.startsWith(l)) continue;
              const rest = text.slice(l.length).trim();
              if (rest === '' || rest === ':' || rest === '：') return 2;
              if (/^[（(][^）)]{0,10}[)）]$/.test(rest)) return 1;
            }
            return 0;
          };

          const nodes = Array.from(root.querySelectorAll('.el-form-item__label, label, th, td, span, div, p'));
          let best = null;
          let bestScore = -1;

          for (const el of nodes) {
            if (!visible(el)) continue;
            const text = norm(el.textContent);
            if (!text || text.length > 40) continue;

            const score = scoreText(text);
            if (score === 0) continue;

            const className = el.className ? String(el.className) : '';
            const isLabelTag = el.tagName === 'LABEL' || className.indexOf('el-form-item__label') >= 0;
            const total = score * 10 + (isLabelTag ? 1 : 0);

            if (total > bestScore) {
              best = el;
              bestScore = total;
            }
          }

          if (!best) {
            return { found: false, kind: null, tag: null, error: '找不到標籤' };
          }

          const findControl = (container) => {
            if (!container) return null;

            const wrapper = container.querySelector('.el-select__wrapper');
            if (wrapper && visible(wrapper)) return { el: wrapper, kind: 'elselect' };

            const native = container.querySelector('select');
            if (native && visible(native)) return { el: native, kind: 'select' };

            const input = container.querySelector(
              'textarea, input:not([type=hidden]):not([type=checkbox]):not([type=radio]):not([type=file])');
            if (input && visible(input)) return { el: input, kind: 'text' };

            return null;
          };

          let container = best.closest('.el-form-item')
            || best.closest('td')
            || best.closest('tr')
            || best.parentElement;

          let control = null;
          for (let i = 0; i < 4 && container; i++) {
            control = findControl(container);
            if (control) break;
            container = container.parentElement;
          }

          if (!control) {
            return { found: false, kind: null, tag: null, error: '找到標籤但找不到對應的輸入控件' };
          }

          document.querySelectorAll('[data-gateauto]').forEach(e => e.removeAttribute('data-gateauto'));
          control.el.setAttribute('data-gateauto', args.token);

          return { found: true, kind: control.kind, tag: control.el.tagName, error: null };
        }
        """;

    /// <summary>按标签文字填写一个字段。找不到控件时，可选字段记警告，必填字段抛异常。</summary>
    public static async Task FillAsync(
        IPage page,
        EGateSelectors selectors,
        EGateField field,
        IReadOnlyList<string> values,
        string displayName,
        ICollection<string> warnings,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(page);
        ArgumentNullException.ThrowIfNull(selectors);

        var labels = selectors.LabelsOf(field);
        var match = await MarkFieldAsync(page, labels);

        if (match is null || !match.found)
        {
            var reason = match?.error ?? "找不到標籤";
            if (selectors.OptionalFields.Contains(field))
            {
                warnings.Add($"{displayName}：{reason}（{string.Join(" / ", labels)}），已略過");
                return;
            }

            throw new EGateAutomationException(
                $"表單上找不到「{displayName}」（標籤：{string.Join(" / ", labels)}）：{reason}。" +
                "若真實系統標籤不同，請在 EGateSelectors.FieldLabels 或 FieldLabelAliases 調整");
        }

        var kind = selectors.FieldKinds.TryGetValue(field, out var configured) ? configured : EGateFieldKind.Text;
        var selector = $"[{MarkerAttribute}='{match.token}']";

        cancellationToken.ThrowIfCancellationRequested();

        // 以页面实际控件类型为准：Element Plus 的 select 与原生 select 都走选择逻辑，
        // 普通输入框即使配置成 Select 也按文本填写，避免因配置与实际不符而失败。
        var isSelect = match.kind switch
        {
            "select" or "elselect" => true,
            "text" => false,
            _ => kind == EGateFieldKind.Select,
        };

        if (isSelect)
        {
            await SelectAsync(page, selectors, selector, match.kind, values, displayName);
            return;
        }

        await FillTextAsync(page, selectors, selector, values);
    }

    /// <summary>只做定位，不操作。找到返回匹配信息，找不到返回 null。</summary>
    public static async Task<FieldMatch?> MarkFieldAsync(IPage page, IReadOnlyList<string> labels, string? scope = null)
    {
        var token = Guid.NewGuid().ToString("N");
        var element = await page.EvaluateAsync<JsonElement>(FindFieldScript, new
        {
            labels = labels.ToArray(),
            scope,
            token,
        });

        // Playwright 反序列化自定义类型要求无参构造，这里先取 JSON 再自行映射。
        var result = element.ValueKind == JsonValueKind.Undefined || element.ValueKind == JsonValueKind.Null
            ? null
            : element.Deserialize<FieldMatchDto>();

        return result is null ? null : new FieldMatch(result.found, result.kind, result.tag, result.error, token);
    }

    /// <summary>判断某个字段当前是否在页面上存在（用于等待表单加载完成）。</summary>
    public static async Task<bool> IsFieldPresentAsync(IPage page, IReadOnlyList<string> labels)
    {
        var match = await MarkFieldAsync(page, labels);
        return match is { found: true };
    }

    private static async Task FillTextAsync(
        IPage page,
        EGateSelectors selectors,
        string selector,
        IReadOnlyList<string> values)
    {
        var input = page.Locator(selector);
        await input.FillAsync(values[0], new() { Timeout = selectors.TimeoutMs });
    }

    private static async Task SelectAsync(
        IPage page,
        EGateSelectors selectors,
        string selector,
        string? domKind,
        IReadOnlyList<string> values,
        string displayName)
    {
        var target = page.Locator(selector);

        if (domKind == "select")
        {
            // 原生 select：先读出全部选项，用宽松匹配（编号前缀 / 简繁 / 包含）找到目标后再选。
            var optionTexts = await target.Locator("option").AllTextContentsAsync();
            var index = OptionMatcher.FindBestIndex(optionTexts, values);

            if (index >= 0)
            {
                await target.SelectOptionAsync(
                    new SelectOptionValue { Index = index },
                    new() { Timeout = selectors.TimeoutMs });
                return;
            }

            throw new EGateAutomationException(
                $"「{displayName}」下拉選項中找不到：{string.Join(" / ", values)}（目前選項：{DescribeOptions(optionTexts)}）");
        }

        await target.ClickAsync(new() { Timeout = selectors.TimeoutMs });

        var dropdown = page.Locator(".el-select-dropdown:visible, .el-popper:visible, [role=listbox]:visible");
        await dropdown.First.WaitForAsync(new()
        {
            State = WaitForSelectorState.Visible,
            Timeout = selectors.TimeoutMs,
        });

        var options = page.Locator(
            ".el-select-dropdown__item:visible, [role=option]:visible, .el-select-dropdown li:visible");

        var visibleTexts = await options.AllTextContentsAsync();
        var optionIndex = OptionMatcher.FindBestIndex(visibleTexts, values);

        if (optionIndex < 0)
        {
            // 收起下拉框，避免遮挡后续字段。
            await page.Keyboard.PressAsync("Escape");

            throw new EGateAutomationException(
                $"「{displayName}」下拉選項中找不到：{string.Join(" / ", values)}（目前選項：{DescribeOptions(visibleTexts)}）");
        }

        await options.Nth(optionIndex).ClickAsync(new() { Timeout = selectors.TimeoutMs });
    }

    private static string DescribeOptions(IReadOnlyList<string> options)
    {
        var texts = options
            .Select(text => text.Trim())
            .Where(text => text.Length > 0)
            .Take(12)
            .ToList();

        return texts.Count == 0 ? "無" : string.Join("、", texts);
    }

    /// <summary>字段定位结果。属性名用小写，直接对应页面脚本返回的 JSON。</summary>
    public sealed record FieldMatch(bool found, string? kind, string? tag, string? error, string token);

    private sealed record FieldMatchDto(bool found, string? kind, string? tag, string? error);
}

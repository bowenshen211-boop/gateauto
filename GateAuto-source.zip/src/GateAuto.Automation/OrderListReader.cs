using System.Text.Json;
using GateAuto.Core.Models;
using Microsoft.Playwright;

namespace GateAuto.Automation;

/// <summary>订单列表里识别出的一行。</summary>
public sealed record OrderListRow(
    int RowIndex,
    string ApplyNo,
    IReadOnlyDictionary<string, string> Columns,
    string? DetailLinkText = null);

/// <summary>订单列表识别结果。骨架阶段只负责「读列表」，不点击、不打开详情。</summary>
public sealed record OrderListResult(
    string Url,
    IReadOnlyList<string> Headers,
    IReadOnlyList<OrderListRow> Rows,
    int TotalRows,
    string? Warning = null);

/// <summary>
/// 只读的订单列表识别服务。按平台识别「订单列表页」的行与申请编号，
/// 为后续「自动点开订单读取详情字段」提供定位依据。当前阶段不做点击或跳转。
/// </summary>
public static class OrderListReader
{
    // 关务物流列表页：jQuery EasyUI，原生表格 #task_rw，申请编号是链接。
    private const string CustomsScript = """
        (args) => {
          const clean = value => (value == null ? '' : String(value)).replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
          const table = document.querySelector('#task_rw');
          if (!table) return { headers: [], applyNoIndex: -1, totalRows: 0, rows: [], warning: '找不到列表表格 #task_rw' };

          const headerRow = table.querySelector('thead tr');
          const headers = headerRow
            ? Array.from(headerRow.querySelectorAll('th, td')).map(cell => clean(cell.innerText || cell.textContent))
            : [];
          const applyNoIndex = headers.findIndex(h => /申請編號|申请编号|申請單號|申请单号/.test(clean(h)));
          const headerCount = headers.length;

          const rows = [];
          Array.from(table.querySelectorAll('tbody tr')).forEach(tr => {
            const tds = Array.from(tr.querySelectorAll('th, td'));
            // 跳过占位/合并行（如「無簽核任務！」的 colspan 提示行）。
            if (headerCount > 0 && tds.length < headerCount) return;

            const cells = tds.map(cell => clean(cell.innerText || cell.textContent));
            let linkText = '';
            let linkHref = '';
            if (applyNoIndex >= 0 && applyNoIndex < tds.length) {
              const a = tds[applyNoIndex].querySelector('a');
              if (a) { linkText = clean(a.innerText || a.textContent); linkHref = a.getAttribute('href') || ''; }
            }
            const applyNo = linkText || (applyNoIndex >= 0 && applyNoIndex < cells.length ? cells[applyNoIndex] : '');
            rows.push({ index: rows.length + 1, applyNo, cells, linkText, linkHref });
          });

          return { headers, applyNoIndex, totalRows: rows.length, rows };
        }
        """;

    // 云富通列表页：Ext JS 网格（div 行），列名尚需详情页诊断数据才能映射。
    private const string YunFuTongScript = """
        (args) => {
          const clean = value => (value == null ? '' : String(value)).replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
          const rows = Array.from(document.querySelectorAll('.x-grid-row, .x-grid3-row'));
          const first = rows[0];
          const sampleCells = first
            ? Array.from(first.querySelectorAll('.x-grid-cell, .x-grid3-cell')).map(cell => clean(cell.innerText || cell.textContent))
            : [];
          return { totalRows: rows.length, sampleCells };
        }
        """;

    /// <summary>读取当前页面的订单列表。只读取，不点击、不导航、不修改页面。</summary>
    public static async Task<OrderListResult> ReadAsync(
        IPage page,
        OrderPlatform platform,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(page);
        cancellationToken.ThrowIfCancellationRequested();

        return platform switch
        {
            OrderPlatform.CustomsLogistics => await ReadCustomsAsync(page, cancellationToken),
            OrderPlatform.YunFuTong => await ReadYunFuTongAsync(page, cancellationToken),
            _ => throw new ArgumentOutOfRangeException(nameof(platform), platform, null),
        };
    }

    private static async Task<OrderListResult> ReadCustomsAsync(IPage page, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var element = await page.EvaluateAsync<JsonElement>(CustomsScript);
        var data = element.Deserialize<CustomsRaw>() ?? new CustomsRaw();

        if (!string.IsNullOrWhiteSpace(data.warning))
        {
            return new OrderListResult(page.Url, [], [], 0, data.warning);
        }

        var headers = data.headers ?? [];
        var rows = new List<OrderListRow>();

        foreach (var row in data.rows ?? [])
        {
            var cells = row.cells ?? [];
            var columns = new Dictionary<string, string>(StringComparer.Ordinal);

            for (var i = 0; i < cells.Count; i++)
            {
                var header = i < headers.Count && !string.IsNullOrWhiteSpace(headers[i])
                    ? headers[i]
                    : $"col{i}";
                columns[header] = cells[i];
            }

            rows.Add(new OrderListRow(
                row.index,
                row.applyNo ?? string.Empty,
                columns,
                string.IsNullOrWhiteSpace(row.linkText) ? null : row.linkText));
        }

        return new OrderListResult(page.Url, headers, rows, data.totalRows);
    }

    private static async Task<OrderListResult> ReadYunFuTongAsync(IPage page, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var element = await page.EvaluateAsync<JsonElement>(YunFuTongScript);
        var data = element.Deserialize<YunFuTongRaw>() ?? new YunFuTongRaw();

        var sample = string.Join(" | ", data.sampleCells ?? []);
        var warning = data.totalRows > 0
            ? $"雲富通列表為 Ext JS 網格（{data.totalRows} 行），列名映射需詳情頁診斷數據後補全。首行樣本：{sample}"
            : "未識別到 Ext 網格行（.x-grid-row / .x-grid3-row）。";

        return new OrderListResult(page.Url, [], [], data.totalRows, warning);
    }

    private sealed class CustomsRaw
    {
        public List<string>? headers { get; set; }
        public int applyNoIndex { get; set; } = -1;
        public int totalRows { get; set; }
        public List<CustomsRowRaw>? rows { get; set; }
        public string? warning { get; set; }
    }

    private sealed class CustomsRowRaw
    {
        public int index { get; set; }
        public string? applyNo { get; set; }
        public List<string>? cells { get; set; }
        public string? linkText { get; set; }
        public string? linkHref { get; set; }
    }

    private sealed class YunFuTongRaw
    {
        public int totalRows { get; set; }
        public List<string>? sampleCells { get; set; }
    }
}

namespace GateAuto.Automation;

/// <summary>建单结果：电子闸口回传的放行单号与过程信息。</summary>
public sealed class ShipmentCreationResult
{
    /// <summary>新的 LQE 放行单号，例如 LQE-261132362。</summary>
    public required string LqeNo { get; init; }

    /// <summary>「有來源添加」查询到的明细行数。</summary>
    public int SourceRowCount { get; init; }

    /// <summary>过程中产生的提示（例如可选字段未找到）。</summary>
    public IReadOnlyList<string> Warnings { get; init; } = [];

    /// <summary>实际执行步骤，便于操作人员核对。</summary>
    public IReadOnlyList<string> Steps { get; init; } = [];
}

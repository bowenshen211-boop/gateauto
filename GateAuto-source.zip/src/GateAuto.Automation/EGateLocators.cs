using Microsoft.Playwright;

namespace GateAuto.Automation;

/// <summary>按文字定位与等待的公共逻辑。</summary>
internal static class EGateLocators
{
    /// <summary>
    /// 按文字点击：先找同名按钮，其次链接，最后按文本匹配。
    /// 避免依赖元素 ID 或 XPath。
    /// </summary>
    public static async Task ClickByTextAsync(ILocator scope, string text, float timeoutMs)
    {
        var button = scope.GetByRole(AriaRole.Button, new() { Name = text });
        if (await button.CountAsync() > 0)
        {
            await button.First.ClickAsync(new() { Timeout = timeoutMs });
            return;
        }

        var link = scope.GetByRole(AriaRole.Link, new() { Name = text });
        if (await link.CountAsync() > 0)
        {
            await link.First.ClickAsync(new() { Timeout = timeoutMs });
            return;
        }

        var fallback = scope.GetByText(text, new() { Exact = false });
        if (await fallback.CountAsync() > 0)
        {
            await fallback.First.ClickAsync(new() { Timeout = timeoutMs });
            return;
        }

        throw new EGateAutomationException($"找不到文字為「{text}」的按鈕或連結");
    }

    /// <summary>
    /// 依次尝试多个文字，命中即点击。返回实际点击的文字；全部找不到时抛异常。
    /// 真实系统同一按钮在不同模块可能叫「確認 / 確定」或「修改工具號 / 修改車牌」。
    /// </summary>
    public static async Task<string> ClickAnyByTextAsync(
        ILocator scope,
        IReadOnlyList<string> texts,
        float timeoutMs)
    {
        foreach (var text in texts)
        {
            if (await TryClickByTextAsync(scope, text, timeoutMs))
            {
                return text;
            }
        }

        throw new EGateAutomationException($"找不到任何一個按鈕：{string.Join(" / ", texts)}");
    }

    /// <summary>按文字点击，找不到时返回 false 而不是抛异常。</summary>
    public static async Task<bool> TryClickByTextAsync(ILocator scope, string text, float timeoutMs)
    {
        var targets = new[]
        {
            scope.GetByRole(AriaRole.Button, new() { Name = text }),
            scope.GetByRole(AriaRole.Link, new() { Name = text }),
            scope.GetByText(text, new() { Exact = true }),
            scope.GetByText(text, new() { Exact = false }),
        };

        foreach (var target in targets)
        {
            if (await target.CountAsync() == 0)
            {
                continue;
            }

            var visible = await FirstVisibleAsync(target);
            if (visible is null)
            {
                continue;
            }

            try
            {
                await visible.ClickAsync(new() { Timeout = timeoutMs });
                return true;
            }
            catch (PlaywrightException)
            {
                // 命中了不可点击的文本节点，继续尝试下一个候选。
            }
        }

        return false;
    }

    /// <summary>在候选里取第一个可见元素；没有则返回 null。</summary>
    public static async Task<ILocator?> FirstVisibleAsync(ILocator locator)
    {
        var count = await locator.CountAsync();
        for (var i = 0; i < count; i++)
        {
            var candidate = locator.Nth(i);
            if (await candidate.IsVisibleAsync())
            {
                return candidate;
            }
        }

        return null;
    }

    /// <summary>
    /// 等待弹窗出现：优先 ARIA role=dialog，找不到再退回配置的根选择器。
    /// 标题允许多个候选（真实系统同一弹窗可能叫「修改工具號 / 修改車牌」）。
    /// 两条路径并行轮询，避免真实系统不支援 ARIA 时白等一整个超时。
    /// </summary>
    public static async Task<ILocator> WaitForDialogAsync(
        IPage page,
        EGateSelectors selectors,
        IReadOnlyList<string> titles,
        TimeSpan timeout)
    {
        var deadline = DateTime.UtcNow + timeout;

        while (DateTime.UtcNow < deadline)
        {
            foreach (var title in titles)
            {
                var byRole = page.GetByRole(AriaRole.Dialog).Filter(new() { HasText = title });
                var found = await FirstVisibleAsync(byRole);
                if (found is not null)
                {
                    return found;
                }

                var bySelector = page.Locator(selectors.DialogRootSelector).Filter(new() { HasText = title });
                found = await FirstVisibleAsync(bySelector);
                if (found is not null)
                {
                    return found;
                }
            }

            await Task.Delay(100);
        }

        throw new EGateAutomationException($"等待弹窗「{string.Join(" / ", titles)}」逾時（{timeout.TotalSeconds:0} 秒）");
    }

    /// <summary>等待弹窗关闭。</summary>
    public static async Task WaitHiddenAsync(ILocator root, TimeSpan timeout)
    {
        var deadline = DateTime.UtcNow + timeout;

        while (DateTime.UtcNow < deadline)
        {
            try
            {
                if (!await root.IsVisibleAsync())
                {
                    return;
                }
            }
            catch (PlaywrightException)
            {
                // 元素被移除也算关闭。
                return;
            }

            await Task.Delay(100);
        }

        throw new EGateAutomationException($"弹窗未關閉（{timeout.TotalSeconds:0} 秒）");
    }

    /// <summary>等待首个可见行出现，返回可见行数；逾时抛异常。</summary>
    public static async Task<int> WaitForRowsAsync(ILocator rows, TimeSpan timeout, string failureMessage)
    {
        var deadline = DateTime.UtcNow + timeout;

        while (DateTime.UtcNow < deadline)
        {
            if (await FirstVisibleAsync(rows) is not null)
            {
                return await rows.CountAsync();
            }

            await Task.Delay(200);
        }

        throw new EGateAutomationException(failureMessage);
    }
}

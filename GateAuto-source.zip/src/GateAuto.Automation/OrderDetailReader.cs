using System.Globalization;
using System.Text.Json;
using System.Text.RegularExpressions;
using GateAuto.Core.Models;
using Microsoft.Playwright;

namespace GateAuto.Automation;

/// <summary>详情页读取的原始事实（DOM 直接读出，未做任何规则判定）。</summary>
public sealed record OrderDetailResult(
    string Url,
    IReadOnlyDictionary<string, string> Labels,
    IReadOnlyDictionary<string, IReadOnlyList<string>> Matches);

/// <summary>
/// 只读的订单详情读取服务：把「订单详情页」的 DOM 映射成 <see cref="OrderInfo"/>。
/// 采用「集中式字段映射表 + 标签文本定位 JS 脚本 + 全文正则兜底」三层结构：
/// 明天日志确认字段名后，只需改下方 <see cref="LabelMap"/> / <see cref="TextMap"/>，不动脚本骨架。
/// </summary>
public static class OrderDetailReader
{
    // =====================================================================
    // 集中式字段映射表。每个平台的标签用正则（忽略大小写）匹配「标签单元格」，
    // 取它紧邻的值；全文正则用于提取来源单号、备注里的装货地址等无固定标签的内容。
    // TODO（待日志确认）：装货/卸货/送货地址的精确字段名与取值方式。
    // =====================================================================

    private const string ApplyNoKey = "applyNo";
    private const string VendorCodeKey = "vendorCode";
    private const string PackageCountKey = "packageCount";
    private const string GrossWeightKgKey = "grossWeightKg";
    private const string NetWeightKgKey = "netWeightKg";
    private const string PackingMethodKey = "packingMethod";
    private const string ConsigneeKey = "consignee";
    private const string LoadingAddressKey = "loadingAddress";
    private const string DeliveryAddressKey = "deliveryAddress";
    private const string UnloadAddressKey = "unloadAddress";

    private const string SourceNosKey = "sourceNos";
    private const string LoadingAddressTextKey = "loadingAddressText";

    private static readonly IReadOnlyDictionary<OrderPlatform, IReadOnlyList<LabelRule>> LabelMap =
        new Dictionary<OrderPlatform, IReadOnlyList<LabelRule>>
        {
            [OrderPlatform.CustomsLogistics] =
            [
                new(ApplyNoKey, "需求[单單][号號]"),
                new(VendorCodeKey, "廠商代碼|厂商代码"),
                new(PackageCountKey, "包裝件數|包装件数|件數|件数"),   // 件数 = 包装件数，绝不能取「数量」
                new(GrossWeightKgKey, "毛重"),
                new(NetWeightKgKey, "淨重|净重"),
                new(PackingMethodKey, "包裝方式|包装方式"),
                new(ConsigneeKey, "收貨方|收货方"),
                new(LoadingAddressKey, "裝貨地址|装货地址"),            // TODO 日志确认字段名
                new(DeliveryAddressKey, "送貨地址|送货地址"),            // TODO 日志确认字段名
                new(UnloadAddressKey, "卸貨地址|卸货地址"),              // TODO 日志确认字段名
            ],
            [OrderPlatform.YunFuTong] =
            [
                new(ApplyNoKey, "申請單號|申请单号|單號|单号"),          // 云富通单号 = XJ 前缀
                new(VendorCodeKey, "廠商代碼|厂商代码"),
                new(PackageCountKey, "包裝件數|包装件数|件數|件数"),   // 件数 = 包装件数，绝不能取「数量」
                new(GrossWeightKgKey, "毛重"),
                new(NetWeightKgKey, "淨重|净重"),
                new(PackingMethodKey, "包裝方式|包装方式"),
                new(ConsigneeKey, "收貨方|收货方"),
                new(LoadingAddressKey, "存放地點|存放地点|裝貨地址|装货地址"), // TODO 日志确认字段名
            ],
        };

    private static readonly IReadOnlyDictionary<OrderPlatform, IReadOnlyList<TextRule>> TextMap =
        new Dictionary<OrderPlatform, IReadOnlyList<TextRule>>
        {
            // 来源单号（5CS-xxx / UCJ-xxx / UCN-xxx）藏在备注文本里，全文正则兜底提取。
            [OrderPlatform.CustomsLogistics] =
            [
                new(SourceNosKey, @"(?:5CS|UCJ|UCN)-[A-Za-z0-9]+", Global: true, Group: 0),
                new(LoadingAddressTextKey, @"存放地[点點]\s*[:：]?\s*([^\s,，。；;]+)", Global: false, Group: 1),
            ],
            [OrderPlatform.YunFuTong] =
            [
                new(SourceNosKey, @"(?:5CS|UCJ|UCN)-[A-Za-z0-9]+", Global: true, Group: 0),
                new(LoadingAddressTextKey, @"存放地[点點]\s*[:：]?\s*([^\s,，。；;]+)", Global: false, Group: 1),
            ],
        };

    private const string ExtractScript = """
        (args) => {
          const norm = value => (value == null ? '' : String(value)).replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
          const labels = {};
          const matches = {};

          const valueOf = el => {
            if (el.matches('input, select, textarea')) return norm(el.value);
            if (el.tagName === 'LABEL' && el.htmlFor) {
              const target = document.getElementById(el.htmlFor);
              if (target) {
                const v = target.matches('input, select, textarea') ? norm(target.value) : norm(target.innerText || target.textContent);
                if (v) return v;
              }
            }
            const container = el.closest('tr, .x-form-item, .form-item, .el-form-item, .x-grid-row, li');
            if (container) {
              const control = container.querySelector('input, select, textarea');
              if (control) { const v = norm(control.value); if (v) return v; }
            }
            const next = el.nextElementSibling;
            if (next && (next.tagName === 'TD' || next.tagName === 'DD')) {
              const v = norm(next.innerText || next.textContent);
              if (v) return v;
            }
            const text = norm(el.innerText || el.textContent);
            const colon = text.search(/[:：]/);
            if (colon > 0) {
              const v = norm(text.slice(colon + 1));
              if (v) return v;
            }
            return '';
          };

          const candidates = Array.from(document.querySelectorAll('th, td, label, dt, span, div, li'));
          args.labels.forEach(rule => {
            const regexes = rule.patterns.map(p => new RegExp(p, 'i'));
            for (const el of candidates) {
              const labelText = norm(el.innerText || el.textContent);
              if (!labelText || labelText.length > 60) continue;
              if (!regexes.some(re => re.test(labelText))) continue;
              const value = valueOf(el);
              if (value) { labels[rule.key] = value; break; }
            }
          });

          const fullText = norm(document.body ? (document.body.innerText || document.body.textContent || '') : '');
          args.texts.forEach(rule => {
            const re = new RegExp(rule.pattern, rule.global ? 'gi' : 'i');
            const found = [];
            if (rule.global) {
              let m;
              while ((m = re.exec(fullText)) !== null) {
                const v = norm(rule.group > 0 ? m[rule.group] : m[0]);
                if (v && !found.includes(v)) found.push(v);
              }
            } else {
              const m = re.exec(fullText);
              const v = m ? norm(rule.group > 0 ? m[rule.group] : m[0]) : '';
              if (v) found.push(v);
            }
            matches[rule.key] = found;
          });

          return JSON.stringify({ labels, matches });
        }
        """;

    /// <summary>读取当前详情页并映射成订单。只读取，不点击、不导航、不修改页面。</summary>
    public static async Task<OrderInfo> ReadAsync(
        IPage page,
        OrderPlatform platform,
        string? listApplyNo = null,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(page);
        cancellationToken.ThrowIfCancellationRequested();

        var raw = await ExtractAsync(page, platform, cancellationToken);
        return Map(raw, platform, listApplyNo);
    }

    /// <summary>把详情页的原始读取结果映射成 <see cref="OrderInfo"/>（纯函数，便于测试）。</summary>
    public static OrderInfo Map(OrderDetailResult raw, OrderPlatform platform, string? listApplyNo = null)
    {
        ArgumentNullException.ThrowIfNull(raw);

        var labels = raw.Labels;
        string Label(string key) => labels.TryGetValue(key, out var value) ? value.Trim() : string.Empty;
        string FirstMatch(string key) => raw.Matches.TryGetValue(key, out var list) && list.Count > 0 ? list[0] : string.Empty;
        IReadOnlyList<string> Matches(string key) => raw.Matches.TryGetValue(key, out var list) ? list : [];

        var sourceNos = Matches(SourceNosKey);

        var loadingAddress = FirstNonEmpty(Label(LoadingAddressKey), FirstMatch(LoadingAddressTextKey));

        var applyNo = FirstNonEmpty(Label(ApplyNoKey));
        if (string.IsNullOrWhiteSpace(applyNo))
        {
            applyNo = listApplyNo?.Trim() ?? string.Empty;
        }

        return new OrderInfo
        {
            Platform = platform,
            ApplyNo = applyNo,
            SourceNos = sourceNos,
            VendorCode = Label(VendorCodeKey),
            PackageCount = ParseInt(Label(PackageCountKey)),
            GrossWeightKg = ParseDecimal(Label(GrossWeightKgKey)),
            NetWeightKg = ParseDecimal(Label(NetWeightKgKey)),
            PackingMethod = Label(PackingMethodKey),
            Consignee = Label(ConsigneeKey),
            LoadingAddress = loadingAddress,
            DeliveryAddress = Label(DeliveryAddressKey),
            UnloadAddress = Label(UnloadAddressKey),
            // TODO：目的地（待派车清单显示用）来源字段尚未确认，先留空，回退逻辑在 OrderCreationWorkflow 里已有。
            Destination = string.Empty,
        };
    }

    private static async Task<OrderDetailResult> ExtractAsync(
        IPage page,
        OrderPlatform platform,
        CancellationToken cancellationToken)
    {
        var labelRules = LabelMap[platform];
        var textRules = TextMap[platform];

        var arg = new
        {
            labels = labelRules.Select(r => new { key = r.Key, patterns = r.Patterns }).ToArray(),
            texts = textRules.Select(r => new { key = r.Key, pattern = r.Pattern, global = r.Global, group = r.Group }).ToArray(),
        };

        var json = await page.EvaluateAsync<string>(ExtractScript, arg);
        var data = JsonSerializer.Deserialize<DetailRaw>(json) ?? new DetailRaw();

        var labels = new Dictionary<string, string>(StringComparer.Ordinal);
        foreach (var pair in data.labels ?? [])
        {
            labels[pair.Key] = pair.Value ?? string.Empty;
        }

        var matches = new Dictionary<string, IReadOnlyList<string>>(StringComparer.Ordinal);
        foreach (var pair in data.matches ?? [])
        {
            matches[pair.Key] = pair.Value ?? [];
        }

        return new OrderDetailResult(page.Url, labels, matches);
    }

    private static string FirstNonEmpty(params string?[] values)
        => values.FirstOrDefault(value => !string.IsNullOrWhiteSpace(value)) ?? string.Empty;

    private static int ParseInt(string raw)
    {
        if (string.IsNullOrWhiteSpace(raw))
        {
            return 0;
        }

        var cleaned = Regex.Replace(raw, @"[^\d-]", string.Empty);
        return int.TryParse(cleaned, NumberStyles.Integer, CultureInfo.InvariantCulture, out var value) ? value : 0;
    }

    private static decimal ParseDecimal(string raw)
    {
        if (string.IsNullOrWhiteSpace(raw))
        {
            return 0m;
        }

        var cleaned = Regex.Replace(raw, @"[^\d.\-]", string.Empty);
        return decimal.TryParse(cleaned, NumberStyles.Number, CultureInfo.InvariantCulture, out var value) ? value : 0m;
    }

    private sealed record LabelRule(string Key, string Pattern)
    {
        public string[] Patterns { get; } = [Pattern];
    }

    private sealed record TextRule(string Key, string Pattern, bool Global, int Group);

    private sealed class DetailRaw
    {
        public Dictionary<string, string>? labels { get; set; }
        public Dictionary<string, List<string>>? matches { get; set; }
    }
}

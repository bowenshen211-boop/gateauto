using Microsoft.Playwright;

namespace GateAuto.Automation;

/// <summary>
/// 「修改車牌」弹窗。流程：点修改车牌 → 输入车牌 → 确定。
/// 车牌由独立流程处理，不参与建单。
/// </summary>
public sealed class PlateEditDialog
{
    private readonly ILocator _root;
    private readonly EGateSelectors _selectors;

    private PlateEditDialog(ILocator root, EGateSelectors selectors)
    {
        _root = root;
        _selectors = selectors;
    }

    /// <summary>按放行单号定位列表行，点击该行的「修改車牌」并等待弹窗出现。</summary>
    public static async Task<PlateEditDialog> OpenFromRowAsync(IPage page, string lqeNo, EGateSelectors? selectors = null)
    {
        ArgumentNullException.ThrowIfNull(page);
        ArgumentException.ThrowIfNullOrWhiteSpace(lqeNo);

        var options = selectors ?? new EGateSelectors();

        var rows = page.Locator(options.RowSelector).Filter(new() { HasText = lqeNo });
        var row = await EGateLocators.FirstVisibleAsync(rows)
            ?? throw new EGateAutomationException($"列表中找不到放行單號 {lqeNo} 的資料列");

        await EGateLocators.ClickAnyByTextAsync(row, options.EditPlateButtonTexts, options.TimeoutMs);

        return await AttachAsync(page, options);
    }

    /// <summary>弹窗已经被人工点开时，直接接管。</summary>
    public static async Task<PlateEditDialog> AttachAsync(IPage page, EGateSelectors? selectors = null)
    {
        ArgumentNullException.ThrowIfNull(page);

        var options = selectors ?? new EGateSelectors();
        var root = await EGateLocators.WaitForDialogAsync(page, options, options.EditPlateDialogTitles, options.Timeout);

        return new PlateEditDialog(root, options);
    }

    /// <summary>填入车牌并确定，等待弹窗关闭。</summary>
    public async Task UpdatePlateAsync(string plateNo)
    {
        if (string.IsNullOrWhiteSpace(plateNo))
        {
            throw new EGateAutomationException("車牌號不可為空");
        }

        var input = await EGateLocators.FirstVisibleAsync(_root.Locator(_selectors.PlateInputSelector))
            ?? throw new EGateAutomationException("弹窗内找不到車牌號輸入框");

        await input.FillAsync(plateNo.Trim(), new() { Timeout = _selectors.TimeoutMs });
        await EGateLocators.ClickAnyByTextAsync(_root, _selectors.ConfirmButtonTexts, _selectors.TimeoutMs);
        await EGateLocators.WaitHiddenAsync(_root, _selectors.Timeout);
    }
}

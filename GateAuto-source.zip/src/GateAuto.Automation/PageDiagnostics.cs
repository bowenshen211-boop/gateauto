using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.Playwright;

namespace GateAuto.Automation;

/// <summary>一次网页诊断的读取结果。</summary>
public sealed record PageDiagnosticResult(
    string Command,
    string Url,
    string Content,
    string? ScreenshotPath = null,
    string? SavedHtmlPath = null);

/// <summary>
/// 固定只读网页诊断命令。用户只能提供命令与 CSS 作用域，不能注入 JavaScript，
/// 也不会点击、导航、填写或提交页面。
/// </summary>
public static class PageDiagnostics
{
    private const int MaxItems = 100;
    private const int MaxValueLength = 2000;
    private const int MaxContentLength = 2 * 1024 * 1024;
    private const int MaxPreviewLength = 32 * 1024;
    private const int MaxHtmlFileLength = 64 * 1024 * 1024;

    public const string HelpText = """
        固定只读命令（不会修改网页）：
          page                    当前 URL、标题、打开页数量
          snapshot [CSS]          汇总页面、字段、按钮、表格与链接
          text [CSS]              可见文本，默认 body
          fields [CSS]            输入框、下拉框及其标签和值
          buttons [CSS]           按钮文字、可见与可用状态
          tables [CSS]            表头、行号与单元格，适合订单列表诊断
          links [CSS]             链接文本与 href
          html [CSS]              指定元素 outerHTML，默认 body
          savehtml [CSS]          把指定元素（默认整页）的 HTML 存档，便于离线分析
          screenshot              保存当前视口 PNG，密码框会遮盖
          clear                   清空控制台输出（不删除日志）
          help                    显示本说明

        示例：tables #order-list、fields form、text .el-table。
        每条命令最多 100 项；敏感信息会脱敏，订单号等业务数据保留。
        """;

    private static readonly Regex HtmlSensitiveRegex = new(
        "(?i)(?<prefix>\\b[A-Za-z0-9_.-]*(?:password|pass|token|cookie|secret|authorization)[A-Za-z0-9_.-]*\\s*=\\s*)(?<q>['\"])(?<value>.*?)\\k<q>",
        RegexOptions.Compiled | RegexOptions.Singleline);

    private static readonly Regex QuerySensitiveRegex = new(
        "(?i)(?<prefix>[?&][^=&#\\s]*(?:password|pass|token|cookie|secret|authorization)[^=&#\\s]*=)(?<value>[^&#\\s]*)",
        RegexOptions.Compiled);

    private static readonly Regex PlainSensitiveRegex = new(
        "(?i)(?<prefix>\\b[A-Za-z0-9_.-]*(?:password|pass|token|cookie|secret|authorization)[A-Za-z0-9_.-]*\\s*=\\s*)(?<value>[^&\\s;<>'\"]+)",
        RegexOptions.Compiled);

    private static readonly Regex SensitiveNameRegex = new(
        "(?i)(?:password|pass|token|cookie|secret|authorization)",
        RegexOptions.Compiled);

    /// <summary>整页/指定区域的 HTML 快照脚本：克隆节点，密码类字段一律遮盖，原页面不受影响。</summary>
    private const string SaveHtmlScript = """
        (args) => {
          const scope = args.scope;
          let root;
          if (!scope) {
            root = document.documentElement;
          } else {
            try {
              root = document.querySelector(scope);
            } catch {
              return { error: '無效 CSS 作用域：' + scope, html: '' };
            }
          }
          if (!root) return { error: 'CSS 作用域找不到元素：' + scope, html: '' };

          const copy = root.cloneNode(true);
          const originalFields = [];
          if (root.matches('input, select, textarea')) originalFields.push(root);
          originalFields.push(...root.querySelectorAll('input, select, textarea'));
          const copiedFields = [];
          if (copy.matches('input, select, textarea')) copiedFields.push(copy);
          copiedFields.push(...copy.querySelectorAll('input, select, textarea'));

          originalFields.forEach((field, index) => {
            const identity = `${field.getAttribute('name') || ''} ${field.id || ''} ${field.getAttribute('type') || ''}`;
            if (!/password|pass|token|cookie|secret|authorization/i.test(identity)) return;
            if (field.tagName === 'INPUT') copiedFields[index].setAttribute('value', '***');
            else copiedFields[index].innerHTML = '***';
          });

          // 移除脚本，存档离线打开时不会执行原页面逻辑。
          copy.querySelectorAll('script').forEach(script => script.remove());

          return { error: null, html: (scope ? '' : '<!DOCTYPE html>\n') + copy.outerHTML };
        }
        """;

    private const string ExtractScript = """
        (args) => {
          const result = (items, total, error = null) => ({ error, total, items });
          const kind = args.kind;
          let root;
          try {
            root = document.querySelector(args.scope || 'body');
          } catch {
            return result([], 0, '無效 CSS 作用域：' + args.scope);
          }
          if (!root) return result([], 0, 'CSS 作用域找不到元素：' + args.scope);

          const clean = value => (value == null ? '' : String(value)).replace(/\u00a0/g, ' ').trim();
          const norm = value => clean(value).replace(/\s+/g, ' ');
          const visible = el => !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
          const identity = el => ({
            tag: el.tagName.toLowerCase(),
            id: el.id || '',
            name: el.getAttribute('name') || '',
            type: el.getAttribute('type') || '',
            placeholder: el.getAttribute('placeholder') || '',
            className: String(el.className || ''),
            visible: visible(el),
          });
          const labelOf = el => {
            const aria = el.getAttribute('aria-label');
            if (aria) return norm(aria);
            if (el.id) {
              const label = document.querySelector(`label[for="${CSS.escape(el.id)}"]`);
              if (label) return norm(label.innerText || label.textContent);
            }
            const wrapping = el.closest('label');
            if (wrapping) return norm(wrapping.innerText || wrapping.textContent);
            const item = el.closest('.el-form-item');
            const itemLabel = item && item.querySelector('.el-form-item__label, label');
            return itemLabel ? norm(itemLabel.innerText || itemLabel.textContent) : '';
          };

          if (kind === 'text') {
            return result([{ text: clean(root.innerText || root.textContent) }], 1);
          }
          if (kind === 'html') {
            const copy = root.cloneNode(true);
            const originalFields = [];
            if (root.matches('input, select, textarea')) originalFields.push(root);
            originalFields.push(...root.querySelectorAll('input, select, textarea'));
            const copiedFields = [];
            if (copy.matches('input, select, textarea')) copiedFields.push(copy);
            copiedFields.push(...copy.querySelectorAll('input, select, textarea'));
            originalFields.forEach((field, index) => {
              const identity = `${field.getAttribute('name') || ''} ${field.id || ''} ${field.getAttribute('type') || ''}`;
              if (!/password|pass|token|cookie|secret|authorization/i.test(identity)) return;
              if (field.tagName === 'INPUT') copiedFields[index].setAttribute('value', '***');
              else copiedFields[index].innerHTML = '***';
            });
            return result([{ text: copy.outerHTML }], 1);
          }

          const selectors = {
            fields: 'input, select, textarea',
            buttons: 'button, input[type="button"], input[type="submit"], [role="button"]',
            tables: 'table',
            links: 'a[href]',
          };
          const selector = selectors[kind];
          if (!selector) return result([], 0, '不支援的讀取類型：' + kind);

          const elements = [];
          if (root.matches(selector)) elements.push(root);
          elements.push(...root.querySelectorAll(selector));
          const total = elements.length;

          const items = elements.slice(0, args.limit).map(el => {
            const item = identity(el);
            if (kind === 'fields') {
              return { ...item, label: labelOf(el), value: el.value == null ? '' : String(el.value) };
            }
            if (kind === 'buttons') {
              return {
                ...item,
                text: norm(el.innerText || el.value || el.textContent),
                enabled: !el.disabled && el.getAttribute('aria-disabled') !== 'true',
              };
            }
            if (kind === 'links') {
              return {
                ...item,
                text: norm(el.innerText || el.textContent),
                href: el.getAttribute('href') || '',
              };
            }

            const allRows = Array.from(el.querySelectorAll('tr'));
            const headerRow = el.querySelector('thead tr');
            const headers = headerRow
              ? Array.from(headerRow.querySelectorAll('th, td')).map(cell => norm(cell.innerText || cell.textContent))
              : [];
            const bodyRows = allRows.filter(row => !headerRow || row !== headerRow);
            return {
              ...item,
              headers,
              totalRows: bodyRows.length,
              rows: bodyRows.slice(0, args.limit).map((row, index) => ({
                index: index + 1,
                cells: Array.from(row.querySelectorAll('th, td')).map(cell => norm(cell.innerText || cell.textContent)),
              })),
            };
          });

          return result(items, total);
        }
        """;

    public static string Preview(string content)
    {
        ArgumentNullException.ThrowIfNull(content);
        return Truncate(content, MaxPreviewLength);
    }

    public static async Task<PageDiagnosticResult> ExecuteAsync(
        IPage page,
        string input,
        string diagnosticDirectory,
        IReadOnlyList<string>? sensitiveValues = null,
        CancellationToken cancellationToken = default,
        string? target = null)
    {
        ArgumentNullException.ThrowIfNull(page);
        ArgumentException.ThrowIfNullOrWhiteSpace(input);
        ArgumentException.ThrowIfNullOrWhiteSpace(diagnosticDirectory);

        var (command, scope) = Parse(input);
        var secrets = sensitiveValues ?? [];

        try
        {
            cancellationToken.ThrowIfCancellationRequested();
            var url = Sanitize(page.Url, secrets);

            if (command == "help")
            {
                return new PageDiagnosticResult(command, url, HelpText);
            }

            if (command == "clear")
            {
                throw new ArgumentException("clear 由控制台界面處理，不需要讀取網頁。");
            }

            if (command == "screenshot")
            {
                var path = await CaptureScreenshotAsync(page, diagnosticDirectory, target, cancellationToken);
                return new PageDiagnosticResult(command, url, $"截圖已保存：{path}", path);
            }

            if (command == "savehtml")
            {
                var (path, length) = await SaveHtmlAsync(
                    page,
                    scope,
                    diagnosticDirectory,
                    target,
                    secrets,
                    cancellationToken);
                return new PageDiagnosticResult(
                    command,
                    url,
                    $"HTML 已保存：{path}（{length:N0} 字元）",
                    SavedHtmlPath: path);
            }

            if (command == "page")
            {
                var content = await PageSummaryAsync(page, secrets);
                return new PageDiagnosticResult(command, url, content);
            }

            if (command == "snapshot")
            {
                var content = await SnapshotAsync(page, scope, secrets, cancellationToken);
                return new PageDiagnosticResult(command, url, content);
            }

            var extracted = await ExtractAsync(page, command, scope);
            var raw = command is "text" or "html"
                ? RawText(command, extracted)
                : FormatItems(command, extracted, secrets);

            return new PageDiagnosticResult(
                command,
                url,
                Truncate(Sanitize(raw, secrets), MaxContentLength));
        }
        catch (PlaywrightException ex)
        {
            throw new InvalidOperationException("頁面已關閉或正在跳轉，請稍後重試。", ex);
        }
    }

    private static (string Command, string Scope) Parse(string input)
    {
        var trimmed = input.Trim();
        var separator = trimmed.IndexOfAny([' ', '\t', '\r', '\n']);
        var command = (separator < 0 ? trimmed : trimmed[..separator]).ToLowerInvariant();
        var scope = separator < 0 ? string.Empty : trimmed[(separator + 1)..].Trim();

        var known = command is "help" or "clear" or "page" or "snapshot" or "text"
            or "fields" or "buttons" or "tables" or "links" or "html" or "savehtml" or "screenshot";
        if (!known)
        {
            throw new ArgumentException($"未知命令：{command}。請輸入 help 查看可用只讀命令。");
        }

        if (scope.Length > 0 && command is "page" or "screenshot" or "help" or "clear")
        {
            throw new ArgumentException($"{command} 不接受 CSS 作用域或額外參數。");
        }

        // savehtml 不給作用域時保存整份文件（含 html/head），其餘命令預設 body。
        if (scope.Length == 0)
        {
            return (command, command == "savehtml" ? string.Empty : "body");
        }

        return (command, scope);
    }

    private static async Task<string> PageSummaryAsync(IPage page, IReadOnlyList<string> secrets)
    {
        var title = await page.TitleAsync();
        var openPages = page.Context.Pages.Count(candidate => !candidate.IsClosed);
        var content = $"命令: page{Environment.NewLine}" +
                      $"URL: {page.Url}{Environment.NewLine}" +
                      $"標題: {title}{Environment.NewLine}" +
                      $"打開頁數: {openPages}";
        return Truncate(Sanitize(content, secrets), MaxContentLength);
    }

    private static async Task<string> SnapshotAsync(
        IPage page,
        string scope,
        IReadOnlyList<string> secrets,
        CancellationToken cancellationToken)
    {
        var output = new StringBuilder(await PageSummaryAsync(page, secrets));
        output.AppendLine().AppendLine($"作用域: {scope}");

        foreach (var kind in new[] { "fields", "buttons", "tables", "links" })
        {
            cancellationToken.ThrowIfCancellationRequested();
            output.AppendLine().AppendLine($"===== {kind} =====");
            var extracted = await ExtractAsync(page, kind, scope, 25);
            output.AppendLine(FormatItems(kind, extracted, secrets));
        }

        return Truncate(Sanitize(output.ToString(), secrets), MaxContentLength);
    }

    private static async Task<ExtractionResult> ExtractAsync(IPage page, string kind, string scope, int limit = MaxItems)
    {
        var element = await page.EvaluateAsync<JsonElement>(ExtractScript, new { kind, scope, limit });
        var result = element.Deserialize<ExtractionResult>() ?? new ExtractionResult();
        if (!string.IsNullOrWhiteSpace(result.error))
        {
            throw new ArgumentException(result.error);
        }

        return result;
    }

    private static string RawText(string command, ExtractionResult result)
    {
        var value = result.items.FirstOrDefault()?.text ?? string.Empty;
        return $"命令: {command}{Environment.NewLine}{Truncate(value, MaxValueLength)}";
    }

    private static string FormatItems(string kind, ExtractionResult result, IReadOnlyList<string> secrets)
    {
        var output = new StringBuilder();
        output.AppendLine($"項目: {result.items.Count} / {result.total}");

        for (var i = 0; i < result.items.Count; i++)
        {
            var item = result.items[i];
            var number = i + 1;

            if (kind == "fields")
            {
                var value = SensitiveNameRegex.IsMatch($"{item.name} {item.id} {item.type}")
                    ? "***"
                    : Truncate(item.value ?? string.Empty, MaxValueLength);
                output.AppendLine(
                    $"[{number}] label={Value(item.label)} | tag={item.tag} | id={Value(item.id)} | name={Value(item.name)}" +
                    $" | type={Value(item.type)} | placeholder={Value(item.placeholder)} | visible={item.visible} | value={value}");
                continue;
            }

            if (kind == "buttons")
            {
                output.AppendLine(
                    $"[{number}] text={Value(Truncate(item.text, MaxValueLength))} | id={Value(item.id)}" +
                    $" | visible={item.visible} | enabled={item.enabled}");
                continue;
            }

            if (kind == "links")
            {
                output.AppendLine(
                    $"[{number}] text={Value(Truncate(item.text, MaxValueLength))} | href={Value(Truncate(item.href, MaxValueLength))}" +
                    $" | id={Value(item.id)} | visible={item.visible}");
                continue;
            }

            output.AppendLine(
                $"[{number}] table id={Value(item.id)} | class={Value(item.className)}" +
                $" | rows={item.rows?.Count ?? 0}/{item.totalRows} | visible={item.visible}");
            if (item.headers is { Count: > 0 })
            {
                output.AppendLine("  表頭: " + string.Join(" | ", item.headers.Select(header => Truncate(header, MaxValueLength))));
            }

            foreach (var row in item.rows ?? [])
            {
                output.AppendLine(
                    $"  列 {row.index}: " + string.Join(" | ", row.cells.Select(cell => Truncate(cell, MaxValueLength))));
            }
        }

        if (result.total > result.items.Count)
        {
            output.AppendLine($"[項目數已截斷：另有 {result.total - result.items.Count} 項未顯示]");
        }

        return Sanitize(output.ToString(), secrets);
    }

    private static string Value(string? value)
        => string.IsNullOrWhiteSpace(value) ? "-" : value;

    private static async Task<(string Path, int Length)> SaveHtmlAsync(
        IPage page,
        string scope,
        string diagnosticDirectory,
        string? target,
        IReadOnlyList<string> secrets,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();

        var element = await page.EvaluateAsync<JsonElement>(SaveHtmlScript, new { scope });
        var data = element.Deserialize<SaveHtmlRaw>() ?? new SaveHtmlRaw();
        if (!string.IsNullOrWhiteSpace(data.error))
        {
            throw new ArgumentException(data.error);
        }

        var html = Sanitize(data.html ?? string.Empty, secrets);
        if (html.Length > MaxHtmlFileLength)
        {
            throw new InvalidOperationException($"頁面 HTML 過大（{html.Length:N0} 字元），已停止保存。");
        }

        var directory = Path.Combine(diagnosticDirectory, "html");
        Directory.CreateDirectory(directory);

        var safeTarget = Regex.Replace(string.IsNullOrWhiteSpace(target) ? "page" : target, "[^A-Za-z0-9_-]", "_");
        var scopeTag = string.IsNullOrWhiteSpace(scope)
            ? "full"
            : Regex.Replace(scope, "[^A-Za-z0-9_-]", "_");
        var path = Path.Combine(
            directory,
            $"{DateTime.Now:yyyyMMdd-HHmmss-fff}-{safeTarget}-{scopeTag}.html");

        await File.WriteAllTextAsync(path, html, new UTF8Encoding(false), cancellationToken);
        return (path, html.Length);
    }

    private static async Task<string> CaptureScreenshotAsync(
        IPage page,
        string diagnosticDirectory,
        string? target,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var directory = Path.Combine(diagnosticDirectory, "screenshots");
        Directory.CreateDirectory(directory);

        var safeTarget = Regex.Replace(string.IsNullOrWhiteSpace(target) ? "page" : target, "[^A-Za-z0-9_-]", "_");
        var path = Path.Combine(directory, $"{DateTime.Now:yyyyMMdd-HHmmss-fff}-{safeTarget}-screenshot.png");

        await page.ScreenshotAsync(new()
        {
            Path = path,
            FullPage = false,
            Mask = [page.Locator("input[type='password']")],
        });

        return path;
    }

    private static string Sanitize(string text, IReadOnlyList<string> secrets)
    {
        var sanitized = text;
        foreach (var secret in secrets.Where(value => !string.IsNullOrWhiteSpace(value)).OrderByDescending(value => value.Length))
        {
            sanitized = sanitized.Replace(secret, "***", StringComparison.Ordinal);
        }

        sanitized = HtmlSensitiveRegex.Replace(sanitized, match =>
            match.Groups["prefix"].Value + match.Groups["q"].Value + "***" + match.Groups["q"].Value);
        sanitized = QuerySensitiveRegex.Replace(sanitized, match => match.Groups["prefix"].Value + "***");
        sanitized = PlainSensitiveRegex.Replace(sanitized, match => match.Groups["prefix"].Value + "***");
        return sanitized;
    }

    private static string Truncate(string? text, int limit)
    {
        if (string.IsNullOrEmpty(text) || text.Length <= limit)
        {
            return text ?? string.Empty;
        }

        var marker = $"{Environment.NewLine}...[已截斷，原始 {text.Length:N0} 字元]";
        return text[..(limit - marker.Length)] + marker;
    }

    private sealed class ExtractionResult
    {
        public string? error { get; set; }
        public int total { get; set; }
        public List<ExtractedItem> items { get; set; } = [];
    }

    private sealed class ExtractedItem
    {
        public string? tag { get; set; }
        public string? id { get; set; }
        public string? name { get; set; }
        public string? type { get; set; }
        public string? placeholder { get; set; }
        public string? className { get; set; }
        public string? label { get; set; }
        public string? value { get; set; }
        public string? text { get; set; }
        public string? href { get; set; }
        public bool visible { get; set; }
        public bool enabled { get; set; }
        public List<string>? headers { get; set; }
        public List<ExtractedRow>? rows { get; set; }
        public int totalRows { get; set; }
    }

    private sealed class ExtractedRow
    {
        public int index { get; set; }
        public List<string> cells { get; set; } = [];
    }

    private sealed class SaveHtmlRaw
    {
        public string? error { get; set; }
        public string? html { get; set; }
    }
}

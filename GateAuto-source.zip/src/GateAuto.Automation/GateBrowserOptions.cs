namespace GateAuto.Automation;

/// <summary>浏览器启动参数。默认使用本机已安装的 Edge，并持久化用户资料目录以复用登录状态。</summary>
public sealed class GateBrowserOptions
{
    /// <summary>Playwright 的浏览器通道：msedge / chrome；留空表示用 Playwright 自带 Chromium。</summary>
    public string BrowserChannel { get; init; } = "msedge";

    /// <summary>是否无头运行。人工登录时必须为 false。</summary>
    public bool Headless { get; init; }

    /// <summary>持久化用户资料目录。同一个目录可复用 Cookies 与登录状态。</summary>
    public string UserDataDirectory { get; init; } = DefaultUserDataDirectory();

    /// <summary>浏览器窗口最大化（非无头时生效）。</summary>
    public bool StartMaximized { get; init; } = true;

    /// <summary>页面默认超时。</summary>
    public float DefaultTimeoutMs { get; init; } = 30_000;

    public static string DefaultUserDataDirectory()
        => Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "GateAuto",
            "browser-profile");
}

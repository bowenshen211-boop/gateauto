using Microsoft.Playwright;

namespace GateAuto.Automation;

/// <summary>
/// 一个长期存活的浏览器会话。使用持久化用户资料目录，
/// 因此第一次人工登录后，后续建单 / 改车牌都不需要重新登录。
/// </summary>
public sealed class GateBrowserSession : IAsyncDisposable
{
    private readonly IPlaywright _playwright;
    private readonly IBrowserContext _context;
    private bool _disposed;

    private GateBrowserSession(IPlaywright playwright, IBrowserContext context, IPage page)
    {
        _playwright = playwright;
        _context = context;
        Page = page;
    }

    /// <summary>当前操作页。若系统以新标签页打开表单，会自动切换到新标签页。</summary>
    public IPage Page { get; private set; }

    public IBrowserContext Context => _context;

    /// <summary>启动浏览器。目录不存在时自动创建。</summary>
    public static async Task<GateBrowserSession> StartAsync(
        GateBrowserOptions? options = null,
        CancellationToken cancellationToken = default)
    {
        var settings = options ?? new GateBrowserOptions();

        var userDataDirectory = string.IsNullOrWhiteSpace(settings.UserDataDirectory)
            ? GateBrowserOptions.DefaultUserDataDirectory()
            : settings.UserDataDirectory;

        Directory.CreateDirectory(userDataDirectory);

        var playwright = await Playwright.CreateAsync();
        try
        {
            var launchOptions = new BrowserTypeLaunchPersistentContextOptions
            {
                Headless = settings.Headless,
            };

            if (!string.IsNullOrWhiteSpace(settings.BrowserChannel))
            {
                launchOptions.Channel = settings.BrowserChannel;
            }

            if (settings.StartMaximized && !settings.Headless)
            {
                launchOptions.Args = ["--start-maximized"];
            }

            cancellationToken.ThrowIfCancellationRequested();

            var context = await playwright.Chromium.LaunchPersistentContextAsync(userDataDirectory, launchOptions);
            context.SetDefaultTimeout(settings.DefaultTimeoutMs);
            context.SetDefaultNavigationTimeout(settings.DefaultTimeoutMs);

            var page = context.Pages.Count > 0
                ? context.Pages[0]
                : await context.NewPageAsync();

            return new GateBrowserSession(playwright, context, page);
        }
        catch
        {
            playwright.Dispose();
            throw;
        }
    }

    /// <summary>打开网址并等待 DOM 就绪。</summary>
    public async Task<IPage> NavigateAsync(string url, CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(url);
        cancellationToken.ThrowIfCancellationRequested();

        await Page.GotoAsync(url, new() { WaitUntil = WaitUntilState.DOMContentLoaded });
        return Page;
    }

    public async ValueTask DisposeAsync()
    {
        if (_disposed)
        {
            return;
        }

        _disposed = true;

        try
        {
            await _context.CloseAsync();
        }
        catch (PlaywrightException)
        {
            // 浏览器可能已被人工关闭。
        }

        _playwright.Dispose();
    }
}

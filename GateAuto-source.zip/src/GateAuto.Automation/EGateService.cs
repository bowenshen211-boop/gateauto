using System.Globalization;
using System.Text.RegularExpressions;
using GateAuto.Core.Rules;
using Microsoft.Playwright;

namespace GateAuto.Automation;

/// <summary>
/// 电子闸口的业务操作：建单（新增 → 填表 → 有来源添加 → 保存 → 取 LQE）与修改车牌。
/// 所有定位文字来自 <see cref="EGateSelectors"/>，流程本身不写死任何界面细节。
/// </summary>
public sealed class EGateService
{
    private readonly EGateSelectors _selectors;
    private readonly string _listUrl;
    private readonly string? _addOrderUrl;

    /// <summary>打开建单页之前页面上已有的 LQE，用于区分本次新建的放行单号。</summary>
    private HashSet<string> _lqeBaseline = new(StringComparer.OrdinalIgnoreCase);

    public EGateService(IPage page, EGateSelectors selectors, string listUrl, string? addOrderUrl = null)
    {
        ArgumentNullException.ThrowIfNull(page);
        ArgumentNullException.ThrowIfNull(selectors);
        ArgumentException.ThrowIfNullOrWhiteSpace(listUrl);

        Page = page;
        _selectors = selectors;
        _listUrl = listUrl;
        _addOrderUrl = string.IsNullOrWhiteSpace(addOrderUrl) ? null : addOrderUrl;
    }

    /// <summary>当前操作页。若系统以新标签页打开表单，会自动切换到新标签页。</summary>
    public IPage Page { get; private set; }

    /// <summary>打开电子闸口清单页。</summary>
    public async Task OpenListAsync(CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();

        await Page.GotoAsync(_listUrl, new() { WaitUntil = WaitUntilState.DOMContentLoaded });

        if (LooksLikeLogin(Page.Url))
        {
            throw new EGateAutomationException("尚未登入電子閘口，請先在瀏覽器中完成登入後再執行");
        }
    }

    /// <summary>打开新增建单表单：优先直接访问配置的新增页网址，否则在清单页点「新增」。</summary>
    public async Task OpenCreateFormAsync(CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();

        if (_addOrderUrl is not null)
        {
            _lqeBaseline = await CollectLqeAsync();
            await Page.GotoAsync(_addOrderUrl, new() { WaitUntil = WaitUntilState.DOMContentLoaded });
        }
        else
        {
            await OpenListAsync(cancellationToken);
            _lqeBaseline = await CollectLqeAsync();

            var pagesBefore = Page.Context.Pages.Count;
            await EGateLocators.ClickAnyByTextAsync(
                Page.Locator("body"),
                _selectors.AddButtonTexts,
                _selectors.TimeoutMs);

            await AdoptNewPageAsync(pagesBefore);
        }

        if (LooksLikeLogin(Page.Url))
        {
            throw new EGateAutomationException("新增建單頁跳轉到登入頁，請先完成登入");
        }

        await WaitForFormReadyAsync();
    }

    /// <summary>按规则判定结果填写固定字段与动态字段。</summary>
    public async Task FillFieldsAsync(
        RuleEvaluation evaluation,
        ICollection<string> warnings,
        ICollection<string>? log = null,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(evaluation);

        var fixedFields = evaluation.FixedFields;
        var order = evaluation.Order;

        var fields = new List<(EGateField Field, IReadOnlyList<string> Values)>
        {
            (EGateField.DeclarationType, [fixedFields.DeclarationType]),
            (EGateField.LegalEntity, [fixedFields.LegalEntity]),
            (EGateField.ApplyDepartment, [fixedFields.ApplyDepartment]),
            (EGateField.TransportMode, [fixedFields.TransportMode]),
            (EGateField.LoadingPark, [fixedFields.LoadingPark]),
            (EGateField.ExitType, Candidates(evaluation.ExitTypeDisplay, evaluation.ExitTypeCode, evaluation.ExitTypeName)),
            (EGateField.CargoType, Candidates(evaluation.CargoType)),
            (EGateField.VendorCode, Candidates(evaluation.VendorCode)),
            (EGateField.VendorType, Candidates(evaluation.VendorType)),
            (EGateField.LoadingAddress, Candidates(evaluation.LoadingAddress)),
            (EGateField.UnloadingPark, Candidates(evaluation.UnloadingPark)),
            (EGateField.UnloadingAddress, Candidates(evaluation.UnloadingAddress)),
            (EGateField.PackingMethod, Candidates(evaluation.PackingMethod)),
            (EGateField.PackageCount, order.PackageCount > 0
                ? [order.PackageCount.ToString(CultureInfo.InvariantCulture)]
                : []),
            (EGateField.GrossWeight, order.GrossWeightKg > 0
                ? [order.GrossWeightKg.ToString("0.##", CultureInfo.InvariantCulture)]
                : []),
            (EGateField.NetWeight, order.NetWeightKg > 0
                ? [order.NetWeightKg.ToString("0.##", CultureInfo.InvariantCulture)]
                : []),
        };

        foreach (var (field, values) in fields)
        {
            cancellationToken.ThrowIfCancellationRequested();

            if (values.Count == 0)
            {
                continue;
            }

            var name = _selectors.FieldLabels.TryGetValue(field, out var label) ? label : field.ToString();

            await EGateFormFiller.FillAsync(
                Page,
                _selectors,
                field,
                values,
                name,
                warnings,
                cancellationToken);

            log?.Add($"已填寫 {name} = {values[0]}");
        }
    }

    /// <summary>打开「有來源添加」：先选外销 → 填来源单号 → 查询 → 确定。返回明细行数。</summary>
    public async Task<int> ApplySourceAsync(
        string sourceNosText,
        ICollection<string>? log = null,
        CancellationToken cancellationToken = default)
    {
        var sourceNos = SourceNoParser.Parse(sourceNosText);
        if (sourceNos.Count == 0)
        {
            throw new EGateAutomationException("來源單號為空，無法執行「有來源添加」");
        }

        cancellationToken.ThrowIfCancellationRequested();

        var dialog = await SourceAddDialog.OpenAsync(Page, _selectors);
        log?.Add("已開啟「有來源添加」");

        await dialog.SelectSourceTypeAsync();
        log?.Add($"已選擇來源類型「{_selectors.SourceTypeOptionText}」");

        var filled = await dialog.FillSourceNosAsync(sourceNos);
        log?.Add($"已填入來源單號 {filled}");

        var rowCount = await dialog.QueryAsync();
        log?.Add($"查詢完成，明細 {rowCount} 行");

        await dialog.ConfirmAsync();
        log?.Add("已確定並關閉「有來源添加」");

        return rowCount;
    }

    /// <summary>完整建单：新增 → 填表 → 有來源添加 → 保存（含確認框）→ 取得新的 LQE 放行单号。</summary>
    public async Task<ShipmentCreationResult> CreateShipmentAsync(
        RuleEvaluation evaluation,
        ICollection<string>? log = null,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(evaluation);

        var warnings = new List<string>();
        var steps = new List<string>();

        await OpenCreateFormAsync(cancellationToken);
        steps.Add("已開啟新增建單頁");

        await FillFieldsAsync(evaluation, warnings, steps, cancellationToken);
        steps.Add("已完成固定欄位與動態欄位填寫");

        var rowCount = await ApplySourceAsync(evaluation.SourceNosText, steps, cancellationToken);

        var lqeNo = await SaveAndCaptureLqeAsync(_lqeBaseline, steps, cancellationToken);
        steps.Add($"取得放行單號 {lqeNo}");

        if (log is not null)
        {
            foreach (var step in steps)
            {
                log.Add(step);
            }
        }

        return new ShipmentCreationResult
        {
            LqeNo = lqeNo,
            SourceRowCount = rowCount,
            Warnings = warnings,
            Steps = steps,
        };
    }

    /// <summary>在清单页按放行单号定位资料列，修改车牌。</summary>
    public async Task UpdatePlateAsync(string lqeNo, string plateNo, CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(lqeNo);
        ArgumentException.ThrowIfNullOrWhiteSpace(plateNo);
        cancellationToken.ThrowIfCancellationRequested();

        await OpenListAsync(cancellationToken);

        await EGateLocators.WaitForRowsAsync(
            Page.Locator(_selectors.RowSelector),
            _selectors.QueryTimeout,
            "電子閘口清單未載入，無法修改車牌");

        var dialog = await PlateEditDialog.OpenFromRowAsync(Page, lqeNo, _selectors);
        await dialog.UpdatePlateAsync(plateNo);
    }

    private async Task<string> SaveAndCaptureLqeAsync(
        HashSet<string> existingLqe,
        ICollection<string> steps,
        CancellationToken cancellationToken)
    {
        string clicked;
        try
        {
            clicked = await EGateLocators.ClickAnyByTextAsync(
                Page.Locator("body"),
                _selectors.SaveButtonTexts,
                _selectors.TimeoutMs);
        }
        catch (EGateAutomationException ex)
        {
            throw new EGateAutomationException($"找不到儲存按鈕：{ex.Message}", ex);
        }

        steps.Add($"已點擊「{clicked}」");

        await HandleSubmitConfirmAsync(steps, cancellationToken);
        cancellationToken.ThrowIfCancellationRequested();

        return await WaitForNewLqeAsync(existingLqe);
    }

    /// <summary>保存后可能弹出运输方式 / 落货园区确认框，出现就点「確認並提交」。</summary>
    private async Task HandleSubmitConfirmAsync(ICollection<string> steps, CancellationToken cancellationToken)
    {
        var deadline = DateTime.UtcNow + TimeSpan.FromSeconds(10);

        while (DateTime.UtcNow < deadline)
        {
            cancellationToken.ThrowIfCancellationRequested();

            foreach (var text in _selectors.SubmitConfirmTexts)
            {
                var inDialog = Page.GetByRole(AriaRole.Dialog).GetByRole(AriaRole.Button, new() { Name = text });
                var button = await EGateLocators.FirstVisibleAsync(inDialog);

                if (button is null)
                {
                    var fallback = Page.Locator("[role=dialog]").GetByText(text, new() { Exact = true });
                    button = await EGateLocators.FirstVisibleAsync(fallback);
                }

                if (button is null)
                {
                    continue;
                }

                await button.ClickAsync(new() { Timeout = _selectors.TimeoutMs });
                steps.Add($"確認框已點擊「{text}」");
                return;
            }

            await Task.Delay(200);
        }
    }

    /// <summary>轮询页面文字，直到出现一个建单前不存在的 LQE 放行单号。</summary>
    private async Task<string> WaitForNewLqeAsync(HashSet<string> existingLqe)
    {
        var regex = new Regex(_selectors.LqePattern, RegexOptions.Compiled);
        var deadline = DateTime.UtcNow + _selectors.LqeTimeout;

        while (DateTime.UtcNow < deadline)
        {
            try
            {
                // 优先看提示条：保存成功后通常会在 message/toast 里直接带出新的放行单号。
                var toast = Page.Locator(".el-message, .el-notification, [role=alert]");
                if (await toast.CountAsync() > 0)
                {
                    var toastText = await toast.First.InnerTextAsync();
                    foreach (Match match in regex.Matches(toastText))
                    {
                        if (!existingLqe.Contains(match.Value))
                        {
                            return match.Value;
                        }
                    }
                }

                var text = await Page.Locator("body").InnerTextAsync();
                string? lastNew = null;
                foreach (Match match in regex.Matches(text))
                {
                    if (!existingLqe.Contains(match.Value))
                    {
                        lastNew = match.Value;
                    }
                }

                if (lastNew is not null)
                {
                    return lastNew;
                }
            }
            catch (PlaywrightException)
            {
                // 儲存後頁面可能正在跳轉，下一輪再讀。
            }

            await Task.Delay(500);
        }

        throw new EGateAutomationException(
            "已送出建單，但頁面上未出現新的 LQE 放行單號；請至電子閘口清單確認是否已建立，避免重複建單");
    }

    private async Task<HashSet<string>> CollectLqeAsync()
    {
        var result = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        try
        {
            var text = await Page.Locator("body").InnerTextAsync();
            foreach (Match match in Regex.Matches(text, _selectors.LqePattern))
            {
                result.Add(match.Value);
            }
        }
        catch (PlaywrightException)
        {
            // 頁面尚未就緒時視為沒有既有放行單號。
        }

        return result;
    }

    private async Task WaitForFormReadyAsync()
    {
        var labels = new List<string>(_selectors.LabelsOf(EGateField.ExitType));
        labels.AddRange(_selectors.LabelsOf(EGateField.DeclarationType));

        var deadline = DateTime.UtcNow + _selectors.FormLoadTimeout;

        while (DateTime.UtcNow < deadline)
        {
            if (await EGateFormFiller.IsFieldPresentAsync(Page, labels))
            {
                return;
            }

            await Task.Delay(300);
        }

        throw new EGateAutomationException(
            "新增建單頁未載入（找不到「進閘類別 / 申報類型」欄位）。" +
            "若表單結構不同，請在設定中指定新增頁網址或調整欄位標籤");
    }

    private async Task AdoptNewPageAsync(int pagesBefore)
    {
        try
        {
            await Page.WaitForTimeoutAsync(500);
        }
        catch (PlaywrightException)
        {
            // 忽略：只是給新標籤頁一點開啟時間。
        }

        var pages = Page.Context.Pages;
        if (pages.Count <= pagesBefore)
        {
            return;
        }

        Page = pages[^1];
        try
        {
            await Page.WaitForLoadStateAsync(LoadState.DOMContentLoaded);
        }
        catch (PlaywrightException)
        {
            // 仍在載入，交給等待表單就緒的輪詢處理。
        }
    }

    private static bool LooksLikeLogin(string? url)
        => url is not null && url.Contains("login", StringComparison.OrdinalIgnoreCase);

    private static IReadOnlyList<string> Candidates(params string?[] values)
        => values
            .Where(v => !string.IsNullOrWhiteSpace(v))
            .Select(v => v!.Trim())
            .Distinct(StringComparer.Ordinal)
            .ToList();
}

namespace GateAuto.Automation;

/// <summary>电子闸口自动化过程中的可预期失败，可直接展示给操作人员。</summary>
public sealed class EGateAutomationException : Exception
{
    public EGateAutomationException(string message) : base(message)
    {
    }

    public EGateAutomationException(string message, Exception inner) : base(message, inner)
    {
    }
}

namespace GateAuto.Automation;

/// <summary>电子闸口界面的中文字形。</summary>
public enum EGateTextVariant
{
    /// <summary>繁体（默认，与需求规格一致）。</summary>
    Traditional,

    /// <summary>简体。</summary>
    Simplified,
}

/// <summary>建单表单上需要填写的字段。</summary>
public enum EGateField
{
    DeclarationType,
    LegalEntity,
    ApplyDepartment,
    TransportMode,
    LoadingPark,
    ExitType,
    CargoType,
    VendorCode,
    VendorType,
    LoadingAddress,
    UnloadingPark,
    UnloadingAddress,
    PackingMethod,
    PackageCount,
    GrossWeight,
    NetWeight,
}

/// <summary>字段的控件类型。</summary>
public enum EGateFieldKind
{
    /// <summary>文本框，直接输入。</summary>
    Text,

    /// <summary>下拉框：原生 select 用选项文字选择，自定义下拉框则点开再按文字选择。</summary>
    Select,
}

/// <summary>两套字形对应的界面文字。</summary>
internal sealed record EGateTexts(
    string AddSourceButton,
    string AddSourceDialogTitle,
    string QueryButton,
    string ConfirmButton,
    string EditPlateButton,
    string EditPlateDialogTitle,
    string SourceTypeOption,
    string AddButton,
    string SaveButton,
    string SubmitConfirmButton)
{
    public static readonly EGateTexts Traditional = new(
        AddSourceButton: "有來源添加",
        AddSourceDialogTitle: "有來源添加",
        QueryButton: "查詢",
        ConfirmButton: "確認",
        EditPlateButton: "修改工具號",
        EditPlateDialogTitle: "修改工具號",
        SourceTypeOption: "外銷",
        AddButton: "新增",
        SaveButton: "保存",
        SubmitConfirmButton: "確認並提交");

    public static readonly EGateTexts Simplified = new(
        AddSourceButton: "有来源添加",
        AddSourceDialogTitle: "有来源添加",
        QueryButton: "查询",
        ConfirmButton: "确认",
        EditPlateButton: "修改工具号",
        EditPlateDialogTitle: "修改工具号",
        SourceTypeOption: "外销",
        AddButton: "新增",
        SaveButton: "保存",
        SubmitConfirmButton: "确认并提交");

    public static EGateTexts For(EGateTextVariant variant)
        => variant == EGateTextVariant.Simplified ? Simplified : Traditional;
}

/// <summary>两套字形对应的字段标签（取自电子闸口前端语言包的 key）。</summary>
internal sealed record EGateFieldLabels(
    string DeclarationType,
    string LegalEntity,
    string ApplyDepartment,
    string TransportMode,
    string LoadingPark,
    string ExitType,
    string CargoType,
    string VendorCode,
    string VendorType,
    string LoadingAddress,
    string UnloadingPark,
    string UnloadingAddress,
    string PackingMethod,
    string PackageCount,
    string GrossWeight,
    string NetWeight)
{
    public static readonly EGateFieldLabels Traditional = new(
        DeclarationType: "申報類型",
        LegalEntity: "申請法人",
        ApplyDepartment: "申請部門",
        TransportMode: "運輸方式",
        LoadingPark: "裝貨園區",
        ExitType: "進閘類別",
        CargoType: "貨物性質",
        VendorCode: "廠商代碼",
        VendorType: "廠商類型",
        LoadingAddress: "裝貨地址",
        UnloadingPark: "落貨園區",
        UnloadingAddress: "落貨地址",
        PackingMethod: "包裝方式",
        PackageCount: "件數",
        GrossWeight: "毛重",
        NetWeight: "淨重");

    public static readonly EGateFieldLabels Simplified = new(
        DeclarationType: "申报类型",
        LegalEntity: "申请法人",
        ApplyDepartment: "申请部门",
        TransportMode: "运输方式",
        LoadingPark: "装货园区",
        ExitType: "进闸类别",
        CargoType: "货物性质",
        VendorCode: "厂商代码",
        VendorType: "厂商类型",
        LoadingAddress: "装货地址",
        UnloadingPark: "落货园区",
        UnloadingAddress: "落货地址",
        PackingMethod: "包装方式",
        PackageCount: "件数",
        GrossWeight: "毛重",
        NetWeight: "净重");

    public static EGateFieldLabels For(EGateTextVariant variant)
        => variant == EGateTextVariant.Simplified ? Simplified : Traditional;

    public Dictionary<EGateField, string> ToMap() => new()
    {
        [EGateField.DeclarationType] = DeclarationType,
        [EGateField.LegalEntity] = LegalEntity,
        [EGateField.ApplyDepartment] = ApplyDepartment,
        [EGateField.TransportMode] = TransportMode,
        [EGateField.LoadingPark] = LoadingPark,
        [EGateField.ExitType] = ExitType,
        [EGateField.CargoType] = CargoType,
        [EGateField.VendorCode] = VendorCode,
        [EGateField.VendorType] = VendorType,
        [EGateField.LoadingAddress] = LoadingAddress,
        [EGateField.UnloadingPark] = UnloadingPark,
        [EGateField.UnloadingAddress] = UnloadingAddress,
        [EGateField.PackingMethod] = PackingMethod,
        [EGateField.PackageCount] = PackageCount,
        [EGateField.GrossWeight] = GrossWeight,
        [EGateField.NetWeight] = NetWeight,
    };
}

/// <summary>
/// 电子闸口的定位配置。全部按「文字 / 标签 / 标准 HTML 属性」定位，不依赖网页元素 ID 与 XPath。
/// 真实系统若与默认值不同，只改这里，不必改流程代码。
/// </summary>
public sealed class EGateSelectors
{
    private EGateTextVariant _textVariant = EGateTextVariant.Traditional;

    /// <summary>
    /// 界面字形，默认繁体。设置后会自动套用该字形下的全部默认文字与字段标签；
    /// 若只需调整个别文字，请在设置本属性之后再覆盖对应属性。
    /// </summary>
    public EGateTextVariant TextVariant
    {
        get => _textVariant;
        set
        {
            _textVariant = value;
            var texts = EGateTexts.For(value);
            AddSourceButtonText = texts.AddSourceButton;
            AddSourceDialogTitle = texts.AddSourceDialogTitle;
            QueryButtonText = texts.QueryButton;
            ConfirmButtonText = texts.ConfirmButton;
            EditPlateButtonText = texts.EditPlateButton;
            EditPlateDialogTitle = texts.EditPlateDialogTitle;
            SourceTypeOptionText = texts.SourceTypeOption;
            AddButtonText = texts.AddButton;
            SaveButtonText = texts.SaveButton;
            SubmitConfirmButtonText = texts.SubmitConfirmButton;

            FieldLabels = EGateFieldLabels.For(value).ToMap();
        }
    }

    /// <summary>弹窗根节点。优先按 ARIA role=dialog 查找，找不到时用此选择器。</summary>
    public string DialogRootSelector { get; set; } = "[role=dialog]";

    /// <summary>列表行选择器，用于按放行单号定位资料列。</summary>
    public string RowSelector { get; set; } = "tr";

    // ---------- 建单表单 ----------

    /// <summary>表单页「新增」按钮文字。</summary>
    public string AddButtonText { get; set; } = "新增";

    /// <summary>「新增」按钮的备用文字。</summary>
    public List<string> AddButtonAliases { get; set; } = ["新增", "添加", "新增單據"];

    /// <summary>表单页「保存」按钮文字。</summary>
    public string SaveButtonText { get; set; } = "保存";

    /// <summary>「保存」按钮的备用文字（送签流程可能叫「提交」）。</summary>
    public List<string> SaveButtonAliases { get; set; } = ["保存", "儲存", "保存並送簽", "提交"];

    /// <summary>保存后确认框的按钮文字。</summary>
    public string SubmitConfirmButtonText { get; set; } = "確認並提交";

    /// <summary>保存后确认框按钮的备用文字。</summary>
    public List<string> SubmitConfirmButtonAliases { get; set; } = ["確認並提交", "确认并提交", "確認", "确定", "確定"];

    /// <summary>字段标签映射，键为字段，值为界面上显示的文字。</summary>
    public Dictionary<EGateField, string> FieldLabels { get; set; } = EGateFieldLabels.Traditional.ToMap();

    /// <summary>
    /// 字段标签的同义写法。真实系统不同模块可能叫法不同（例如出閘類別 / 進閘類別 / 出廠分類）。
    /// 定位时主标签找不到才会用这些别名，不影响默认行为。
    /// </summary>
    public Dictionary<EGateField, List<string>> FieldLabelAliases { get; set; } = new()
    {
        [EGateField.DeclarationType] = ["申報類型", "申报类型", "報關類型"],
        [EGateField.LegalEntity] = ["申請法人", "所屬法人", "申请法人", "所属法人"],
        [EGateField.ApplyDepartment] = ["申請部門", "申请部门", "申請單位"],
        [EGateField.ExitType] = ["進閘類別", "出閘類別", "出閘分類", "出廠分類", "进闸类别", "出闸类别", "出厂分类"],
        [EGateField.CargoType] = ["貨物性質", "货物性质", "貨物類別"],
        [EGateField.PackingMethod] = ["包裝方式", "包装方式"],
        [EGateField.VendorType] = ["廠商類型", "厂商类型", "廠商性質"],
        [EGateField.UnloadingPark] = ["落貨園區", "落货园区", "卸貨園區"],
        [EGateField.LoadingPark] = ["裝貨園區", "装货园区"],
        [EGateField.LoadingAddress] = ["裝貨地址", "装货地址"],
        [EGateField.UnloadingAddress] = ["落貨地址", "落货地址"],
        [EGateField.PackageCount] = ["件數", "件数", "總件數"],
        [EGateField.GrossWeight] = ["毛重", "毛重(KG)", "毛重（KG）"],
        [EGateField.NetWeight] = ["淨重", "净重", "淨重(KG)", "净重(KG)"],
    };

    /// <summary>字段控件类型映射。真实系统若是原生下拉框或自定义下拉框，可在此逐项调整。</summary>
    public Dictionary<EGateField, EGateFieldKind> FieldKinds { get; set; } = new()
    {
        [EGateField.DeclarationType] = EGateFieldKind.Select,
        [EGateField.LegalEntity] = EGateFieldKind.Select,
        [EGateField.ApplyDepartment] = EGateFieldKind.Select,
        [EGateField.TransportMode] = EGateFieldKind.Select,
        [EGateField.LoadingPark] = EGateFieldKind.Select,
        [EGateField.ExitType] = EGateFieldKind.Select,
        [EGateField.CargoType] = EGateFieldKind.Select,
        [EGateField.VendorCode] = EGateFieldKind.Text,
        [EGateField.VendorType] = EGateFieldKind.Select,
        [EGateField.LoadingAddress] = EGateFieldKind.Text,
        [EGateField.UnloadingPark] = EGateFieldKind.Select,
        [EGateField.UnloadingAddress] = EGateFieldKind.Text,
        [EGateField.PackingMethod] = EGateFieldKind.Text,
        [EGateField.PackageCount] = EGateFieldKind.Text,
        [EGateField.GrossWeight] = EGateFieldKind.Text,
        [EGateField.NetWeight] = EGateFieldKind.Text,
    };

    /// <summary>
    /// 可以留空、找不到控件也不算失败的字段。默认只有净重：需求未强制填写。
    /// </summary>
    public HashSet<EGateField> OptionalFields { get; set; } = [EGateField.NetWeight];

    /// <summary>保存后提取 LQE 放行单号的正则。</summary>
    public string LqePattern { get; set; } = @"LQE-\d+";

    /// <summary>等待 LQE 放行单号出现的超时。</summary>
    public TimeSpan LqeTimeout { get; set; } = TimeSpan.FromSeconds(60);

    /// <summary>表单页加载完成的等待超时。</summary>
    public TimeSpan FormLoadTimeout { get; set; } = TimeSpan.FromSeconds(30);

    // ---------- 有來源添加 ----------

    /// <summary>表单页上「有来源添加」按钮文字。</summary>
    public string AddSourceButtonText { get; set; } = "有來源添加";

    /// <summary>「有来源添加」按钮的备用文字。</summary>
    public List<string> AddSourceButtonAliases { get; set; } = ["有來源添加", "有来源添加", "有來源新增", "有来源新增"];

    /// <summary>弹窗标题文字。</summary>
    public string AddSourceDialogTitle { get; set; } = "有來源添加";

    /// <summary>弹窗标题的备用文字。</summary>
    public List<string> AddSourceDialogTitleAliases { get; set; } = ["有來源添加", "有来源添加"];

    /// <summary>来源单号输入框。默认取弹窗内第一个可输入的文本框。</summary>
    public string SourceNoInputSelector { get; set; } = "input:not([type=checkbox]):not([type=radio]):not([type=hidden])";

    /// <summary>来源类型固定选项文字（需求：固定选择外销）。</summary>
    public string SourceTypeOptionText { get; set; } = "外銷";

    /// <summary>来源类型的备用文字。</summary>
    public List<string> SourceTypeOptionAliases { get; set; } = ["外銷", "外销"];

    /// <summary>是否需要在弹窗内点选来源类型。</summary>
    public bool SelectSourceType { get; set; } = true;

    /// <summary>查询按钮文字。</summary>
    public string QueryButtonText { get; set; } = "查詢";

    /// <summary>查询按钮的备用文字。</summary>
    public List<string> QueryButtonAliases { get; set; } = ["查詢", "查询", "搜索", "檢索"];

    /// <summary>查询结果明细行选择器，出现行即视为查询完成。</summary>
    public string DetailRowSelector { get; set; } = "tbody tr";

    /// <summary>确定按钮文字（真实系统为「確認」）。</summary>
    public string ConfirmButtonText { get; set; } = "確認";

    /// <summary>确定按钮的备用文字。</summary>
    public List<string> ConfirmButtonAliases { get; set; } = ["確認", "确认", "確定", "确定"];

    // ---------- 修改車牌 ----------

    /// <summary>列表行内「修改车牌」按钮文字（真实系统为「修改工具號」）。</summary>
    public string EditPlateButtonText { get; set; } = "修改工具號";

    /// <summary>修改车牌按钮的备用文字。</summary>
    public List<string> EditPlateButtonAliases { get; set; } = ["修改工具號", "修改工具号", "修改車牌", "修改车牌"];

    /// <summary>弹窗标题文字。</summary>
    public string EditPlateDialogTitle { get; set; } = "修改工具號";

    /// <summary>弹窗标题的备用文字。</summary>
    public List<string> EditPlateDialogTitleAliases { get; set; } = ["修改工具號", "修改工具号", "修改車牌", "修改车牌"];

    /// <summary>车牌输入框。默认取弹窗内第一个可输入的文本框。</summary>
    public string PlateInputSelector { get; set; } = "input:not([type=checkbox]):not([type=radio]):not([type=hidden])";

    /// <summary>一般操作（点按钮、等弹窗）超时。</summary>
    public TimeSpan Timeout { get; set; } = TimeSpan.FromSeconds(30);

    /// <summary>查询明细出现的等待超时。</summary>
    public TimeSpan QueryTimeout { get; set; } = TimeSpan.FromSeconds(60);

    internal float TimeoutMs => (float)Timeout.TotalMilliseconds;

    internal float QueryTimeoutMs => (float)QueryTimeout.TotalMilliseconds;

    internal float LqeTimeoutMs => (float)LqeTimeout.TotalMilliseconds;

    internal float FormLoadTimeoutMs => (float)FormLoadTimeout.TotalMilliseconds;

    /// <summary>主文字 + 备用文字（去重，保持顺序）。</summary>
    internal static IReadOnlyList<string> Candidates(string primary, IEnumerable<string>? aliases)
    {
        var result = new List<string> { primary };
        if (aliases is not null)
        {
            foreach (var alias in aliases)
            {
                if (!string.IsNullOrWhiteSpace(alias) && !result.Contains(alias))
                {
                    result.Add(alias);
                }
            }
        }

        return result;
    }

    internal IReadOnlyList<string> AddButtonTexts => Candidates(AddButtonText, AddButtonAliases);

    internal IReadOnlyList<string> SaveButtonTexts => Candidates(SaveButtonText, SaveButtonAliases);

    internal IReadOnlyList<string> SubmitConfirmTexts => Candidates(SubmitConfirmButtonText, SubmitConfirmButtonAliases);

    internal IReadOnlyList<string> AddSourceButtonTexts => Candidates(AddSourceButtonText, AddSourceButtonAliases);

    internal IReadOnlyList<string> QueryButtonTexts => Candidates(QueryButtonText, QueryButtonAliases);

    internal IReadOnlyList<string> ConfirmButtonTexts => Candidates(ConfirmButtonText, ConfirmButtonAliases);

    internal IReadOnlyList<string> EditPlateButtonTexts => Candidates(EditPlateButtonText, EditPlateButtonAliases);

    internal IReadOnlyList<string> SourceTypeTexts => Candidates(SourceTypeOptionText, SourceTypeOptionAliases);

    internal IReadOnlyList<string> AddSourceDialogTitles => Candidates(AddSourceDialogTitle, AddSourceDialogTitleAliases);

    internal IReadOnlyList<string> EditPlateDialogTitles => Candidates(EditPlateDialogTitle, EditPlateDialogTitleAliases);

    /// <summary>某字段的全部可用标签：主标签 + 别名。</summary>
    internal IReadOnlyList<string> LabelsOf(EGateField field)
    {
        var result = new List<string>();
        if (FieldLabels.TryGetValue(field, out var primary) && !string.IsNullOrWhiteSpace(primary))
        {
            result.Add(primary);
        }

        if (FieldLabelAliases.TryGetValue(field, out var aliases))
        {
            foreach (var alias in aliases)
            {
                if (!string.IsNullOrWhiteSpace(alias) && !result.Contains(alias))
                {
                    result.Add(alias);
                }
            }
        }

        return result;
    }
}

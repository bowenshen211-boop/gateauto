using GateAuto.Core.Models;
using Microsoft.Playwright;

namespace GateAuto.Automation.Workflows;

/// <summary>一次自动抓单的汇总结果。</summary>
public sealed class OrderFetchResult
{
    public required IReadOnlyList<OrderInfo> Orders { get; init; }

    public required IReadOnlyList<string> Steps { get; init; }

    public IReadOnlyList<string> Warnings { get; init; } = [];
}

/// <summary>
/// 打开某一行申请单详情的策略。默认实现只是「尽力点开」，
/// 关务/云富通的精确点击方式待日志确认后可整体替换，而不动抓单骨架。
/// </summary>
public delegate Task<IPage?> OrderDetailOpener(
    IPage listPage,
    OrderPlatform platform,
    OrderListRow row,
    CancellationToken cancellationToken);

/// <summary>
/// 自动抓单编排：读列表 → 逐笔点开详情 → 读详情生成 <see cref="OrderInfo"/> → 去重汇总。
/// 两个平台完全独立，不做任何跨平台字段合并；去重键沿用「平台 + 申请编号」。
/// </summary>
public sealed class OrderFetchWorkflow
{
    private readonly OrderDetailOpener _openDetail;

    public OrderFetchWorkflow(OrderDetailOpener? openDetail = null)
    {
        _openDetail = openDetail ?? DefaultOpenDetailAsync;
    }

    public async Task<OrderFetchResult> FetchAsync(
        IPage listPage,
        OrderPlatform platform,
        string listUrl,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(listPage);
        ArgumentException.ThrowIfNullOrWhiteSpace(listUrl);

        var steps = new List<string>();
        var warnings = new List<string>();

        cancellationToken.ThrowIfCancellationRequested();

        var list = await OrderListReader.ReadAsync(listPage, platform, cancellationToken);
        if (!string.IsNullOrWhiteSpace(list.Warning))
        {
            warnings.Add(list.Warning);
        }

        var orders = new List<OrderInfo>();
        var seen = new HashSet<string>(StringComparer.Ordinal);

        foreach (var row in list.Rows)
        {
            cancellationToken.ThrowIfCancellationRequested();

            if (string.IsNullOrWhiteSpace(row.ApplyNo))
            {
                continue;
            }

            var detailPage = await _openDetail(listPage, platform, row, cancellationToken);
            if (detailPage is null)
            {
                warnings.Add($"無法開啟申請單 {row.ApplyNo} 的詳情，已略過");
                continue;
            }

            var info = await OrderDetailReader.ReadAsync(detailPage, platform, row.ApplyNo, cancellationToken);
            if (seen.Add($"{platform}:{info.ApplyNo}"))
            {
                orders.Add(info);
                steps.Add($"已讀取 {platform.ToDisplay()} 申請單 {info.ApplyNo}（來源單號 {string.Join("、", info.SourceNos)}）");
            }

            await ReturnToListAsync(listPage, detailPage, listUrl, cancellationToken);
        }

        steps.Add($"共抓取 {orders.Count} 筆訂單");
        return new OrderFetchResult { Orders = orders, Steps = steps, Warnings = warnings };
    }

    private static async Task<IPage?> DefaultOpenDetailAsync(
        IPage listPage,
        OrderPlatform platform,
        OrderListRow row,
        CancellationToken cancellationToken)
    {
        var target = row.DetailLinkText ?? row.ApplyNo;
        if (string.IsNullOrWhiteSpace(target))
        {
            return null;
        }

        var pagesBefore = listPage.Context.Pages.Count(p => !p.IsClosed);

        try
        {
            // 关务列表的申请编号是链接（可能同页跳转或新开页）；云富通为 Ext 行。
            // 优先点链接，退而点文本；精确定位待日志确认后调整。
            var link = listPage.GetByRole(AriaRole.Link, new() { Name = target });
            var locator = await link.CountAsync() > 0
                ? link.First
                : listPage.GetByText(target, new() { Exact = true }).First;

            if (await locator.CountAsync() == 0)
            {
                return null;
            }

            await locator.ClickAsync();
        }
        catch (PlaywrightException)
        {
            return null;
        }

        // 等待可能的新页或当前页跳转。
        await listPage.WaitForTimeoutAsync(1000);

        var pages = listPage.Context.Pages.Where(p => !p.IsClosed).ToList();
        return pages.Count > pagesBefore ? pages[^1] : listPage;
    }

    private static async Task ReturnToListAsync(
        IPage listPage,
        IPage detailPage,
        string listUrl,
        CancellationToken cancellationToken)
    {
        try
        {
            if (!ReferenceEquals(detailPage, listPage))
            {
                await detailPage.CloseAsync();
            }
            else if (!string.Equals(listPage.Url, listUrl, StringComparison.OrdinalIgnoreCase))
            {
                await listPage.GotoAsync(listUrl, new() { WaitUntil = WaitUntilState.DOMContentLoaded });
            }
        }
        catch (PlaywrightException)
        {
            // 返回列表失败时忽略，交给下一笔或调用方处理。
        }
    }
}

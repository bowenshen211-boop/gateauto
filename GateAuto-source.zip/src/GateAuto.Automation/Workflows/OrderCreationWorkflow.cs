using GateAuto.Core.Models;
using GateAuto.Core.Rules;
using GateAuto.Data;

namespace GateAuto.Automation.Workflows;

/// <summary>一笔订单的建单结果。</summary>
public sealed class OrderCreationOutcome
{
    public required OrderInfo Order { get; init; }

    public required RuleEvaluation Evaluation { get; init; }

    public bool Success { get; init; }

    /// <summary>建单成功后的 LQE 放行单号。</summary>
    public string? LqeNo { get; init; }

    /// <summary>失败原因；规则不通过时为全部错误信息。</summary>
    public string? Error { get; init; }

    public IReadOnlyList<string> Steps { get; init; } = [];

    public IReadOnlyList<string> Warnings { get; init; } = [];
}

/// <summary>
/// 建单编排：规则判定 → 建单记录（建單中）→ 电子闸口建单 → 回写 LQE（已建單）→ 写入待派车清单。
/// 规则不通过时不打开浏览器；电子闸口失败时把订单标记为「失敗」，并保留可读的错误信息。
/// </summary>
public sealed class OrderCreationWorkflow
{
    private readonly RuleEngine _engine;
    private readonly OrderRepository _orders;
    private readonly PlateTaskRepository _plateTasks;
    private readonly EGateService _gate;

    public OrderCreationWorkflow(
        RuleEngine engine,
        OrderRepository orders,
        PlateTaskRepository plateTasks,
        EGateService gate)
    {
        ArgumentNullException.ThrowIfNull(engine);
        ArgumentNullException.ThrowIfNull(orders);
        ArgumentNullException.ThrowIfNull(plateTasks);
        ArgumentNullException.ThrowIfNull(gate);

        _engine = engine;
        _orders = orders;
        _plateTasks = plateTasks;
        _gate = gate;
    }

    public async Task<OrderCreationOutcome> CreateAsync(OrderInfo order, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(order);
        ArgumentException.ThrowIfNullOrWhiteSpace(order.ApplyNo);

        var evaluation = _engine.Evaluate(order);

        if (!evaluation.IsValid)
        {
            return new OrderCreationOutcome
            {
                Order = order,
                Evaluation = evaluation,
                Success = false,
                Error = string.Join("；", evaluation.Errors),
            };
        }

        var existing = _orders.GetByApplyNo(order.Platform, order.ApplyNo);
        if (existing is { Status: OrderStatus.Created } && !string.IsNullOrWhiteSpace(existing.LqeNo))
        {
            return new OrderCreationOutcome
            {
                Order = order,
                Evaluation = evaluation,
                Success = true,
                LqeNo = existing.LqeNo,
                Steps = [$"{order.Platform.ToDisplay()} 申請單 {order.ApplyNo} 已建單（{existing.LqeNo}），略過重複建單"],
            };
        }

        _orders.Save(new OrderRecord
        {
            Platform = order.Platform,
            ApplyNo = order.ApplyNo,
            SourceNo = evaluation.SourceNosText,
            ExitType = evaluation.ExitTypeDisplay ?? string.Empty,
            CargoType = evaluation.CargoType ?? string.Empty,
            VendorCode = evaluation.VendorCode ?? string.Empty,
            Status = OrderStatus.Creating,
            CreatedAt = DateTimeOffset.Now,
        });

        var steps = new List<string>();

        try
        {
            var result = await _gate.CreateShipmentAsync(evaluation, steps, cancellationToken);

            _orders.MarkCreated(order.Platform, order.ApplyNo, result.LqeNo);

            _plateTasks.Add(new PlateTask
            {
                LqeNo = result.LqeNo,
                Destination = ResolveDestination(order),
                PackageCount = order.PackageCount,
                WeightKg = order.GrossWeightKg,
                Status = PlateTaskStatus.Pending,
                CreatedAt = DateTimeOffset.Now,
            });

            steps.Add($"已寫入待派車清單：{result.LqeNo}");
            steps.Add($"申請單 {order.ApplyNo} 建單完成");

            return new OrderCreationOutcome
            {
                Order = order,
                Evaluation = evaluation,
                Success = true,
                LqeNo = result.LqeNo,
                Steps = steps,
                Warnings = [.. evaluation.Warnings, .. result.Warnings],
            };
        }
        catch (EGateAutomationException ex)
        {
            _orders.MarkFailed(order.Platform, order.ApplyNo);

            return new OrderCreationOutcome
            {
                Order = order,
                Evaluation = evaluation,
                Success = false,
                Error = ex.Message,
                Steps = steps,
                Warnings = evaluation.Warnings,
            };
        }
    }

    private static string ResolveDestination(OrderInfo order)
    {
        if (!string.IsNullOrWhiteSpace(order.Destination))
        {
            return order.Destination.Trim();
        }

        return string.IsNullOrWhiteSpace(order.UnloadAddress)
            ? order.DeliveryAddress?.Trim() ?? string.Empty
            : order.UnloadAddress.Trim();
    }
}

/// <summary>一笔车牌更新的结果。</summary>
public sealed class PlateUpdateOutcome
{
    public required string LqeNo { get; init; }

    public required string PlateNo { get; init; }

    public bool Success { get; init; }

    public string? Error { get; init; }
}

/// <summary>改车牌编排：电子闸口更新成功后才回写数据库。</summary>
public sealed class PlateUpdateWorkflow
{
    private readonly PlateTaskRepository _plateTasks;
    private readonly EGateService _gate;

    public PlateUpdateWorkflow(PlateTaskRepository plateTasks, EGateService gate)
    {
        ArgumentNullException.ThrowIfNull(plateTasks);
        ArgumentNullException.ThrowIfNull(gate);

        _plateTasks = plateTasks;
        _gate = gate;
    }

    public async Task<PlateUpdateOutcome> UpdateAsync(
        string lqeNo,
        string plateNo,
        CancellationToken cancellationToken = default)
    {
        try
        {
            await _gate.UpdatePlateAsync(lqeNo, plateNo, cancellationToken);
            _plateTasks.UpdatePlate(lqeNo, plateNo);

            return new PlateUpdateOutcome
            {
                LqeNo = lqeNo,
                PlateNo = plateNo,
                Success = true,
            };
        }
        catch (EGateAutomationException ex)
        {
            return new PlateUpdateOutcome
            {
                LqeNo = lqeNo,
                PlateNo = plateNo,
                Success = false,
                Error = ex.Message,
            };
        }
    }
}

using System.Runtime.InteropServices;
using System.Text.RegularExpressions;

namespace GateAuto.Automation;

/// <summary>
/// 下拉选项的宽松匹配。
/// 真实系统的选项常常带编号前缀（如「1-货物」「087-不返廠貨樣」），且界面可能是简体或繁体，
/// 因此匹配时统一去掉空白与编号前缀、折叠简繁，再按「完全相同 → 去前缀相同 → 包含」的顺序取最优。
/// </summary>
public static partial class OptionMatcher
{
    /// <summary>在选项中找出最符合任一候选值的下标；找不到返回 -1。</summary>
    public static int FindBestIndex(IReadOnlyList<string> options, IReadOnlyList<string> candidates)
    {
        ArgumentNullException.ThrowIfNull(options);
        ArgumentNullException.ThrowIfNull(candidates);

        foreach (var candidate in candidates)
        {
            var index = FindBestIndex(options, candidate);
            if (index >= 0)
            {
                return index;
            }
        }

        return -1;
    }

    /// <summary>在选项中找出最符合候选值的下标；找不到返回 -1。</summary>
    public static int FindBestIndex(IReadOnlyList<string> options, string candidate)
    {
        ArgumentNullException.ThrowIfNull(options);

        var foldedCandidate = Fold(candidate);
        if (foldedCandidate.Length == 0)
        {
            return -1;
        }

        var strippedCandidate = StripCode(foldedCandidate);

        var bestIndex = -1;
        var bestScore = int.MaxValue;
        var bestLength = int.MaxValue;

        for (var i = 0; i < options.Count; i++)
        {
            var option = Fold(options[i]);
            if (option.Length == 0)
            {
                continue;
            }

            var strippedOption = StripCode(option);

            int score;
            if (option == foldedCandidate)
            {
                score = 0;
            }
            else if (strippedOption.Length > 0 && strippedOption == strippedCandidate)
            {
                score = 1;
            }
            else if (strippedCandidate.Length >= 2
                     && strippedOption.Contains(strippedCandidate, StringComparison.Ordinal))
            {
                score = 2;
            }
            else
            {
                continue;
            }

            // 同分时取文字较短的选项，避免「包含」匹配到更长的其他选项。
            if (score < bestScore || (score == bestScore && option.Length < bestLength))
            {
                bestScore = score;
                bestIndex = i;
                bestLength = option.Length;
            }
        }

        return bestIndex;
    }

    /// <summary>去空白、折叠简繁与大小写，用于比较。</summary>
    private static string Fold(string? text)
    {
        if (string.IsNullOrWhiteSpace(text))
        {
            return string.Empty;
        }

        var normalized = WhitespaceRegex().Replace(text.Replace(' ', ' '), string.Empty);

        // Windows 自带的简繁转换，让「貨物」与「货物」视为相同。
        normalized = ChineseConverter.ToSimplified(normalized);

        return normalized.ToLowerInvariant();
    }

    /// <summary>去掉开头的编号前缀，例如「1-货物」「087-不返廠貨樣」「A1：xxx」。</summary>
    private static string StripCode(string text)
    {
        var current = text;

        for (var i = 0; i < 2; i++)
        {
            var next = CodePrefixRegex().Replace(current, string.Empty);
            if (next == current)
            {
                break;
            }

            current = next;
        }

        return current;
    }

    [GeneratedRegex(@"\s+", RegexOptions.Compiled)]
    private static partial Regex WhitespaceRegex();

    [GeneratedRegex(@"^[0-9a-z]+[-－—–:：/]+", RegexOptions.Compiled)]
    private static partial Regex CodePrefixRegex();

    /// <summary>调用 Windows 的 LCMapString 做简繁转换，让「貨物」与「货物」视为相同。</summary>
    private static class ChineseConverter
    {
        private const uint LcmapSimplifiedChinese = 0x02000000;

        public static string ToSimplified(string text)
        {
            if (text.Length == 0)
            {
                return text;
            }

            try
            {
                var length = LCMapString(0x0404, LcmapSimplifiedChinese, text, text.Length, null!, 0);
                if (length <= 0)
                {
                    return text;
                }

                var buffer = new char[length];
                var written = LCMapString(0x0404, LcmapSimplifiedChinese, text, text.Length, buffer, length);

                return written > 0 ? new string(buffer, 0, written) : text;
            }
            catch (Exception ex) when (ex is DllNotFoundException or EntryPointNotFoundException)
            {
                return text;
            }
        }

        [DllImport("kernel32.dll", EntryPoint = "LCMapStringW", CharSet = CharSet.Unicode)]
        private static extern int LCMapString(
            uint locale,
            uint mapFlags,
            string source,
            int sourceLength,
            [Out] char[] destination,
            int destinationLength);
    }
}

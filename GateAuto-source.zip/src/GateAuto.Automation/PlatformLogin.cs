using Microsoft.Playwright;

namespace GateAuto.Automation;

/// <summary>
/// 取单平台登入页的帐密填入。各平台登入页结构不同，这里只做「找出可见的密码框，
/// 以及它前面最近的文字输入框」，填入帐密后不自动提交，由使用者确认后自行登入。
/// </summary>
public static class PlatformLoginFiller
{
    private const string FillScript = """
        (args) => {
            const [account, password] = args;
            const visible = (el) => {
                const style = window.getComputedStyle(el);
                const rect = el.getBoundingClientRect();
                return style.display !== 'none' && style.visibility !== 'hidden'
                    && rect.width > 4 && rect.height > 4 && !el.disabled && !el.readOnly;
            };
            const setValue = (el, value) => {
                const proto = Object.getPrototypeOf(el);
                const desc = Object.getOwnPropertyDescriptor(proto, 'value');
                if (desc && desc.set) { desc.set.call(el, value); } else { el.value = value; }
                el.dispatchEvent(new Event('input', { bubbles: true }));
                el.dispatchEvent(new Event('change', { bubbles: true }));
            };
            const passwordInputs = Array.from(document.querySelectorAll('input[type="password"]')).filter(visible);
            if (passwordInputs.length === 0) { return false; }

            const pwd = passwordInputs[0];
            const inputs = Array.from(document.querySelectorAll('input')).filter(visible);
            const index = inputs.indexOf(pwd);
            const textInputs = inputs.slice(0, index).reverse().filter((el) => {
                const type = (el.type || 'text').toLowerCase();
                return type === 'text' || type === 'tel' || type === 'email' || type === '';
            });
            const user = textInputs.find((el) => /user|account|login|name|工號|帐号|帳號|用户名|用戶名/i.test(
                (el.name || '') + (el.id || '') + (el.placeholder || ''))) || textInputs[0];
            if (!user) { return false; }

            setValue(user, account);
            setValue(pwd, password);
            user.focus();
            return true;
        }
        """;

    /// <summary>打开平台登入页并尝试填入帐密。返回是否填入了帐密。</summary>
    public static async Task<bool> OpenAndFillAsync(
        IPage page,
        string url,
        string account,
        string password,
        Action<string>? log = null,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(page);
        ArgumentException.ThrowIfNullOrWhiteSpace(url);

        await page.GotoAsync(url, new() { WaitUntil = WaitUntilState.DOMContentLoaded });

        if (string.IsNullOrWhiteSpace(account))
        {
            log?.Invoke($"已開啟平台 {url}，請手動登入（登入狀態會保存）");
            return false;
        }

        for (var attempt = 0; attempt < 16; attempt++)
        {
            cancellationToken.ThrowIfCancellationRequested();

            var filled = await page.EvaluateAsync<bool>(FillScript, new object[] { account, password });
            if (filled)
            {
                log?.Invoke("已自動填入帳號密碼，請確認後點擊登入（不會自動提交）");
                return true;
            }

            await page.WaitForTimeoutAsync(500);
        }

        log?.Invoke("未找到登入表單，請在瀏覽器中手動登入（登入狀態會保存）");
        return false;
    }
}

using GateAuto.Core.Rules;
using Microsoft.Playwright;

namespace GateAuto.Automation;

/// <summary>
/// 「有來源添加」弹窗。
/// 流程：选择来源类型（固定外销）→ 输入来源单号 → 查询 → 等明细出现 → 确定。
/// </summary>
public sealed class SourceAddDialog
{
    private readonly ILocator _root;
    private readonly EGateSelectors _selectors;

    private SourceAddDialog(ILocator root, EGateSelectors selectors)
    {
        _root = root;
        _selectors = selectors;
    }

    /// <summary>点击「有來源添加」并等待弹窗出现。</summary>
    public static async Task<SourceAddDialog> OpenAsync(IPage page, EGateSelectors? selectors = null)
    {
        ArgumentNullException.ThrowIfNull(page);

        var options = selectors ?? new EGateSelectors();
        await EGateLocators.ClickAnyByTextAsync(page.Locator("body"), options.AddSourceButtonTexts, options.TimeoutMs);

        return await AttachAsync(page, options);
    }

    /// <summary>弹窗已经被人工点开时，直接接管。</summary>
    public static async Task<SourceAddDialog> AttachAsync(IPage page, EGateSelectors? selectors = null)
    {
        ArgumentNullException.ThrowIfNull(page);

        var options = selectors ?? new EGateSelectors();
        var root = await EGateLocators.WaitForDialogAsync(page, options, options.AddSourceDialogTitles, options.Timeout);

        return new SourceAddDialog(root, options);
    }

    /// <summary>
    /// 点选来源类型（固定外销）。这是查询前的必经步骤：
    /// 找不到该选项时直接报错，不会跳过而继续查询。
    /// </summary>
    public async Task SelectSourceTypeAsync()
    {
        if (!_selectors.SelectSourceType)
        {
            return;
        }

        var options = _selectors.SourceTypeTexts;
        ILocator? visible = null;

        foreach (var text in options)
        {
            var option = _root.GetByText(text, new() { Exact = true });
            visible = await EGateLocators.FirstVisibleAsync(option);
            if (visible is not null)
            {
                break;
            }
        }

        if (visible is null)
        {
            throw new EGateAutomationException(
                $"弹窗内找不到來源類型選項「{string.Join(" / ", options)}」，無法先選擇外銷再查詢");
        }

        await visible.ClickAsync(new() { Timeout = _selectors.TimeoutMs });
    }

    /// <summary>填入来源单号，多笔以英文逗号拼接。返回实际填入的内容。</summary>
    public async Task<string> FillSourceNosAsync(IEnumerable<string> sourceNos)
    {
        ArgumentNullException.ThrowIfNull(sourceNos);

        var text = SourceNoParser.Join(sourceNos);
        if (string.IsNullOrWhiteSpace(text))
        {
            throw new EGateAutomationException("來源單號為空，無法查詢");
        }

        var input = await EGateLocators.FirstVisibleAsync(_root.Locator(_selectors.SourceNoInputSelector))
            ?? throw new EGateAutomationException("弹窗内找不到來源單號輸入框");

        await input.FillAsync(text, new() { Timeout = _selectors.TimeoutMs });
        return text;
    }

    /// <summary>点击查询并等待明细列表出现，返回明细行数。</summary>
    public async Task<int> QueryAsync()
    {
        await EGateLocators.ClickAnyByTextAsync(_root, _selectors.QueryButtonTexts, _selectors.TimeoutMs);

        var rows = _root.Locator(_selectors.DetailRowSelector);
        return await EGateLocators.WaitForRowsAsync(
            rows,
            _selectors.QueryTimeout,
            "點擊查詢後未出現明細列表，查詢可能失敗或來源單號無效");
    }

    /// <summary>点击确定并等待弹窗关闭。</summary>
    public async Task ConfirmAsync()
    {
        await EGateLocators.ClickAnyByTextAsync(_root, _selectors.ConfirmButtonTexts, _selectors.TimeoutMs);
        await EGateLocators.WaitHiddenAsync(_root, _selectors.Timeout);
    }

    /// <summary>完整流程：选类型 → 填单号 → 查询 → 确定。返回查询到的明细行数。</summary>
    public async Task<int> SubmitAsync(IEnumerable<string> sourceNos)
    {
        await SelectSourceTypeAsync();
        await FillSourceNosAsync(sourceNos);
        var rowCount = await QueryAsync();
        await ConfirmAsync();

        return rowCount;
    }
}

using GateAuto.Core.Models;

namespace GateAuto.Core.Rules;

/// <summary>
/// 一次规则判定的结果。所有字段都是"准备填入电子闸口"的最终值，不含任何页面操作。
/// </summary>
public sealed class RuleEvaluation
{
    public required OrderInfo Order { get; init; }

    public required FixedFields FixedFields { get; init; }

    /// <summary>出闸类别代码（087 / 021 / 051）。</summary>
    public string? ExitTypeCode { get; init; }

    /// <summary>出闸类别名称。</summary>
    public string? ExitTypeName { get; init; }

    /// <summary>出闸类别显示值，例如 087-不返廠貨樣。</summary>
    public string? ExitTypeDisplay => ExitTypeCode is null
        ? null
        : string.IsNullOrEmpty(ExitTypeName) ? ExitTypeCode : $"{ExitTypeCode}-{ExitTypeName}";

    /// <summary>实施判定的来源单号前三位。</summary>
    public string? MatchedPrefix { get; init; }

    public string? CargoType { get; init; }

    public string? VendorCode { get; init; }

    public string? VendorType { get; init; }

    /// <summary>落货园区；厂商类型不是集团国内时为空。</summary>
    public string? UnloadingPark { get; init; }

    public string? UnloadingAddress { get; init; }

    public string LoadingAddress { get; init; } = string.Empty;

    public string PackingMethod { get; init; } = string.Empty;

    /// <summary>拼接后可直接粘贴到「有来源添加」的来源单号。</summary>
    public string SourceNosText { get; init; } = string.Empty;

    public IReadOnlyList<string> Errors { get; init; } = [];

    public IReadOnlyList<string> Warnings { get; init; } = [];

    public bool IsValid => Errors.Count == 0;
}

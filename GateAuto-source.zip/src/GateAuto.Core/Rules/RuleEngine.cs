using System.Text.RegularExpressions;
using GateAuto.Core.Models;

namespace GateAuto.Core.Rules;

/// <summary>
/// 规则引擎。输入订单事实，输出可直接填入电子闸口的字段值。
/// 规则全部来自 <see cref="RuleTable"/>，新增来源单号规则只需改 rules.json。
/// </summary>
public sealed class RuleEngine
{
    private readonly RuleTable _table;
    private readonly List<ExitTypeRule> _exitRules;
    private readonly List<(CargoTypeRule Rule, Regex Regex)> _cargoRules;
    private readonly List<VendorCodeRule> _vendorCodeRules;
    private readonly Regex _domesticRegex;
    private readonly Regex? _parkRegex;

    public RuleEngine(RuleTable table)
    {
        ArgumentNullException.ThrowIfNull(table);

        _table = table;
        _exitRules = [.. table.ExitTypeRules.OrderBy(r => r.Priority)];
        _cargoRules = [.. table.CargoTypeRules
            .OrderBy(r => r.Priority)
            .Select(r => (r, new Regex(r.Pattern, RegexOptions.Compiled)))];
        _vendorCodeRules = [.. table.VendorCodeRules.OrderBy(r => r.Priority)];
        _domesticRegex = new Regex(table.VendorType.DomesticPattern, RegexOptions.Compiled);
        _parkRegex = string.IsNullOrWhiteSpace(table.UnloadingPark.ExtractPattern)
            ? null
            : new Regex(table.UnloadingPark.ExtractPattern, RegexOptions.Compiled);
    }

    public RuleTable Table => _table;

    public RuleEvaluation Evaluate(OrderInfo order)
    {
        ArgumentNullException.ThrowIfNull(order);

        var errors = new List<string>();
        var warnings = new List<string>();

        var sourceNos = order.SourceNos.Where(s => !string.IsNullOrWhiteSpace(s)).Select(s => s.Trim()).ToList();
        if (sourceNos.Count == 0)
        {
            errors.Add("訂單缺少來源單號");
        }

        // 逐笔来源单号判定；第一笔为建单依据，其余仅用于不一致提示。
        var perSource = sourceNos.Select(sn =>
        {
            var prefix = SourceNoParser.PrefixOf(sn);
            return new SourceEvaluation(
                SourceNo: sn,
                Prefix: prefix,
                ExitRule: _exitRules.FirstOrDefault(r => MatchesPrefix(r.Prefix, r.CaseSensitive, prefix)),
                CargoType: ResolveCargoType(prefix),
                VendorCode: ResolveVendorCode(prefix, order.VendorCode));
        }).ToList();

        var first = perSource.FirstOrDefault();

        if (first is not null && first.ExitRule is null)
        {
            errors.Add($"來源單號 {first.SourceNo} 未命中任何出閘類別規則");
        }

        WarnOnConflicts(perSource, warnings);

        var vendorCode = first?.VendorCode;
        if (string.IsNullOrWhiteSpace(vendorCode))
        {
            errors.Add("訂單缺少廠商代碼");
        }

        var deliveryAddress = order.DeliveryAddress?.Trim() ?? string.Empty;
        var vendorType = ResolveVendorType(deliveryAddress, warnings);

        string? unloadingPark = null;
        if (_table.UnloadingPark.ApplyForVendorTypes.Contains(vendorType))
        {
            unloadingPark = ExtractPark(deliveryAddress);
            if (string.IsNullOrWhiteSpace(unloadingPark))
            {
                warnings.Add($"廠商類型為{vendorType}，但無法從送貨地址判定落貨園區");
            }
        }

        var unloadAddress = string.IsNullOrWhiteSpace(order.UnloadAddress)
            ? deliveryAddress
            : order.UnloadAddress.Trim();
        if (string.IsNullOrWhiteSpace(unloadAddress))
        {
            warnings.Add("訂單缺少落貨地址");
        }

        var loadingAddress = order.LoadingAddress?.Trim() ?? string.Empty;
        if (string.IsNullOrWhiteSpace(loadingAddress))
        {
            errors.Add("訂單缺少裝貨地址（需從訂單識別，不得寫死）");
        }

        var packingMethod = order.PackingMethod?.Trim() ?? string.Empty;
        if (string.IsNullOrWhiteSpace(packingMethod))
        {
            errors.Add("訂單缺少包裝方式");
        }

        return new RuleEvaluation
        {
            Order = order,
            FixedFields = _table.Fixed,
            ExitTypeCode = first?.ExitRule?.Code,
            ExitTypeName = first?.ExitRule?.Name,
            MatchedPrefix = first?.Prefix,
            CargoType = first?.CargoType,
            VendorCode = vendorCode,
            VendorType = vendorType,
            UnloadingPark = unloadingPark,
            UnloadingAddress = unloadAddress,
            LoadingAddress = loadingAddress,
            PackingMethod = packingMethod,
            SourceNosText = SourceNoParser.Join(sourceNos),
            Errors = errors,
            Warnings = warnings,
        };
    }

    private string ResolveCargoType(string prefix)
    {
        foreach (var (rule, regex) in _cargoRules)
        {
            if (regex.IsMatch(prefix))
            {
                return rule.CargoType;
            }
        }

        return _table.DefaultCargoType;
    }

    private string ResolveVendorCode(string prefix, string orderVendorCode)
    {
        var rule = _vendorCodeRules.FirstOrDefault(r => MatchesPrefix(r.Prefix, r.CaseSensitive, prefix));
        return string.IsNullOrWhiteSpace(rule?.VendorCode) ? orderVendorCode?.Trim() ?? string.Empty : rule.VendorCode;
    }

    private string ResolveVendorType(string deliveryAddress, List<string> warnings)
    {
        if (string.IsNullOrWhiteSpace(deliveryAddress))
        {
            warnings.Add($"送貨地址為空，廠商類型按預設「{_table.VendorType.Default}」處理");
            return _table.VendorType.Default;
        }

        return _domesticRegex.IsMatch(deliveryAddress) ? _table.VendorType.Domestic : _table.VendorType.Default;
    }

    private string? ExtractPark(string deliveryAddress)
    {
        if (string.IsNullOrWhiteSpace(deliveryAddress))
        {
            return null;
        }

        if (_parkRegex is null)
        {
            return deliveryAddress;
        }

        var match = _parkRegex.Match(deliveryAddress);
        if (!match.Success)
        {
            return null;
        }

        for (var i = 1; i < match.Groups.Count; i++)
        {
            if (match.Groups[i].Success && match.Groups[i].Length > 0)
            {
                return match.Groups[i].Value;
            }
        }

        return match.Value;
    }

    private static bool MatchesPrefix(string? rulePrefix, bool caseSensitive, string actualPrefix)
    {
        if (string.IsNullOrWhiteSpace(rulePrefix) || rulePrefix == "*")
        {
            return true;
        }

        return caseSensitive
            ? string.Equals(rulePrefix, actualPrefix, StringComparison.Ordinal)
            : string.Equals(rulePrefix, actualPrefix, StringComparison.OrdinalIgnoreCase);
    }

    private static void WarnOnConflicts(List<SourceEvaluation> perSource, List<string> warnings)
    {
        if (perSource.Count <= 1)
        {
            return;
        }

        var primary = perSource[0];

        var exitCodes = perSource.Select(s => s.ExitRule?.Code ?? string.Empty).Distinct().ToList();
        if (exitCodes.Count > 1)
        {
            warnings.Add(
                $"多來源單號出閘類別不一致（{Describe(perSource, s => s.ExitRule?.Code)}），" +
                $"以第一筆 {primary.SourceNo} 判定的 {primary.ExitRule?.Display} 為準");
        }

        var cargoTypes = perSource.Select(s => s.CargoType).Distinct().ToList();
        if (cargoTypes.Count > 1)
        {
            warnings.Add(
                $"多來源單號貨物性質不一致（{Describe(perSource, s => s.CargoType)}），" +
                $"以第一筆 {primary.SourceNo} 判定的 {primary.CargoType} 為準");
        }

        var vendorCodes = perSource.Select(s => s.VendorCode).Distinct().ToList();
        if (vendorCodes.Count > 1)
        {
            warnings.Add(
                $"多來源單號廠商代碼不一致（{Describe(perSource, s => s.VendorCode)}），" +
                $"以第一筆 {primary.SourceNo} 判定的 {primary.VendorCode} 為準");
        }
    }

    private static string Describe(List<SourceEvaluation> perSource, Func<SourceEvaluation, string?> selector)
        => string.Join("、", perSource.Select(s => $"{s.SourceNo}={selector(s) ?? "-"}"));

    private sealed record SourceEvaluation(
        string SourceNo,
        string Prefix,
        ExitTypeRule? ExitRule,
        string CargoType,
        string VendorCode);
}

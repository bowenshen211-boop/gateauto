using System.Reflection;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace GateAuto.Core.Rules;

/// <summary>
/// 规则表读取器。默认规则内嵌在程序集里；现场需要调整规则时可改用外部 rules.json。
/// </summary>
public static class RuleTableLoader
{
    private const string EmbeddedResourceName = "GateAuto.Core.rules.json";

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true,
        ReadCommentHandling = JsonCommentHandling.Skip,
        AllowTrailingCommas = true,
    };

    private static readonly Lazy<RuleTable> DefaultTable = new(LoadDefault);

    /// <summary>内嵌的默认规则表（单例）。</summary>
    public static RuleTable Default => DefaultTable.Value;

    public static RuleTable LoadDefault()
    {
        var assembly = typeof(RuleTableLoader).Assembly;
        using var stream = assembly.GetManifestResourceStream(EmbeddedResourceName)
            ?? throw new InvalidOperationException($"找不到内嵌规则表资源：{EmbeddedResourceName}");

        using var reader = new StreamReader(stream);
        return Parse(reader.ReadToEnd());
    }

    public static RuleTable LoadFromFile(string path)
    {
        if (!File.Exists(path))
        {
            throw new FileNotFoundException($"找不到规则表文件：{path}", path);
        }

        return Parse(File.ReadAllText(path));
    }

    public static RuleTable Parse(string json)
    {
        var table = JsonSerializer.Deserialize<RuleTable>(json, JsonOptions)
            ?? throw new InvalidOperationException("规则表内容为空");

        Validate(table);
        return table;
    }

    private static void Validate(RuleTable table)
    {
        if (table.ExitTypeRules.Count == 0)
        {
            throw new InvalidOperationException("规则表缺少 exitTypeRules");
        }

        if (!table.ExitTypeRules.Any(r => r.IsFallback))
        {
            throw new InvalidOperationException("规则表缺少出闸类别兜底规则（prefix = \"*\"）");
        }

        foreach (var rule in table.ExitTypeRules)
        {
            if (string.IsNullOrWhiteSpace(rule.Code))
            {
                throw new InvalidOperationException($"出闸类别规则 {rule.Id} 未设置 code");
            }
        }

        foreach (var rule in table.CargoTypeRules)
        {
            if (string.IsNullOrWhiteSpace(rule.Pattern))
            {
                throw new InvalidOperationException($"货物性质规则 {rule.Id} 未设置 pattern");
            }

            EnsureValidRegex(rule.Pattern, rule.Id);
        }

        foreach (var rule in table.VendorCodeRules.Where(r => !string.IsNullOrWhiteSpace(r.Prefix) && r.Prefix != "*"))
        {
            if (string.IsNullOrWhiteSpace(rule.VendorCode))
            {
                throw new InvalidOperationException($"厂商代码规则 {rule.Id} 未设置 vendorCode");
            }
        }

        EnsureValidRegex(table.VendorType.DomesticPattern, "vendorType.domesticPattern");

        if (!string.IsNullOrWhiteSpace(table.UnloadingPark.ExtractPattern))
        {
            EnsureValidRegex(table.UnloadingPark.ExtractPattern, "unloadingPark.extractPattern");
        }
    }

    private static void EnsureValidRegex(string pattern, string owner)
    {
        try
        {
            _ = new Regex(pattern);
        }
        catch (ArgumentException ex)
        {
            throw new InvalidOperationException($"规则 {owner} 的正则表达式无效：{pattern}", ex);
        }
    }
}

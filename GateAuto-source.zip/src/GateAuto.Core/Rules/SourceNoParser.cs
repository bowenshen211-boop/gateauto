namespace GateAuto.Core.Rules;

/// <summary>来源单号的拆分与拼接。电子闸口接受英文逗号与中文逗号两种分隔符。</summary>
public static class SourceNoParser
{
    private static readonly char[] Separators = [',', '，'];

    /// <summary>把 "A,B，C" 拆成 ["A", "B", "C"]，自动去空白与空项。</summary>
    public static IReadOnlyList<string> Parse(string? raw)
    {
        if (string.IsNullOrWhiteSpace(raw))
        {
            return [];
        }

        return raw.Split(Separators, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
    }

    /// <summary>把多个来源单号拼成电子闸口要求的单个输入值。</summary>
    public static string Join(IEnumerable<string> sourceNos)
        => string.Join(",", sourceNos.Where(s => !string.IsNullOrWhiteSpace(s)).Select(s => s.Trim()));

    /// <summary>取来源单号前三位用于规则判断；不足三位时返回原值。</summary>
    public static string PrefixOf(string sourceNo)
    {
        var value = sourceNo.Trim();
        return value.Length <= 3 ? value : value[..3];
    }
}

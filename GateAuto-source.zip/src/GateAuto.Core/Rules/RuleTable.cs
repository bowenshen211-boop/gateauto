namespace GateAuto.Core.Rules;

/// <summary>
/// 规则表。整份内容来自 rules.json，代码里不写死任何业务值。
/// 规则按 Priority 升序执行，先命中者生效。
/// </summary>
public sealed class RuleTable
{
    public int Version { get; set; } = 1;

    public FixedFields Fixed { get; set; } = new();

    /// <summary>出闸类别规则（R001~R006）。</summary>
    public List<ExitTypeRule> ExitTypeRules { get; set; } = [];

    /// <summary>货物性质规则（R007/R008），按 Priority 升序，先命中者生效。</summary>
    public List<CargoTypeRule> CargoTypeRules { get; set; } = [];

    /// <summary>所有货物性质规则都未命中时的取值。</summary>
    public string DefaultCargoType { get; set; } = "非保稅";

    /// <summary>厂商代码规则（R009）。未命中则使用订单自带的厂商代码。</summary>
    public List<VendorCodeRule> VendorCodeRules { get; set; } = [];

    public VendorTypeRule VendorType { get; set; } = new();

    public UnloadingParkRule UnloadingPark { get; set; } = new();
}

/// <summary>电子闸口新增页的固定字段（需求规格 二、固定资料）。</summary>
public sealed class FixedFields
{
    public string DeclarationType { get; set; } = "貨物";

    public string LegalEntity { get; set; } = "1405930037-富晋精密工业（晋城）有限公司";

    public string ApplyDepartment { get; set; } = "TGB005-Fundamental&Connection";

    public string TransportMode { get; set; } = "公路運輸";

    public string LoadingPark { get; set; } = "華北-晉城市-晉城園區-B區-C1";

    /// <summary>「有来源添加」弹窗中固定选择的来源类型。</summary>
    public string SourceType { get; set; } = "外銷";
}

/// <summary>出闸类别规则：按来源单号前三位匹配。</summary>
public sealed class ExitTypeRule
{
    public string Id { get; set; } = string.Empty;

    public int Priority { get; set; } = 100;

    /// <summary>来源单号前三位；"*" 表示匹配全部（默认规则）。</summary>
    public string Prefix { get; set; } = "*";

    /// <summary>true 表示必须完全一致才命中，false 表示忽略大小写。</summary>
    public bool CaseSensitive { get; set; } = true;

    /// <summary>出闸类别代码，例如 087。</summary>
    public string Code { get; set; } = string.Empty;

    /// <summary>出闸类别名称，例如 不返廠貨樣。</summary>
    public string Name { get; set; } = string.Empty;

    public string Display => string.IsNullOrEmpty(Name) ? Code : $"{Code}-{Name}";

    public bool IsFallback => Prefix is "*" or "";
}

/// <summary>货物性质规则：对来源单号前三位做正则匹配。</summary>
public sealed class CargoTypeRule
{
    public string Id { get; set; } = string.Empty;

    public int Priority { get; set; } = 100;

    /// <summary>正则表达式，例如 ^[A-Z]{3}$。</summary>
    public string Pattern { get; set; } = string.Empty;

    public string CargoType { get; set; } = string.Empty;
}

/// <summary>厂商代码规则：命中时覆盖订单中的厂商代码。</summary>
public sealed class VendorCodeRule
{
    public string Id { get; set; } = string.Empty;

    public int Priority { get; set; } = 100;

    /// <summary>来源单号前三位；"*" 表示匹配全部。</summary>
    public string Prefix { get; set; } = "*";

    public bool CaseSensitive { get; set; } = true;

    public string VendorCode { get; set; } = string.Empty;
}

/// <summary>厂商类型规则：默认集团外，送货地址命中园区时视为集团国内。</summary>
public sealed class VendorTypeRule
{
    public string Default { get; set; } = "集團外";

    public string Domestic { get; set; } = "集團國內";

    /// <summary>
    /// 判定为集团国内的送货地址正则。
    /// 兼容「晉城園區B區」与「晉城園區-B區-C1」两种写法。
    /// </summary>
    public string DomesticPattern { get; set; } = @"園區[-\s]*[A-D][-\s]*區";
}

/// <summary>落货园区规则：仅特定厂商类型才填写。</summary>
public sealed class UnloadingParkRule
{
    /// <summary>需要填写落货园区的厂商类型。</summary>
    public List<string> ApplyForVendorTypes { get; set; } = ["集團國內"];

    /// <summary>
    /// 从送货地址提取落货园区的正则（取第 1 个捕获组）。
    /// 为空表示直接使用完整送货地址。
    /// </summary>
    public string? ExtractPattern { get; set; }
}

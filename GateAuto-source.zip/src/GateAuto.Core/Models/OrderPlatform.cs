namespace GateAuto.Core.Models;

/// <summary>
/// 订单来源平台。关务物流平台与云富通管理平台是两个彼此独立的取单平台：
/// 两边不存在信息互补，各自取得的订单信息本身就是完整的，不做任何跨平台字段合并。
/// </summary>
public enum OrderPlatform
{
    /// <summary>关务物流平台。</summary>
    CustomsLogistics = 0,

    /// <summary>云富通管理平台。</summary>
    YunFuTong = 1,
}

/// <summary>平台名称的显示文字与解析（兼容简体、繁体与英文写法）。</summary>
public static class OrderPlatforms
{
    public const string CustomsLogisticsText = "關務物流";

    public const string YunFuTongText = "雲富通";

    private static readonly string[] CustomsLogisticsAliases =
    [
        "關務物流平台", "关务物流平台",
        "關務物流", "关务物流",
        "customslogistics", "customs", "logistics",
    ];

    private static readonly string[] YunFuTongAliases =
    [
        "雲富通管理平台", "云富通管理平台",
        "雲富通平台", "云富通平台",
        "雲富通", "云富通",
        "yunfutong", "yft",
    ];

    public static string ToDisplay(this OrderPlatform platform) => platform switch
    {
        OrderPlatform.YunFuTong => YunFuTongText,
        _ => CustomsLogisticsText,
    };

    /// <summary>把界面/CSV 中的平台文字解析成枚举；无法识别时返回 <paramref name="fallback"/>。</summary>
    public static OrderPlatform Parse(string? text, OrderPlatform fallback = OrderPlatform.CustomsLogistics)
    {
        var normalized = Normalize(text);
        if (normalized.Length == 0)
        {
            return fallback;
        }

        if (YunFuTongAliases.Contains(normalized, StringComparer.Ordinal))
        {
            return OrderPlatform.YunFuTong;
        }

        if (CustomsLogisticsAliases.Contains(normalized, StringComparer.Ordinal))
        {
            return OrderPlatform.CustomsLogistics;
        }

        return fallback;
    }

    /// <summary>平台文字是否可识别。空字符串视为未填写（可识别）。</summary>
    public static bool IsKnown(string? text)
    {
        var normalized = Normalize(text);
        if (normalized.Length == 0)
        {
            return true;
        }

        return YunFuTongAliases.Contains(normalized, StringComparer.Ordinal)
            || CustomsLogisticsAliases.Contains(normalized, StringComparer.Ordinal);
    }

    private static string Normalize(string? text)
        => string.IsNullOrWhiteSpace(text)
            ? string.Empty
            : text.Trim().Replace(" ", string.Empty).ToLowerInvariant();
}

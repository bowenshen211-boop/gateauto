namespace GateAuto.Core.Models;

/// <summary>
/// 一笔完整的订单数据。订单只来自一个平台（关务物流或云富通），
/// 该平台取到的信息即为完整信息，不做跨平台合并；
/// 这里只承载"原始事实"，任何判断结果都由 <see cref="Rules.RuleEngine"/> 产出。
/// </summary>
public sealed class OrderInfo
{
    /// <summary>订单来源平台。</summary>
    public OrderPlatform Platform { get; init; } = OrderPlatform.CustomsLogistics;

    /// <summary>申请编号（在所属平台内唯一）。</summary>
    public string ApplyNo { get; init; } = string.Empty;

    /// <summary>来源单号，可能有多笔（如 5CS-QB0081 / UCJ-123456 / UCN-888888）。</summary>
    public IReadOnlyList<string> SourceNos { get; init; } = [];

    /// <summary>送货地址。落货园区与厂商类型均据此判断。</summary>
    public string DeliveryAddress { get; init; } = string.Empty;

    /// <summary>件数。</summary>
    public int PackageCount { get; init; }

    /// <summary>毛重（kg）。</summary>
    public decimal GrossWeightKg { get; init; }

    /// <summary>净重（kg）。</summary>
    public decimal NetWeightKg { get; init; }

    /// <summary>包装方式，例如「22-紙製或纖維板製裝盒/箱」，原样带入电子闸口。</summary>
    public string PackingMethod { get; init; } = string.Empty;

    /// <summary>订单中的厂商代码。5CS 以外的来源单号直接使用此值。</summary>
    public string VendorCode { get; init; } = string.Empty;

    /// <summary>装货地址（如 A1 / B1 / C1），必须从订单识别，不得写死。</summary>
    public string LoadingAddress { get; init; } = string.Empty;

    /// <summary>收货方。</summary>
    public string Consignee { get; init; } = string.Empty;

    /// <summary>落货地址，缺省时回退到送货地址。</summary>
    public string UnloadAddress { get; init; } = string.Empty;

    /// <summary>目的地（待派车清单显示用，例如「深圳」）。缺省时使用落货地址。</summary>
    public string Destination { get; init; } = string.Empty;
}

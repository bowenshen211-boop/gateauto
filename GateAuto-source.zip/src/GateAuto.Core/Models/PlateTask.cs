namespace GateAuto.Core.Models;

/// <summary>待派车清单中的状态值。</summary>
public static class PlateTaskStatus
{
    public const string Pending = "待派車";
    public const string Updated = "已更新";
    public const string Failed = "失敗";
}

/// <summary>
/// 待派车清单的一条记录。建单成功拿到 LQE 放行单号后写入，车牌由后续独立流程补录。
/// </summary>
public sealed class PlateTask
{
    public long Id { get; init; }

    /// <summary>LQE 放行单号，例如 LQE-261132362。</summary>
    public required string LqeNo { get; init; }

    /// <summary>目的地，例如「深圳」。</summary>
    public string Destination { get; init; } = string.Empty;

    /// <summary>件数。</summary>
    public int PackageCount { get; init; }

    /// <summary>重量（kg）。显示时使用 <see cref="WeightText"/>。</summary>
    public decimal WeightKg { get; init; }

    /// <summary>车牌号，派车前为空。</summary>
    public string? PlateNo { get; init; }

    public string Status { get; init; } = PlateTaskStatus.Pending;

    public DateTimeOffset CreatedAt { get; init; }

    public DateTimeOffset? UpdatedAt { get; init; }

    /// <summary>电子闸口清单里显示的重量文本，例如「11KG」。</summary>
    public string WeightText => $"{WeightKg:0.##}KG";

    public bool HasPlate => !string.IsNullOrWhiteSpace(PlateNo);
}

namespace GateAuto.Core.Models;

/// <summary>建单流程中订单的状态。</summary>
public static class OrderStatus
{
    /// <summary>已抓取，尚未建单。</summary>
    public const string Pending = "待建單";

    /// <summary>正在电子闸口建单。</summary>
    public const string Creating = "建單中";

    /// <summary>建单成功并已取得 LQE 放行单号。</summary>
    public const string Created = "已建單";

    /// <summary>建单失败，需人工处理。</summary>
    public const string Failed = "失敗";
}

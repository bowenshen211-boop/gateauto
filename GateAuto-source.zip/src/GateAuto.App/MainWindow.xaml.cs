using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using GateAuto.App.Services;
using GateAuto.Automation;
using GateAuto.Automation.Workflows;
using GateAuto.Core.Models;
using GateAuto.Core.Rules;
using GateAuto.Data;
using Microsoft.Win32;

namespace GateAuto.App;

public partial class MainWindow : Window
{
    private readonly AppSettingsStore _settingsStore;
    private readonly AppSettings _settings;
    private readonly AppLogger _logger;
    private readonly GateAutoDatabase _database;
    private readonly OrderRepository _orders;
    private readonly PlateTaskRepository _plateTasks;
    private readonly RuleEngine _engine;
    private readonly GateCoordinator _gate;

    private readonly ObservableCollection<PlateTaskRow> _plateRows = [];
    private readonly Dictionary<OrderPlatform, PlatformWorkWindow> _platformWindows = [];

    private bool _busy;

    public MainWindow()
    {
        InitializeComponent();
        ClampToScreen();

        _settingsStore = new AppSettingsStore(AppPaths.SettingsFile);
        _settings = _settingsStore.Load();

        _logger = new AppLogger(AppPaths.LogDirectory);
        _logger.Written += OnLogWritten;

        _database = new GateAutoDatabase(AppPaths.DatabaseFile);
        _database.Initialize();

        _orders = new OrderRepository(_database);
        _plateTasks = new PlateTaskRepository(_database);
        _engine = new RuleEngine(RuleTableLoader.Default);
        _gate = new GateCoordinator(_logger);

        gridPlates.ItemsSource = _plateRows;
        ApplySettingsToUi();
        RefreshPlateTasks();
        RefreshPlatformCards();

        Activated += (_, _) => RefreshPlatformCards();

        _logger.Info($"應用啟動，資料庫：{AppPaths.DatabaseFile}");
        if (string.IsNullOrWhiteSpace(_settings.AddOrderUrl))
        {
            _logger.Info("未設定新增建單頁網址，建單時會在清單頁點擊「新增」進入");
        }
    }

    protected override void OnClosed(EventArgs e)
    {
        base.OnClosed(e);

        try
        {
            Task.Run(() => _gate.DisposeAsync().AsTask()).Wait(TimeSpan.FromSeconds(5));
        }
        catch (Exception ex) when (ex is AggregateException or InvalidOperationException)
        {
            // 關閉時的瀏覽器清理失敗不影響退出。
        }
    }

    // ==================== 平台工作區 ====================

    private void OpenCustoms_Click(object sender, RoutedEventArgs e) => OpenWorkspace(OrderPlatform.CustomsLogistics);

    private void OpenYunFuTong_Click(object sender, RoutedEventArgs e) => OpenWorkspace(OrderPlatform.YunFuTong);

    /// <summary>打开（或激活）指定平台的工作区窗口。</summary>
    public void OpenWorkspace(OrderPlatform platform)
    {
        if (_platformWindows.TryGetValue(platform, out var existing))
        {
            existing.WindowState = WindowState.Normal;
            existing.Activate();
            return;
        }

        var window = new PlatformWorkWindow(
            platform,
            _settingsStore,
            _settings,
            _logger,
            _orders,
            _plateTasks,
            _engine,
            _gate);

        window.PlateTasksChanged += (_, _) => RefreshPlateTasks();
        window.Closed += (_, _) =>
        {
            _platformWindows.Remove(platform);
            RefreshPlatformCards();
        };

        _platformWindows[platform] = window;
        window.Show();
        RefreshPlatformCards();
    }

    private async void LoginCustoms_Click(object sender, RoutedEventArgs e) => await LoginPlatformAsync(OrderPlatform.CustomsLogistics);

    private async void LoginYunFuTong_Click(object sender, RoutedEventArgs e) => await LoginPlatformAsync(OrderPlatform.YunFuTong);

    private async Task LoginPlatformAsync(OrderPlatform platform)
    {
        var sessionKey = platform == OrderPlatform.YunFuTong ? SessionKeys.YunFuTong : SessionKeys.Customs;
        var login = _settings.LoginOf(platform);

        await RunAsync("開啟平台登入", async () =>
        {
            await _gate.OpenPlatformAsync(sessionKey, _settings, _settings.UrlOf(platform), login.Account, login.Password);
            _logger.Info($"已開啟 {platform.ToDisplay()} 登入頁");
        });
    }

    private void RefreshPlatformCards()
    {
        var customs = _settings.CustomsLogin;
        lblCustomsAccount.Text = customs.HasAccount ? customs.Account : "尚未設定";
        lblCustomsState.Text = _platformWindows.ContainsKey(OrderPlatform.CustomsLogistics) ? "工作區已開啟，可開始建單" : "工作區未開啟";

        var yunFuTong = _settings.YunFuTongLogin;
        lblYunFuTongAccount.Text = yunFuTong.HasAccount ? yunFuTong.Account : "尚未設定";
        lblYunFuTongState.Text = _platformWindows.ContainsKey(OrderPlatform.YunFuTong) ? "工作區已開啟，可開始建單" : "工作區未開啟";
    }

    private void Tabs_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (e.Source is TabControl control && control.SelectedIndex == 1)
        {
            RefreshPlateTasks();
        }
    }

    // ==================== 待派車 ====================

    private void RefreshPlates_Click(object sender, RoutedEventArgs e) => RefreshPlateTasks();

    private void ImportPlates_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog
        {
            Title = "選擇車牌 CSV",
            Filter = "CSV 檔案 (*.csv)|*.csv|所有檔案 (*.*)|*.*",
        };

        if (dialog.ShowDialog(this) != true)
        {
            return;
        }

        var imported = PlateCsvImporter.Load(dialog.FileName);

        foreach (var error in imported.Errors)
        {
            _logger.Warn(error);
        }

        var applied = 0;
        foreach (var item in imported.Rows)
        {
            var row = _plateRows.FirstOrDefault(r =>
                string.Equals(r.LqeNo, item.LqeNo, StringComparison.OrdinalIgnoreCase));

            if (row is null)
            {
                _logger.Warn($"車牌 {item.PlateNo}：待派車清單中找不到放行單號 {item.LqeNo}");
                continue;
            }

            row.PlateNo = item.PlateNo;
            applied++;
        }

        _logger.Info($"匯入車牌 {applied} 筆（來源：{Path.GetFileName(dialog.FileName)}）");
    }

    private async void ApplyPlates_Click(object sender, RoutedEventArgs e)
    {
        var selected = gridPlates.SelectedItems.Cast<PlateTaskRow>().ToList();
        var rows = (selected.Count > 0 ? selected : _plateRows.ToList())
            .Where(r => !string.IsNullOrWhiteSpace(r.PlateNo))
            .Where(r => r.Status != PlateTaskStatus.Updated)
            .ToList();

        if (rows.Count == 0)
        {
            MessageBox.Show("沒有需要修改車牌的資料（請先輸入或匯入車牌）。", "修改車牌", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        var success = 0;
        var failed = 0;

        await RunAsync("修改車牌", async () =>
        {
            await _gate.GateLock.WaitAsync();
            try
            {
                var service = await _gate.GetServiceAsync(_settings, BuildSelectors());
                var workflow = new PlateUpdateWorkflow(_plateTasks, service);

                foreach (var row in rows)
                {
                    row.Status = "更新中…";
                    _logger.Info($"開始修改車牌：{row.LqeNo} → {row.PlateNo}");

                    var outcome = await workflow.UpdateAsync(row.LqeNo, row.PlateNo);

                    if (outcome.Success)
                    {
                        success++;
                        row.Status = PlateTaskStatus.Updated;
                        _logger.Info($"修改車牌成功：{row.LqeNo} → {row.PlateNo}");
                    }
                    else
                    {
                        failed++;
                        row.Status = PlateTaskStatus.Failed;
                        _logger.Error($"修改車牌失敗：{row.LqeNo} → {outcome.Error}");
                    }
                }
            }
            finally
            {
                _gate.GateLock.Release();
            }
        });

        MessageBox.Show(
            $"修改車牌完成：成功 {success} 筆，失敗 {failed} 筆。",
            "修改車牌結果",
            MessageBoxButton.OK,
            failed > 0 ? MessageBoxImage.Warning : MessageBoxImage.Information);
    }

    private void RefreshPlateTasks()
    {
        _plateRows.Clear();
        foreach (var task in _plateTasks.ListAll())
        {
            _plateRows.Add(PlateTaskRow.From(task));
        }
    }

    // ==================== 設定 ====================

    private void ApplySettingsToUi()
    {
        txtGateUrl.Text = _settings.GateUrl;
        txtAddOrderUrl.Text = _settings.AddOrderUrl;
        txtCustomsUrl.Text = _settings.CustomsUrl;
        txtYunFuTongUrl.Text = _settings.YunFuTongUrl;
        txtTimeout.Text = _settings.TimeoutSeconds.ToString(CultureInfo.InvariantCulture);
        txtQueryTimeout.Text = _settings.QueryTimeoutSeconds.ToString(CultureInfo.InvariantCulture);
        txtLqeTimeout.Text = _settings.LqeTimeoutSeconds.ToString(CultureInfo.InvariantCulture);
        txtUserDataDir.Text = _settings.UserDataDirectory;
        chkSimplified.IsChecked = _settings.UseSimplifiedChinese;
        chkHeadless.IsChecked = _settings.Headless;
        cboChannel.SelectedIndex = string.Equals(_settings.BrowserChannel, "chrome", StringComparison.OrdinalIgnoreCase) ? 1 : 0;
    }

    private void ReadSettingsFromUi()
    {
        _settings.GateUrl = txtGateUrl.Text.Trim();
        _settings.AddOrderUrl = txtAddOrderUrl.Text.Trim();
        _settings.CustomsUrl = txtCustomsUrl.Text.Trim();
        _settings.YunFuTongUrl = txtYunFuTongUrl.Text.Trim();
        _settings.TimeoutSeconds = UiText.ParseInt(txtTimeout.Text, 30);
        _settings.QueryTimeoutSeconds = UiText.ParseInt(txtQueryTimeout.Text, 60);
        _settings.LqeTimeoutSeconds = UiText.ParseInt(txtLqeTimeout.Text, 60);
        _settings.UserDataDirectory = txtUserDataDir.Text.Trim();
        _settings.UseSimplifiedChinese = chkSimplified.IsChecked == true;
        _settings.Headless = chkHeadless.IsChecked == true;
        _settings.BrowserChannel = cboChannel.SelectedIndex == 1 ? "chrome" : "msedge";
    }

    private async void SaveSettings_Click(object sender, RoutedEventArgs e)
    {
        await RunAsync("保存設定", async () =>
        {
            ReadSettingsFromUi();
            _settingsStore.Save(_settings);
            await _gate.ResetAsync();
            _logger.Info($"設定已保存：{AppPaths.SettingsFile}");
            RefreshPlatformCards();
        });

        MessageBox.Show("設定已保存。", "設定", MessageBoxButton.OK, MessageBoxImage.Information);
    }

    private async void OpenLogin_Click(object sender, RoutedEventArgs e)
    {
        await RunAsync("開啟瀏覽器", async () =>
        {
            ReadSettingsFromUi();
            _settingsStore.Save(_settings);
            await _gate.OpenForLoginAsync(_settings);
        });
    }

    private void OpenLogFolder_Click(object sender, RoutedEventArgs e)
    {
        Directory.CreateDirectory(AppPaths.LogDirectory);
        Process.Start(new ProcessStartInfo("explorer.exe", AppPaths.LogDirectory) { UseShellExecute = true });
    }

    private void ClearLog_Click(object sender, RoutedEventArgs e) => txtLog.Clear();

    // ==================== 開發者控制台 ====================

    private void DiagnosticHelp_Click(object sender, RoutedEventArgs e)
        => AppendDiagnosticOutput(PageDiagnostics.HelpText);

    private void ClearDiagnostic_Click(object sender, RoutedEventArgs e) => txtDiagnosticOutput.Clear();

    private void OpenDiagnosticFolder_Click(object sender, RoutedEventArgs e)
    {
        Directory.CreateDirectory(_logger.DiagnosticDirectory);
        Process.Start(new ProcessStartInfo("explorer.exe", _logger.DiagnosticDirectory) { UseShellExecute = true });
    }

    private async void DiagnosticCommand_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key != Key.Enter)
        {
            return;
        }

        e.Handled = true;
        await ExecuteDiagnosticAsync();
    }

    private async void ExecuteDiagnostic_Click(object sender, RoutedEventArgs e) => await ExecuteDiagnosticAsync();

    private async void SaveHtml_Click(object sender, RoutedEventArgs e) => await ExecuteDiagnosticAsync("savehtml");

    private async Task ExecuteDiagnosticAsync(string? commandOverride = null)
    {
        var input = (commandOverride ?? txtDiagnosticCommand.Text).Trim();
        if (input.Length == 0)
        {
            AppendDiagnosticOutput("請先輸入命令；輸入 help 查看全部只讀命令。");
            return;
        }

        if (string.Equals(input, "help", StringComparison.OrdinalIgnoreCase))
        {
            AppendDiagnosticOutput(PageDiagnostics.HelpText);
            return;
        }

        if (string.Equals(input, "clear", StringComparison.OrdinalIgnoreCase))
        {
            txtDiagnosticOutput.Clear();
            return;
        }

        var target = cboDiagnosticTarget.SelectedIndex switch
        {
            1 => SessionKeys.YunFuTong,
            2 => SessionKeys.Gate,
            _ => SessionKeys.Customs,
        };

        await RunAsync("網頁診斷", async () =>
        {
            AppendDiagnosticOutput($"> {DiagnosticTargetName(target)} / {input}");

            try
            {
                var result = await _gate.DiagnoseAsync(
                    target,
                    input,
                    _logger.DiagnosticDirectory,
                    DiagnosticSensitiveValues(target));

                var logPath = _logger.WriteDiagnostic(
                    target,
                    result.Command,
                    result.Url,
                    true,
                    result.Content,
                    result.ScreenshotPath,
                    null);

                AppendDiagnosticOutput(PageDiagnostics.Preview(result.Content));
                AppendDiagnosticArtifacts(result.ScreenshotPath, result.SavedHtmlPath, logPath);
                _logger.Info($"網頁診斷完成：{DiagnosticTargetName(target)} / {result.Command}");
            }
            catch (Exception ex)
            {
                var logPath = _logger.WriteDiagnostic(target, input, null, false, null, null, ex.Message);
                AppendDiagnosticOutput($"錯誤：{ex.Message}");
                AppendDiagnosticArtifacts(null, null, logPath);
                _logger.Warn($"網頁診斷失敗：{DiagnosticTargetName(target)}：{ex.Message}");
            }
        });
    }

    private IReadOnlyList<string> DiagnosticSensitiveValues(string target)
    {
        var login = target switch
        {
            SessionKeys.Customs => _settings.CustomsLogin,
            SessionKeys.YunFuTong => _settings.YunFuTongLogin,
            _ => null,
        };

        if (login is null)
        {
            return [];
        }

        return new[] { login.Account, login.Password }
            .Where(value => !string.IsNullOrWhiteSpace(value))
            .Distinct(StringComparer.Ordinal)
            .ToArray();
    }

    private static string DiagnosticTargetName(string target) => target switch
    {
        SessionKeys.Customs => "關務物流",
        SessionKeys.YunFuTong => "雲富通",
        SessionKeys.Gate => "電子閘口",
        _ => target,
    };

    private void AppendDiagnosticArtifacts(string? screenshotPath, string? savedHtmlPath, string? logPath)
    {
        if (!string.IsNullOrWhiteSpace(screenshotPath))
        {
            AppendDiagnosticOutput($"截圖：{screenshotPath}");
        }

        if (!string.IsNullOrWhiteSpace(savedHtmlPath))
        {
            AppendDiagnosticOutput($"HTML：{savedHtmlPath}");
        }

        AppendDiagnosticOutput(logPath is null
            ? "診斷日誌寫入失敗，請檢查日誌目錄權限。"
            : $"診斷日誌：{logPath}");
    }

    private void AppendDiagnosticOutput(string text)
    {
        if (txtDiagnosticOutput.Text.Length > 0)
        {
            txtDiagnosticOutput.AppendText(Environment.NewLine);
        }

        txtDiagnosticOutput.AppendText(text.TrimEnd() + Environment.NewLine);
        txtDiagnosticOutput.ScrollToEnd();
    }

    // ==================== 公共 ====================

    private EGateSelectors BuildSelectors() => new()
    {
        TextVariant = _settings.UseSimplifiedChinese ? EGateTextVariant.Simplified : EGateTextVariant.Traditional,
        Timeout = TimeSpan.FromSeconds(Math.Max(5, _settings.TimeoutSeconds)),
        QueryTimeout = TimeSpan.FromSeconds(Math.Max(5, _settings.QueryTimeoutSeconds)),
        LqeTimeout = TimeSpan.FromSeconds(Math.Max(5, _settings.LqeTimeoutSeconds)),
    };

    private async Task RunAsync(string operation, Func<Task> action)
    {
        if (_busy)
        {
            MessageBox.Show("目前有作業正在執行，請稍候。", operation, MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        _busy = true;
        lblBusy.Text = $"{operation} 執行中…";

        try
        {
            await action();
        }
        catch (Exception ex)
        {
            _logger.Error($"{operation} 失敗：{ex.Message}");
            MessageBox.Show(ex.Message, operation, MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            _busy = false;
            lblBusy.Text = "就緒";
        }
    }

    private void OnLogWritten(string line)
    {
        if (!Dispatcher.CheckAccess())
        {
            Dispatcher.BeginInvoke(() => AppendLog(line));
            return;
        }

        AppendLog(line);
    }

    private void AppendLog(string line)
    {
        txtLog.AppendText(line + Environment.NewLine);
        txtLog.ScrollToEnd();
    }

    /// <summary>小螢幕上自動縮到可用工作區，避免視窗超出畫面。</summary>
    private void ClampToScreen()
    {
        var area = SystemParameters.WorkArea;
        if (Width > area.Width)
        {
            Width = Math.Max(MinWidth, area.Width - 24);
        }

        if (Height > area.Height)
        {
            Height = Math.Max(MinHeight, area.Height - 24);
        }
    }
}

using System.Diagnostics;
using System.IO;
using System.Text.Json;

namespace GateAuto.App.Services;

/// <summary>平台登入資訊。密碼以目前 Windows 使用者金鑰加密後才寫入設定檔。</summary>
public sealed class PlatformLogin
{
    public string Account { get; set; } = string.Empty;

    /// <summary>加密後的密碼（Base64）。</summary>
    public string PasswordCipher { get; set; } = string.Empty;

    [System.Text.Json.Serialization.JsonIgnore]
    public string Password
    {
        get => SecretProtector.Unprotect(PasswordCipher);
        set => PasswordCipher = SecretProtector.Protect(value);
    }

    public bool HasAccount => !string.IsNullOrWhiteSpace(Account);
}

/// <summary>应用设置。保存为 JSON，修改后立即生效。</summary>
public sealed class AppSettings
{
    /// <summary>电子闸口清单页网址。</summary>
    public string GateUrl { get; set; } = "https://fgate.efoxconn.com/portal/goodsInOutCenter/goodsExit";

    /// <summary>新增建单页网址。留空时在清单页点击「新增」进入。</summary>
    public string AddOrderUrl { get; set; } = string.Empty;

    /// <summary>关务物流平台登入页网址。</summary>
    public string CustomsUrl { get; set; } = "https://cclm.efoxconn.com/newciq/";

    /// <summary>云富通管理平台登入页网址。</summary>
    public string YunFuTongUrl { get; set; } = "http://10.65.3.1/jcsc/main.action";

    /// <summary>关务物流平台的帐号密码。</summary>
    public PlatformLogin CustomsLogin { get; set; } = new();

    /// <summary>云富通管理平台的帐号密码。</summary>
    public PlatformLogin YunFuTongLogin { get; set; } = new();

    /// <summary>取指定平台的登入資訊。</summary>
    public PlatformLogin LoginOf(GateAuto.Core.Models.OrderPlatform platform)
        => platform == GateAuto.Core.Models.OrderPlatform.YunFuTong ? YunFuTongLogin : CustomsLogin;

    /// <summary>取指定平台的登入页网址。</summary>
    public string UrlOf(GateAuto.Core.Models.OrderPlatform platform)
        => platform == GateAuto.Core.Models.OrderPlatform.YunFuTong ? YunFuTongUrl : CustomsUrl;

    /// <summary>电子闸口界面是否为简体；默认繁体。</summary>
    public bool UseSimplifiedChinese { get; set; }

    /// <summary>无头模式。需要人工登录时必须关闭。</summary>
    public bool Headless { get; set; }

    /// <summary>浏览器通道：msedge / chrome。</summary>
    public string BrowserChannel { get; set; } = "msedge";

    /// <summary>浏览器用户资料目录，用于复用登录状态。</summary>
    public string UserDataDirectory { get; set; } = Path.Combine(AppPaths.DataDirectory, "browser-profile");

    public int TimeoutSeconds { get; set; } = 30;

    public int QueryTimeoutSeconds { get; set; } = 60;

    public int LqeTimeoutSeconds { get; set; } = 60;
}

/// <summary>设置文件的读写。</summary>
public sealed class AppSettingsStore
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
    };

    public AppSettingsStore(string filePath)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(filePath);
        FilePath = filePath;
    }

    public string FilePath { get; }

    public AppSettings Load()
    {
        if (!File.Exists(FilePath))
        {
            return new AppSettings();
        }

        try
        {
            var json = File.ReadAllText(FilePath);
            return JsonSerializer.Deserialize<AppSettings>(json) ?? new AppSettings();
        }
        catch (Exception ex) when (ex is IOException or JsonException)
        {
            Debug.WriteLine($"读取设置失败：{ex.Message}");
            return new AppSettings();
        }
    }

    public void Save(AppSettings settings)
    {
        ArgumentNullException.ThrowIfNull(settings);

        var directory = Path.GetDirectoryName(FilePath);
        if (!string.IsNullOrEmpty(directory))
        {
            Directory.CreateDirectory(directory);
        }

        File.WriteAllText(FilePath, JsonSerializer.Serialize(settings, JsonOptions));
    }
}

/// <summary>应用数据路径：数据库、设置、日志统一放在本机应用数据目录。</summary>
public static class AppPaths
{
    public static string DataDirectory { get; } = ResolveDataDirectory();

    public static string DatabaseFile => Path.Combine(DataDirectory, "gateauto.db");

    public static string SettingsFile => Path.Combine(DataDirectory, "settings.json");

    public static string LogDirectory => Path.Combine(DataDirectory, "logs");

    /// <summary>
    /// 优先使用 %LOCALAPPDATA%\GateAuto；该位置不可写时退回程序所在目录的 data 子目录，
    /// 避免在受限制的电脑上直接无法启动。
    /// </summary>
    private static string ResolveDataDirectory()
    {
        var preferred = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "GateAuto");

        try
        {
            Directory.CreateDirectory(preferred);

            // 有些受管控的电脑允许建立目录，却不允许写文件，这里实际写一个探针文件确认。
            var probe = Path.Combine(preferred, ".write-test");
            File.WriteAllText(probe, "ok");
            File.Delete(probe);
            return preferred;
        }
        catch (Exception ex) when (ex is UnauthorizedAccessException or IOException)
        {
            var fallback = Path.Combine(AppContext.BaseDirectory, "data");
            Directory.CreateDirectory(fallback);
            return fallback;
        }
    }
}

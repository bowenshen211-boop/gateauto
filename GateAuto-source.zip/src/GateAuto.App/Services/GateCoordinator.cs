using System.IO;
using GateAuto.Automation;
using Microsoft.Playwright;

namespace GateAuto.App.Services;

/// <summary>会话键：电子闸口一个，两个取单平台各一个，各自使用独立的浏览器资料目录。</summary>
public static class SessionKeys
{
    public const string Gate = "gate";

    public const string Customs = "customs";

    public const string YunFuTong = "yuntong";
}

/// <summary>
/// 浏览器会话管理。电子闸口与两个取单平台分别使用独立会话（独立资料目录），
/// 因此两边可以同时保持登入、同时作业；电子闸口写单使用共享锁（<see cref="GateLock"/>），
/// 平台登入与诊断则只在各自会话内互斥。
/// </summary>
public sealed class GateCoordinator : IAsyncDisposable
{
    private sealed class SessionEntry
    {
        public required GateBrowserSession Session { get; init; }

        public required string Fingerprint { get; init; }
    }

    private readonly AppLogger _logger;
    private readonly Dictionary<string, SessionEntry> _sessions = new(StringComparer.Ordinal);
    private readonly Dictionary<string, SemaphoreSlim> _platformLocks = new(StringComparer.Ordinal)
    {
        [SessionKeys.Customs] = new(1, 1),
        [SessionKeys.YunFuTong] = new(1, 1),
    };

    public GateCoordinator(AppLogger logger)
    {
        ArgumentNullException.ThrowIfNull(logger);
        _logger = logger;
    }

    /// <summary>
    /// 电子闸口一次只允许一个工作区操作，避免两个视窗同时写同一张表单。
    /// </summary>
    public SemaphoreSlim GateLock { get; } = new(1, 1);

    public bool IsRunning => _sessions.Count > 0;

    /// <summary>创建一个指向电子闸口页面、按设置绑定界面文字的 EGateService。</summary>
    public async Task<EGateService> GetServiceAsync(AppSettings settings, EGateSelectors selectors)
    {
        ArgumentNullException.ThrowIfNull(settings);
        ArgumentNullException.ThrowIfNull(selectors);

        var session = await EnsureSessionAsync(SessionKeys.Gate, settings, settings.UserDataDirectory);

        return new EGateService(
            session.Page,
            selectors,
            settings.GateUrl,
            string.IsNullOrWhiteSpace(settings.AddOrderUrl) ? null : settings.AddOrderUrl.Trim());
    }

    /// <summary>打开电子闸口页面，交给用户人工登录。</summary>
    public async Task OpenForLoginAsync(AppSettings settings)
    {
        await GateLock.WaitAsync();
        try
        {
            var session = await EnsureSessionAsync(SessionKeys.Gate, settings, settings.UserDataDirectory);
            await session.NavigateAsync(settings.GateUrl);
            _logger.Info("已開啟電子閘口，請在瀏覽器中完成登入；登入狀態會保存");
        }
        finally
        {
            GateLock.Release();
        }
    }

    /// <summary>
    /// 打开取单平台登入页；若已填写帐密，会尝试自动填入（不会自动提交），
    /// 之后由使用者自行点击登入。返回是否成功填入帐密。
    /// </summary>
    public async Task<bool> OpenPlatformAsync(
        string sessionKey,
        AppSettings settings,
        string url,
        string account,
        string password)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(url);

        var accessLock = SessionLockOf(sessionKey);
        await accessLock.WaitAsync();
        try
        {
            var session = await EnsureSessionAsync(sessionKey, settings, ProfileDirectoryOf(sessionKey));

            if (!string.IsNullOrWhiteSpace(account) && sessionKey != SessionKeys.Gate)
            {
                return await PlatformLoginFiller.OpenAndFillAsync(
                    session.Page,
                    url,
                    account,
                    password,
                    message => _logger.Info(message));
            }

            await session.NavigateAsync(url);
            _logger.Info($"已開啟平台 {url}，請手動登入（登入狀態會保存）");
            return false;
        }
        finally
        {
            accessLock.Release();
        }
    }

    /// <summary>读取现有页面诊断信息；不会创建浏览器、导航或修改页面。</summary>
    public async Task<PageDiagnosticResult> DiagnoseAsync(
        string sessionKey,
        string input,
        string diagnosticDirectory,
        IReadOnlyList<string>? sensitiveValues = null,
        CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(input);
        ArgumentException.ThrowIfNullOrWhiteSpace(diagnosticDirectory);

        var accessLock = SessionLockOf(sessionKey);
        if (!accessLock.Wait(0))
        {
            throw new InvalidOperationException("目標頁面正在登入或作業，請稍後再執行診斷。");
        }

        try
        {
            cancellationToken.ThrowIfCancellationRequested();

            if (!_sessions.TryGetValue(sessionKey, out var entry))
            {
                throw new InvalidOperationException("尚未開啟此平台，請先從原平台入口開啟並登入。");
            }

            var page = entry.Session.Context.Pages.LastOrDefault(candidate => !candidate.IsClosed);
            if (page is null && !entry.Session.Page.IsClosed)
            {
                page = entry.Session.Page;
            }

            if (page is null)
            {
                throw new InvalidOperationException("平台頁面已關閉，請先從原平台入口重新開啟。");
            }

            if (string.IsNullOrWhiteSpace(page.Url)
                || string.Equals(page.Url, "about:blank", StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidOperationException("平台尚未開啟有效頁面，請先開啟並登入後再診斷。");
            }

            return await PageDiagnostics.ExecuteAsync(
                page,
                input,
                diagnosticDirectory,
                sensitiveValues,
                cancellationToken,
                sessionKey);
        }
        catch (PlaywrightException ex)
        {
            throw new InvalidOperationException("頁面已關閉或正在跳轉，請稍後重試。", ex);
        }
        finally
        {
            accessLock.Release();
        }
    }

    /// <summary>设置变化后重启所有浏览器，让新的通道 / 无头 / 资料目录生效。</summary>
    public async Task ResetAsync()
    {
        foreach (var key in _sessions.Keys.ToList())
        {
            await DisposeSessionAsync(key);
        }
    }

    private SemaphoreSlim SessionLockOf(string sessionKey)
    {
        if (sessionKey == SessionKeys.Gate)
        {
            return GateLock;
        }

        if (_platformLocks.TryGetValue(sessionKey, out var accessLock))
        {
            return accessLock;
        }

        throw new ArgumentException($"未知瀏覽器工作階段：{sessionKey}", nameof(sessionKey));
    }

    private static string ProfileDirectoryOf(string sessionKey)
        => Path.Combine(AppPaths.DataDirectory, $"browser-profile-{sessionKey}");

    private async Task<GateBrowserSession> EnsureSessionAsync(string key, AppSettings settings, string userDataDirectory)
    {
        var directory = string.IsNullOrWhiteSpace(userDataDirectory)
            ? GateBrowserOptions.DefaultUserDataDirectory()
            : userDataDirectory;

        var fingerprint = $"{settings.BrowserChannel}|{settings.Headless}|{directory}";

        if (_sessions.TryGetValue(key, out var entry) && entry.Fingerprint == fingerprint)
        {
            return entry.Session;
        }

        await DisposeSessionAsync(key);

        _logger.Info($"啟動瀏覽器（{settings.BrowserChannel}，無頭：{settings.Headless}，資料夾：{Path.GetFileName(directory)}）");
        var session = await GateBrowserSession.StartAsync(new GateBrowserOptions
        {
            BrowserChannel = settings.BrowserChannel,
            Headless = settings.Headless,
            UserDataDirectory = directory,
            DefaultTimeoutMs = Math.Max(5, settings.TimeoutSeconds) * 1000f,
        });

        _sessions[key] = new SessionEntry { Session = session, Fingerprint = fingerprint };
        return session;
    }

    private async Task DisposeSessionAsync(string key)
    {
        if (!_sessions.Remove(key, out var entry))
        {
            return;
        }

        try
        {
            await entry.Session.DisposeAsync();
        }
        catch (Exception ex) when (ex is InvalidOperationException or Microsoft.Playwright.PlaywrightException)
        {
            _logger.Warn($"關閉瀏覽器時發生例外：{ex.Message}");
        }
    }

    public async ValueTask DisposeAsync()
    {
        foreach (var key in _sessions.Keys.ToList())
        {
            await DisposeSessionAsync(key);
        }

        GateLock.Dispose();
        foreach (var accessLock in _platformLocks.Values)
        {
            accessLock.Dispose();
        }
    }
}

using System.IO;
using System.Text.Json;

namespace GateAuto.App.Services;

/// <summary>简单日志：同时写入文件并通知界面。</summary>
public sealed class AppLogger
{
    private static readonly JsonSerializerOptions DiagnosticJsonOptions = new()
    {
        Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
    };

    private readonly object _lock = new();

    public AppLogger(string logDirectory)
    {
        DiagnosticDirectory = Path.Combine(logDirectory, "diagnostics");

        try
        {
            Directory.CreateDirectory(logDirectory);
            Directory.CreateDirectory(DiagnosticDirectory);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            // 目錄不可寫時仍保留介面日誌，只是不落檔。
        }

        LogFilePath = Path.Combine(logDirectory, $"gateauto-{DateTime.Now:yyyyMMdd}.log");
    }

    public event Action<string>? Written;

    public string LogFilePath { get; }

    public string DiagnosticDirectory { get; }

    public void Info(string message) => Write("INFO", message);

    public void Warn(string message) => Write("WARN", message);

    public void Error(string message) => Write("ERROR", message);

    /// <summary>写入一条独立的网页诊断 JSONL 日志；返回实际文件路径，写入失败时返回 null。</summary>
    public string? WriteDiagnostic(
        string target,
        string command,
        string? url,
        bool success,
        string? content,
        string? screenshotPath,
        string? error)
    {
        var filePath = Path.Combine(DiagnosticDirectory, $"diagnostics-{DateTime.Now:yyyyMMdd}.jsonl");
        var record = new
        {
            timestamp = DateTimeOffset.Now,
            target,
            command,
            url,
            success,
            content,
            screenshotPath,
            error,
        };

        lock (_lock)
        {
            try
            {
                Directory.CreateDirectory(DiagnosticDirectory);
                File.AppendAllText(
                    filePath,
                    JsonSerializer.Serialize(record, DiagnosticJsonOptions) + Environment.NewLine);
                return filePath;
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
            {
                return null;
            }
        }
    }

    private void Write(string level, string message)
    {
        var line = $"{DateTime.Now:HH:mm:ss} [{level}] {message}";

        lock (_lock)
        {
            try
            {
                File.AppendAllText(LogFilePath, line + Environment.NewLine);
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
            {
                // 日志写失败不应影响主流程。
            }
        }

        Written?.Invoke(line);
    }
}

using System.Globalization;
using System.IO;
using GateAuto.Core.Models;
using GateAuto.Core.Rules;

namespace GateAuto.App.Services;

/// <summary>CSV 导入结果：成功解析的行 + 逐行错误说明。</summary>
public sealed class CsvImportResult<T>
{
    public List<T> Rows { get; } = [];

    public List<string> Errors { get; } = [];

    public bool HasRows => Rows.Count > 0;
}

/// <summary>
/// 订单 CSV 导入。表头可用英文或中文，大小写不敏感；
/// 至少需要「申請編號 / ApplyNo」与「來源單號 / SourceNos」两列，
/// 可选「平台 / Platform」（關務物流 / 雲富通，未填时默认为關務物流）。
/// 每行订单属于单一平台且信息完整，导入时不会与另一平台的订单合并。
/// </summary>
public static class OrderCsvImporter
{
    private static readonly string[] PlatformKeys = ["platform", "平台", "來源平台", "来源平台"];
    private static readonly string[] ApplyNoKeys = ["applyno", "申請編號", "申请编号", "單號", "单号"];
    private static readonly string[] SourceNosKeys = ["sourcenos", "sourceno", "來源單號", "来源单号"];
    private static readonly string[] DeliveryKeys = ["deliveryaddress", "送貨地址", "送货地址"];
    private static readonly string[] UnloadKeys = ["unloadaddress", "落貨地址", "落货地址"];
    private static readonly string[] DestinationKeys = ["destination", "目的地"];
    private static readonly string[] PackageKeys = ["packagecount", "件數", "件数"];
    private static readonly string[] GrossKeys = ["grossweightkg", "grossweight", "毛重", "毛重(kg)"];
    private static readonly string[] NetKeys = ["netweightkg", "netweight", "淨重", "净重"];
    private static readonly string[] PackingKeys = ["packingmethod", "包裝方式", "包装方式"];
    private static readonly string[] VendorKeys = ["vendorcode", "廠商代碼", "厂商代码"];
    private static readonly string[] LoadingAddressKeys = ["loadingaddress", "裝貨地址", "装货地址"];
    private static readonly string[] ConsigneeKeys = ["consignee", "收貨方", "收货方"];

    /// <summary>读取订单 CSV。<paramref name="fixedPlatform"/> 有值时，所有行都归入该平台（平台工作区使用）。</summary>
    public static CsvImportResult<OrderInfo> Load(string filePath, OrderPlatform? fixedPlatform = null)
    {
        var result = new CsvImportResult<OrderInfo>();
        var lines = Csv.ParseFile(filePath);
        if (lines.Count < 2)
        {
            result.Errors.Add("CSV 沒有資料列（第一列必須是表頭）");
            return result;
        }

        var header = lines[0]
            .Select(h => Normalize(h))
            .ToList();

        var applyIndex = IndexOf(header, ApplyNoKeys);
        var sourceIndex = IndexOf(header, SourceNosKeys);

        if (applyIndex < 0)
        {
            result.Errors.Add("找不到「申請編號 / ApplyNo」欄位");
        }

        if (sourceIndex < 0)
        {
            result.Errors.Add("找不到「來源單號 / SourceNos」欄位");
        }

        if (result.Errors.Count > 0)
        {
            return result;
        }

        var platformIndex = IndexOf(header, PlatformKeys);
        var deliveryIndex = IndexOf(header, DeliveryKeys);
        var unloadIndex = IndexOf(header, UnloadKeys);
        var destinationIndex = IndexOf(header, DestinationKeys);
        var packageIndex = IndexOf(header, PackageKeys);
        var grossIndex = IndexOf(header, GrossKeys);
        var netIndex = IndexOf(header, NetKeys);
        var packingIndex = IndexOf(header, PackingKeys);
        var vendorIndex = IndexOf(header, VendorKeys);
        var loadingAddressIndex = IndexOf(header, LoadingAddressKeys);
        var consigneeIndex = IndexOf(header, ConsigneeKeys);

        for (var i = 1; i < lines.Count; i++)
        {
            var cells = lines[i];
            if (cells.All(string.IsNullOrWhiteSpace))
            {
                continue;
            }

            var applyNo = Cell(cells, applyIndex);
            if (string.IsNullOrWhiteSpace(applyNo))
            {
                result.Errors.Add($"第 {i + 1} 列：申請編號為空，已略過");
                continue;
            }

            var platformText = Cell(cells, platformIndex);
            var platform = fixedPlatform ?? OrderPlatforms.Parse(platformText);

            if (fixedPlatform is { } fixedValue)
            {
                if (platformText.Length > 0
                    && OrderPlatforms.IsKnown(platformText)
                    && OrderPlatforms.Parse(platformText) != fixedValue)
                {
                    result.Errors.Add(
                        $"第 {i + 1} 列：CSV 平台「{platformText}」與本工作區不同，已按 {fixedValue.ToDisplay()} 匯入");
                }
            }
            else if (!OrderPlatforms.IsKnown(platformText))
            {
                result.Errors.Add($"第 {i + 1} 列：無法識別平台「{platformText}」，已按關務物流處理");
            }

            result.Rows.Add(new OrderInfo
            {
                Platform = platform,
                ApplyNo = applyNo,
                SourceNos = SourceNoParser.Parse(Cell(cells, sourceIndex)),
                DeliveryAddress = Cell(cells, deliveryIndex),
                UnloadAddress = Cell(cells, unloadIndex),
                Destination = Cell(cells, destinationIndex),
                PackageCount = ParseInt(Cell(cells, packageIndex)),
                GrossWeightKg = ParseDecimal(Cell(cells, grossIndex)),
                NetWeightKg = ParseDecimal(Cell(cells, netIndex)),
                PackingMethod = Cell(cells, packingIndex),
                VendorCode = Cell(cells, vendorIndex),
                LoadingAddress = Cell(cells, loadingAddressIndex),
                Consignee = Cell(cells, consigneeIndex),
            });
        }

        return result;
    }

    private static string Cell(IReadOnlyList<string> cells, int index)
        => index >= 0 && index < cells.Count ? cells[index].Trim() : string.Empty;

    private static int ParseInt(string text)
        => int.TryParse(text, NumberStyles.Integer, CultureInfo.InvariantCulture, out var value) ? value : 0;

    private static decimal ParseDecimal(string text)
        => decimal.TryParse(text, NumberStyles.Number, CultureInfo.InvariantCulture, out var value) ? value : 0m;

    private static int IndexOf(IReadOnlyList<string> header, IReadOnlyList<string> keys)
    {
        for (var i = 0; i < header.Count; i++)
        {
            if (keys.Contains(header[i], StringComparer.OrdinalIgnoreCase))
            {
                return i;
            }
        }

        return -1;
    }

    internal static string Normalize(string text)
        => text.Trim().Trim('\uFEFF').Replace(" ", string.Empty).Replace("（", "(").Replace("）", ")").ToLowerInvariant();
}

/// <summary>车牌 CSV 导入：放行单号 + 车牌。车牌先存在界面清单，电子闸口更新成功后才写库。</summary>
public static class PlateCsvImporter
{
    private static readonly string[] LqeKeys = ["lqeno", "lqe", "放行單號", "放行单号"];
    private static readonly string[] PlateKeys = ["plateno", "plate", "車牌", "车牌", "車牌號", "车牌号"];

    public sealed record Row(string LqeNo, string PlateNo);

    public static CsvImportResult<Row> Load(string filePath)
    {
        var result = new CsvImportResult<Row>();
        var lines = Csv.ParseFile(filePath);
        if (lines.Count < 2)
        {
            result.Errors.Add("CSV 沒有資料列（第一列必須是表頭）");
            return result;
        }

        var header = lines[0].Select(OrderCsvImporter.Normalize).ToList();
        var lqeIndex = Find(header, LqeKeys);
        var plateIndex = Find(header, PlateKeys);

        if (lqeIndex < 0 || plateIndex < 0)
        {
            result.Errors.Add("CSV 需包含「放行單號 / LqeNo」與「車牌 / PlateNo」兩欄");
            return result;
        }

        for (var i = 1; i < lines.Count; i++)
        {
            var cells = lines[i];
            if (cells.All(string.IsNullOrWhiteSpace))
            {
                continue;
            }

            var lqe = Cell(cells, lqeIndex);
            var plate = Cell(cells, plateIndex);

            if (string.IsNullOrWhiteSpace(lqe) || string.IsNullOrWhiteSpace(plate))
            {
                result.Errors.Add($"第 {i + 1} 列：放行單號或車牌為空，已略過");
                continue;
            }

            result.Rows.Add(new Row(lqe, plate));
        }

        return result;
    }

    private static string Cell(IReadOnlyList<string> cells, int index)
        => index >= 0 && index < cells.Count ? cells[index].Trim() : string.Empty;

    private static int Find(IReadOnlyList<string> header, IReadOnlyList<string> keys)
    {
        for (var i = 0; i < header.Count; i++)
        {
            if (keys.Contains(header[i], StringComparer.OrdinalIgnoreCase))
            {
                return i;
            }
        }

        return -1;
    }
}

/// <summary>极简 CSV 解析：支持双引号包裹、引号转义与逗号/分号分隔。</summary>
internal static class Csv
{
    public static List<List<string>> ParseFile(string filePath)
    {
        var text = File.ReadAllText(filePath);
        return Parse(text);
    }

    public static List<List<string>> Parse(string text)
    {
        var rows = new List<List<string>>();
        var row = new List<string>();
        var field = new System.Text.StringBuilder();
        var inQuotes = false;

        for (var i = 0; i < text.Length; i++)
        {
            var ch = text[i];

            if (inQuotes)
            {
                if (ch == '"')
                {
                    if (i + 1 < text.Length && text[i + 1] == '"')
                    {
                        field.Append('"');
                        i++;
                    }
                    else
                    {
                        inQuotes = false;
                    }
                }
                else
                {
                    field.Append(ch);
                }

                continue;
            }

            switch (ch)
            {
                case '"':
                    inQuotes = true;
                    break;

                case ',':
                case ';':
                case '\t':
                    row.Add(field.ToString());
                    field.Clear();
                    break;

                case '\r':
                    break;

                case '\n':
                    row.Add(field.ToString());
                    field.Clear();
                    rows.Add(row);
                    row = [];
                    break;

                default:
                    field.Append(ch);
                    break;
            }
        }

        if (field.Length > 0 || row.Count > 0)
        {
            row.Add(field.ToString());
            rows.Add(row);
        }

        return rows;
    }
}

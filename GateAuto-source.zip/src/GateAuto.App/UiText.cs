using System.Globalization;
using System.Text;
using GateAuto.Core.Models;
using GateAuto.Core.Rules;

namespace GateAuto.App;

/// <summary>界面共用的文字格式化与数值解析。</summary>
internal static class UiText
{
    public static string FormatEvaluation(RuleEvaluation evaluation)
    {
        var builder = new StringBuilder();
        builder.AppendLine($"來源平台：{evaluation.Order.Platform.ToDisplay()}");
        builder.AppendLine($"申請編號：{evaluation.Order.ApplyNo}");
        builder.AppendLine($"出閘類別：{evaluation.ExitTypeDisplay ?? "（無法判定）"}");
        builder.AppendLine($"貨物性質：{evaluation.CargoType ?? "-"}");
        builder.AppendLine($"廠商代碼：{evaluation.VendorCode ?? "-"}");
        builder.AppendLine($"廠商類型：{evaluation.VendorType ?? "-"}");
        builder.AppendLine($"落貨園區：{evaluation.UnloadingPark ?? "（非集團國內，不填）"}");
        builder.AppendLine($"裝貨地址：{evaluation.LoadingAddress}");
        builder.AppendLine($"落貨地址：{evaluation.UnloadingAddress ?? "-"}");
        builder.AppendLine($"包裝方式：{evaluation.PackingMethod}");
        builder.AppendLine($"來源單號：{evaluation.SourceNosText}");
        builder.AppendLine($"判定前綴：{evaluation.MatchedPrefix ?? "-"}");

        builder.AppendLine();
        builder.AppendLine($"固定欄位：申報類型 {evaluation.FixedFields.DeclarationType}｜" +
                           $"申請法人 {evaluation.FixedFields.LegalEntity}｜" +
                           $"申請部門 {evaluation.FixedFields.ApplyDepartment}");
        builder.AppendLine($"　　　　　運輸方式 {evaluation.FixedFields.TransportMode}｜" +
                           $"裝貨園區 {evaluation.FixedFields.LoadingPark}");

        if (evaluation.Errors.Count > 0)
        {
            builder.AppendLine();
            builder.AppendLine("錯誤：");
            foreach (var error in evaluation.Errors)
            {
                builder.AppendLine($"  · {error}");
            }
        }

        if (evaluation.Warnings.Count > 0)
        {
            builder.AppendLine();
            builder.AppendLine("提醒：");
            foreach (var warning in evaluation.Warnings)
            {
                builder.AppendLine($"  · {warning}");
            }
        }

        return builder.ToString();
    }

    public static int ParseInt(string text, int fallback)
        => int.TryParse(text, NumberStyles.Integer, CultureInfo.InvariantCulture, out var value) ? value : fallback;

    public static decimal ParseDecimal(string text)
    {
        if (decimal.TryParse(text, NumberStyles.Number, CultureInfo.InvariantCulture, out var value))
        {
            return value;
        }

        return decimal.TryParse(text, NumberStyles.Number, CultureInfo.CurrentCulture, out value) ? value : 0m;
    }
}

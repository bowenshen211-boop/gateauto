using System.Collections.ObjectModel;
using System.Globalization;
using System.IO;
using System.Text;
using System.Windows;
using GateAuto.App.Services;
using GateAuto.Automation;
using GateAuto.Automation.Workflows;
using GateAuto.Core.Models;
using GateAuto.Core.Rules;
using GateAuto.Data;
using Microsoft.Win32;

namespace GateAuto.App;

/// <summary>
/// 单个平台的建单工作区。两个平台各开一个窗口，使用独立的浏览器会话与登录状态，
/// 因此可以同时登入、同时作业；只有电子闸口写单会通过 <see cref="GateCoordinator.GateLock"/> 排队。
/// </summary>
public partial class PlatformWorkWindow : Window
{
    private readonly OrderPlatform _platform;
    private readonly string _sessionKey;
    private readonly AppSettingsStore _settingsStore;
    private readonly AppSettings _settings;
    private readonly AppLogger _logger;
    private readonly OrderRepository _orders;
    private readonly PlateTaskRepository _plateTasks;
    private readonly RuleEngine _engine;
    private readonly GateCoordinator _gate;

    private readonly ObservableCollection<PendingOrderRow> _orderRows = [];
    private bool _busy;

    /// <summary>建单成功后触发，让主窗口刷新待派车清单。</summary>
    public event EventHandler? PlateTasksChanged;

    public PlatformWorkWindow(
        OrderPlatform platform,
        AppSettingsStore settingsStore,
        AppSettings settings,
        AppLogger logger,
        OrderRepository orders,
        PlateTaskRepository plateTasks,
        RuleEngine engine,
        GateCoordinator gate)
    {
        InitializeComponent();
        ClampToScreen();

        _platform = platform;
        _sessionKey = platform == OrderPlatform.YunFuTong ? SessionKeys.YunFuTong : SessionKeys.Customs;
        _settingsStore = settingsStore;
        _settings = settings;
        _logger = logger;
        _orders = orders;
        _plateTasks = plateTasks;
        _engine = engine;
        _gate = gate;

        var name = platform.ToDisplay();
        Title = $"{name} · 建單工作區";
        lblTitle.Text = $"{name} · 建單工作區";
        lblBadge.Text = platform == OrderPlatform.YunFuTong ? "雲" : "關";
        lblSubtitle.Text = $"{_settings.UrlOf(platform)}　·　獨立瀏覽器與登入狀態，可與另一平台同時作業";

        var login = _settings.LoginOf(platform);
        txtAccount.Text = login.Account;
        pwdPassword.Password = login.Password;

        gridOrders.ItemsSource = _orderRows;

        AppendLog($"工作區已就緒：{name}");
    }

    // ==================== 登入 ====================

    private void SaveLogin_Click(object sender, RoutedEventArgs e) => SaveLogin();

    private async void OpenPlatform_Click(object sender, RoutedEventArgs e)
    {
        SaveLogin();

        await RunAsync("開啟平台", async () =>
        {
            await _gate.OpenPlatformAsync(_sessionKey, _settings, _settings.UrlOf(_platform), txtAccount.Text.Trim(), pwdPassword.Password);
            AppendLog("已開啟平台，請在瀏覽器中確認登入狀態");
        });
    }

    private void SaveLogin()
    {
        var login = _settings.LoginOf(_platform);
        login.Account = txtAccount.Text.Trim();
        login.Password = pwdPassword.Password;
        _settingsStore.Save(_settings);
        _logger.Info($"{_platform.ToDisplay()} 帳密已保存");
        AppendLog("帳密已保存（密碼以本機 Windows 帳號加密）");
    }

    // ==================== 建單清單 ====================

    private void Preview_Click(object sender, RoutedEventArgs e)
    {
        var order = BuildOrderFromUi();
        txtLog.Text = UiText.FormatEvaluation(_engine.Evaluate(order));
    }

    private void AddToList_Click(object sender, RoutedEventArgs e)
    {
        var order = BuildOrderFromUi();

        if (string.IsNullOrWhiteSpace(order.ApplyNo))
        {
            MessageBox.Show("請填寫申請編號。", "缺少資料", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        if (order.SourceNos.Count == 0)
        {
            MessageBox.Show("請填寫來源單號。", "缺少資料", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        if (_orderRows.Any(r => string.Equals(r.ApplyNo, order.ApplyNo, StringComparison.OrdinalIgnoreCase)))
        {
            MessageBox.Show($"申請編號 {order.ApplyNo} 已在清單中。", "重複資料", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        _orderRows.Add(new PendingOrderRow { Order = order });
        AppendLog($"已加入 {order.ApplyNo}");
        ClearForm();
    }

    private void ImportOrders_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog
        {
            Title = "選擇訂單 CSV",
            Filter = "CSV 檔案 (*.csv)|*.csv|所有檔案 (*.*)|*.*",
        };

        if (dialog.ShowDialog(this) != true)
        {
            return;
        }

        var imported = OrderCsvImporter.Load(dialog.FileName, _platform);

        foreach (var error in imported.Errors)
        {
            _logger.Warn(error);
        }

        var added = 0;
        foreach (var order in imported.Rows)
        {
            if (_orderRows.Any(r => string.Equals(r.ApplyNo, order.ApplyNo, StringComparison.OrdinalIgnoreCase)))
            {
                continue;
            }

            _orderRows.Add(new PendingOrderRow { Order = order });
            added++;
        }

        AppendLog($"匯入 {added} 筆（{Path.GetFileName(dialog.FileName)}）");

        if (imported.Errors.Count > 0)
        {
            MessageBox.Show(
                string.Join(Environment.NewLine, imported.Errors.Take(10)),
                "匯入完成，但有部分資料被略過",
                MessageBoxButton.OK,
                MessageBoxImage.Warning);
        }
    }

    private void RemoveOrder_Click(object sender, RoutedEventArgs e)
    {
        foreach (var row in gridOrders.SelectedItems.Cast<PendingOrderRow>().ToList())
        {
            _orderRows.Remove(row);
        }
    }

    private void ClearOrders_Click(object sender, RoutedEventArgs e) => _orderRows.Clear();

    private async void CreateSelected_Click(object sender, RoutedEventArgs e)
    {
        var selected = gridOrders.SelectedItems.Cast<PendingOrderRow>().ToList();
        if (selected.Count == 0)
        {
            MessageBox.Show("請先在清單中選取要建單的資料。", "建單", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        await CreateRowsAsync(selected);
    }

    private async void CreateAll_Click(object sender, RoutedEventArgs e)
    {
        var pending = _orderRows.Where(r => r.Status.StartsWith("待建單", StringComparison.Ordinal)).ToList();
        if (pending.Count == 0)
        {
            MessageBox.Show("清單中沒有待建單的資料。", "建單", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        await CreateRowsAsync(pending);
    }

    private async Task CreateRowsAsync(IReadOnlyList<PendingOrderRow> rows)
    {
        var success = 0;
        var failed = 0;
        var waiting = false;

        await RunAsync("建單", async () =>
        {
            // 兩個工作區可能同時按下建單：閘口一次只允許一個操作，另一個排隊等待。
            if (!_gate.GateLock.Wait(0))
            {
                waiting = true;
                lblState.Text = "等待另一工作區完成閘口作業…";
                await _gate.GateLock.WaitAsync();
            }

            try
            {
                var service = await _gate.GetServiceAsync(_settings, BuildSelectors());
                var workflow = new OrderCreationWorkflow(_engine, _orders, _plateTasks, service);

                foreach (var row in rows)
                {
                    row.Status = "建單中…";
                    AppendLog($"開始建單 {row.ApplyNo}");
                    _logger.Info($"[{_platform.ToDisplay()}] 開始建單：{row.ApplyNo}");

                    var outcome = await workflow.CreateAsync(row.Order);

                    if (outcome.Success)
                    {
                        success++;
                        row.Status = $"已建單 {outcome.LqeNo}";
                        AppendLog($"建單成功 {row.ApplyNo} → {outcome.LqeNo}");
                        _logger.Info($"[{_platform.ToDisplay()}] 建單成功：{row.ApplyNo} → {outcome.LqeNo}");
                    }
                    else
                    {
                        failed++;
                        row.Status = "失敗";
                        AppendLog($"建單失敗 {row.ApplyNo}：{outcome.Error}");
                        _logger.Error($"[{_platform.ToDisplay()}] 建單失敗：{row.ApplyNo} → {outcome.Error}");
                    }

                    foreach (var warning in outcome.Warnings)
                    {
                        AppendLog($"  · {warning}");
                        _logger.Warn($"  {warning}");
                    }
                }
            }
            finally
            {
                _gate.GateLock.Release();
            }

            PlateTasksChanged?.Invoke(this, EventArgs.Empty);
        });

        if (waiting)
        {
            AppendLog("已取得閘口操作權，完成本批建單");
        }

        MessageBox.Show(
            $"建單完成：成功 {success} 筆，失敗 {failed} 筆。詳情請看主視窗「日誌」。",
            "建單結果",
            MessageBoxButton.OK,
            failed > 0 ? MessageBoxImage.Warning : MessageBoxImage.Information);
    }

    // ==================== 公共 ====================

    private EGateSelectors BuildSelectors() => new()
    {
        TextVariant = _settings.UseSimplifiedChinese ? EGateTextVariant.Simplified : EGateTextVariant.Traditional,
        Timeout = TimeSpan.FromSeconds(Math.Max(5, _settings.TimeoutSeconds)),
        QueryTimeout = TimeSpan.FromSeconds(Math.Max(5, _settings.QueryTimeoutSeconds)),
        LqeTimeout = TimeSpan.FromSeconds(Math.Max(5, _settings.LqeTimeoutSeconds)),
    };

    private OrderInfo BuildOrderFromUi() => new()
    {
        Platform = _platform,
        ApplyNo = txtApplyNo.Text.Trim(),
        SourceNos = SourceNoParser.Parse(txtSourceNos.Text),
        DeliveryAddress = txtDeliveryAddress.Text.Trim(),
        UnloadAddress = txtUnloadAddress.Text.Trim(),
        Destination = txtDestination.Text.Trim(),
        PackageCount = UiText.ParseInt(txtPackageCount.Text, 0),
        GrossWeightKg = UiText.ParseDecimal(txtGrossWeight.Text),
        NetWeightKg = UiText.ParseDecimal(txtNetWeight.Text),
        PackingMethod = txtPackingMethod.Text.Trim(),
        VendorCode = txtVendorCode.Text.Trim(),
        LoadingAddress = txtLoadingAddress.Text.Trim(),
        Consignee = txtConsignee.Text.Trim(),
    };

    private void ClearForm()
    {
        txtApplyNo.Clear();
        txtSourceNos.Clear();
        txtDeliveryAddress.Clear();
        txtUnloadAddress.Clear();
        txtDestination.Clear();
        txtPackageCount.Clear();
        txtGrossWeight.Clear();
        txtNetWeight.Clear();
        txtPackingMethod.Clear();
        txtVendorCode.Clear();
        txtLoadingAddress.Clear();
        txtConsignee.Clear();
        txtApplyNo.Focus();
    }

    private async Task RunAsync(string operation, Func<Task> action)
    {
        if (_busy)
        {
            MessageBox.Show("目前有作業正在執行，請稍候。", operation, MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        _busy = true;
        lblState.Text = $"{operation} 執行中…";

        try
        {
            await action();
        }
        catch (Exception ex)
        {
            _logger.Error($"{_platform.ToDisplay()} {operation} 失敗：{ex.Message}");
            AppendLog($"{operation} 失敗：{ex.Message}");
            MessageBox.Show(ex.Message, operation, MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            _busy = false;
            lblState.Text = "就緒";
        }
    }

    private void AppendLog(string line)
    {
        txtLog.AppendText($"[{DateTime.Now:HH:mm:ss}] {line}{Environment.NewLine}");
        txtLog.ScrollToEnd();
    }

    private void Close_Click(object sender, RoutedEventArgs e) => Close();

    /// <summary>小螢幕上自動縮到可用工作區，避免視窗超出畫面。</summary>
    private void ClampToScreen()
    {
        var area = SystemParameters.WorkArea;
        if (Width > area.Width)
        {
            Width = Math.Max(MinWidth, area.Width - 24);
        }

        if (Height > area.Height)
        {
            Height = Math.Max(MinHeight, area.Height - 24);
        }
    }
}

using System.IO;
using System.Windows;
using System.Windows.Threading;

namespace GateAuto.App;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        DispatcherUnhandledException += OnDispatcherUnhandledException;

        try
        {
            var window = new MainWindow();
            MainWindow = window;
            window.Show();

            // 可選：--open=關務物流 / --open=雲富通，啟動後直接打開該平台工作區。
            var open = e.Args.FirstOrDefault(arg => arg.StartsWith("--open=", StringComparison.OrdinalIgnoreCase));
            if (open is not null)
            {
                window.OpenWorkspace(GateAuto.Core.Models.OrderPlatforms.Parse(open["--open=".Length..]));
            }
        }
        catch (Exception ex)
        {
            ReportStartupFailure(ex);
            Shutdown(1);
        }
    }

    private void OnDispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        MessageBox.Show(
            $"發生未預期的錯誤：{e.Exception.Message}",
            "錯誤",
            MessageBoxButton.OK,
            MessageBoxImage.Error);

        e.Handled = true;
    }

    private static void ReportStartupFailure(Exception exception)
    {
        var detail = exception.ToString();

        foreach (var directory in new[]
                 {
                     Path.Combine(
                         Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                         "GateAuto"),
                     AppContext.BaseDirectory,
                 })
        {
            try
            {
                Directory.CreateDirectory(directory);
                File.WriteAllText(Path.Combine(directory, "startup-error.log"), detail);
                break;
            }
            catch (Exception)
            {
                // 換下一個可寫入的位置。
            }
        }

        MessageBox.Show(
            $"應用啟動失敗：{exception.Message}{Environment.NewLine}{Environment.NewLine}{detail}",
            "啟動失敗",
            MessageBoxButton.OK,
            MessageBoxImage.Error);
    }
}

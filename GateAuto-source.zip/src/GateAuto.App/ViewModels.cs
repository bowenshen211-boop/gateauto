using System.ComponentModel;
using System.Runtime.CompilerServices;
using GateAuto.Core.Models;
using GateAuto.Core.Rules;

namespace GateAuto.App;

/// <summary>建单清单中的一行。状态用于显示建单进度。</summary>
public sealed class PendingOrderRow : INotifyPropertyChanged
{
    private string _status = "待建單";

    public required OrderInfo Order { get; init; }

    public string PlatformText => Order.Platform.ToDisplay();

    public string ApplyNo => Order.ApplyNo;

    public string SourceNosText => SourceNoParser.Join(Order.SourceNos);

    public string DeliveryAddress => Order.DeliveryAddress;

    public string Destination => Order.Destination;

    public int PackageCount => Order.PackageCount;

    public string GrossWeightText => $"{Order.GrossWeightKg:0.##}KG";

    public string Status
    {
        get => _status;
        set
        {
            if (_status == value)
            {
                return;
            }

            _status = value;
            OnPropertyChanged();
        }
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    private void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
}

/// <summary>待派车清单中的一行；车牌可直接在表格里修改后再执行。</summary>
public sealed class PlateTaskRow : INotifyPropertyChanged
{
    private string _plateNo = string.Empty;
    private string _status = PlateTaskStatus.Pending;

    public required string LqeNo { get; init; }

    public required string Destination { get; init; }

    public required int PackageCount { get; init; }

    public required string WeightText { get; init; }

    public string PlateNo
    {
        get => _plateNo;
        set
        {
            if (_plateNo == value)
            {
                return;
            }

            _plateNo = value;
            OnPropertyChanged();
        }
    }

    public string Status
    {
        get => _status;
        set
        {
            if (_status == value)
            {
                return;
            }

            _status = value;
            OnPropertyChanged();
        }
    }

    public static PlateTaskRow From(PlateTask task) => new()
    {
        LqeNo = task.LqeNo,
        Destination = task.Destination,
        PackageCount = task.PackageCount,
        WeightText = task.WeightText,
        PlateNo = task.PlateNo ?? string.Empty,
        Status = task.Status,
    };

    public event PropertyChangedEventHandler? PropertyChanged;

    private void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
}

using System.Globalization;
using GateAuto.Core.Models;
using Microsoft.Data.Sqlite;

namespace GateAuto.Data;

/// <summary>Orders 表的一行。</summary>
public sealed class OrderRecord
{
    public long Id { get; init; }

    public OrderPlatform Platform { get; init; } = OrderPlatform.CustomsLogistics;

    public required string ApplyNo { get; init; }

    public required string SourceNo { get; init; }

    public string ExitType { get; init; } = string.Empty;

    public string CargoType { get; init; } = string.Empty;

    public string VendorCode { get; init; } = string.Empty;

    public string? LqeNo { get; init; }

    public string? PlateNo { get; init; }

    public string Status { get; init; } = OrderStatus.Pending;

    public DateTimeOffset CreatedAt { get; init; }
}

/// <summary>
/// Orders 表读写。以「平台 + 申请编号」为唯一键：两个平台各自独立取单，
/// 编号相同也不会互相覆盖；重复抓取同一申请同样不会产生重复记录。
/// </summary>
public sealed class OrderRepository
{
    private readonly GateAutoDatabase _database;

    public OrderRepository(GateAutoDatabase database)
    {
        ArgumentNullException.ThrowIfNull(database);
        _database = database;
    }

    /// <summary>插入或更新一笔订单，返回记录 Id。</summary>
    public long Save(OrderRecord record)
    {
        ArgumentNullException.ThrowIfNull(record);

        using var connection = _database.OpenConnection();
        using var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO Orders (Platform, ApplyNo, SourceNo, ExitType, CargoType, VendorCode, LqeNo, PlateNo, Status, CreatedAt)
            VALUES ($platform, $applyNo, $sourceNo, $exitType, $cargoType, $vendorCode, $lqeNo, $plateNo, $status, $createdAt)
            ON CONFLICT (Platform, ApplyNo) DO UPDATE SET
                SourceNo   = excluded.SourceNo,
                ExitType   = excluded.ExitType,
                CargoType  = excluded.CargoType,
                VendorCode = excluded.VendorCode,
                Status     = excluded.Status
            RETURNING Id;
            """;

        command.Parameters.AddWithValue("$platform", record.Platform.ToDisplay());
        command.Parameters.AddWithValue("$applyNo", record.ApplyNo);
        command.Parameters.AddWithValue("$sourceNo", record.SourceNo);
        command.Parameters.AddWithValue("$exitType", record.ExitType);
        command.Parameters.AddWithValue("$cargoType", record.CargoType);
        command.Parameters.AddWithValue("$vendorCode", record.VendorCode);
        command.Parameters.AddWithValue("$lqeNo", (object?)record.LqeNo ?? DBNull.Value);
        command.Parameters.AddWithValue("$plateNo", (object?)record.PlateNo ?? DBNull.Value);
        command.Parameters.AddWithValue("$status", record.Status);
        command.Parameters.AddWithValue("$createdAt", ToStorage(record.CreatedAt == default ? DateTimeOffset.Now : record.CreatedAt));

        return Convert.ToInt64(command.ExecuteScalar(), CultureInfo.InvariantCulture);
    }

    public OrderRecord? GetByApplyNo(OrderPlatform platform, string applyNo)
    {
        using var connection = _database.OpenConnection();
        using var command = connection.CreateCommand();
        command.CommandText = "SELECT * FROM Orders WHERE Platform = $platform AND ApplyNo = $applyNo LIMIT 1;";
        command.Parameters.AddWithValue("$platform", platform.ToDisplay());
        command.Parameters.AddWithValue("$applyNo", applyNo);

        using var reader = command.ExecuteReader();
        return reader.Read() ? Map(reader) : null;
    }

    public bool Exists(OrderPlatform platform, string applyNo)
    {
        using var connection = _database.OpenConnection();
        using var command = connection.CreateCommand();
        command.CommandText = "SELECT 1 FROM Orders WHERE Platform = $platform AND ApplyNo = $applyNo LIMIT 1;";
        command.Parameters.AddWithValue("$platform", platform.ToDisplay());
        command.Parameters.AddWithValue("$applyNo", applyNo);

        return command.ExecuteScalar() is not null;
    }

    /// <summary>建单成功后回写 LQE 放行单号与状态。</summary>
    public bool MarkCreated(OrderPlatform platform, string applyNo, string lqeNo)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(lqeNo);

        using var connection = _database.OpenConnection();
        using var command = connection.CreateCommand();
        command.CommandText = """
            UPDATE Orders
            SET LqeNo = $lqeNo, Status = $status
            WHERE Platform = $platform AND ApplyNo = $applyNo;
            """;
        command.Parameters.AddWithValue("$lqeNo", lqeNo);
        command.Parameters.AddWithValue("$status", OrderStatus.Created);
        command.Parameters.AddWithValue("$platform", platform.ToDisplay());
        command.Parameters.AddWithValue("$applyNo", applyNo);

        return command.ExecuteNonQuery() > 0;
    }

    public bool MarkFailed(OrderPlatform platform, string applyNo)
    {
        using var connection = _database.OpenConnection();
        using var command = connection.CreateCommand();
        command.CommandText = "UPDATE Orders SET Status = $status WHERE Platform = $platform AND ApplyNo = $applyNo;";
        command.Parameters.AddWithValue("$status", OrderStatus.Failed);
        command.Parameters.AddWithValue("$platform", platform.ToDisplay());
        command.Parameters.AddWithValue("$applyNo", applyNo);

        return command.ExecuteNonQuery() > 0;
    }

    private static OrderRecord Map(SqliteDataReader reader)
    {
        var platformText = reader.IsDBNull(reader.GetOrdinal("Platform"))
            ? null
            : reader.GetString(reader.GetOrdinal("Platform"));

        return new OrderRecord
        {
            Id = reader.GetInt64(reader.GetOrdinal("Id")),
            Platform = OrderPlatforms.Parse(platformText),
            ApplyNo = reader.GetString(reader.GetOrdinal("ApplyNo")),
            SourceNo = reader.GetString(reader.GetOrdinal("SourceNo")),
            ExitType = reader.GetString(reader.GetOrdinal("ExitType")),
            CargoType = reader.GetString(reader.GetOrdinal("CargoType")),
            VendorCode = reader.GetString(reader.GetOrdinal("VendorCode")),
            LqeNo = reader.IsDBNull(reader.GetOrdinal("LqeNo")) ? null : reader.GetString(reader.GetOrdinal("LqeNo")),
            PlateNo = reader.IsDBNull(reader.GetOrdinal("PlateNo")) ? null : reader.GetString(reader.GetOrdinal("PlateNo")),
            Status = reader.GetString(reader.GetOrdinal("Status")),
            CreatedAt = DateTimeOffset.Parse(reader.GetString(reader.GetOrdinal("CreatedAt")), CultureInfo.InvariantCulture),
        };
    }

    internal static string ToStorage(DateTimeOffset value) => value.ToString("O", CultureInfo.InvariantCulture);
}

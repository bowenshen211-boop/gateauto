using System.Globalization;
using GateAuto.Core.Models;
using Microsoft.Data.Sqlite;

namespace GateAuto.Data;

/// <summary>待派车清单读写。车牌与建单解耦：建单只写入待派车记录，车牌由独立流程回写。</summary>
public sealed class PlateTaskRepository
{
    private readonly GateAutoDatabase _database;

    public PlateTaskRepository(GateAutoDatabase database)
    {
        ArgumentNullException.ThrowIfNull(database);
        _database = database;
    }

    public long Add(PlateTask task)
    {
        ArgumentNullException.ThrowIfNull(task);
        ArgumentException.ThrowIfNullOrWhiteSpace(task.LqeNo);

        using var connection = _database.OpenConnection();
        using var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO PlateTasks (LqeNo, Destination, PackageCount, WeightKg, PlateNo, Status, CreatedAt, UpdatedAt)
            VALUES ($lqeNo, $destination, $packageCount, $weightKg, $plateNo, $status, $createdAt, $updatedAt)
            ON CONFLICT (LqeNo) DO UPDATE SET
                Destination  = excluded.Destination,
                PackageCount = excluded.PackageCount,
                WeightKg     = excluded.WeightKg
            RETURNING Id;
            """;

        command.Parameters.AddWithValue("$lqeNo", task.LqeNo);
        command.Parameters.AddWithValue("$destination", task.Destination);
        command.Parameters.AddWithValue("$packageCount", task.PackageCount);
        command.Parameters.AddWithValue("$weightKg", (double)task.WeightKg);
        command.Parameters.AddWithValue("$plateNo", (object?)task.PlateNo ?? DBNull.Value);
        command.Parameters.AddWithValue("$status", task.Status);
        command.Parameters.AddWithValue("$createdAt", OrderRepository.ToStorage(task.CreatedAt == default ? DateTimeOffset.Now : task.CreatedAt));
        command.Parameters.AddWithValue("$updatedAt", task.UpdatedAt is null ? DBNull.Value : OrderRepository.ToStorage(task.UpdatedAt.Value));

        return Convert.ToInt64(command.ExecuteScalar(), CultureInfo.InvariantCulture);
    }

    public PlateTask? GetByLqeNo(string lqeNo)
    {
        using var connection = _database.OpenConnection();
        using var command = connection.CreateCommand();
        command.CommandText = "SELECT * FROM PlateTasks WHERE LqeNo = $lqeNo LIMIT 1;";
        command.Parameters.AddWithValue("$lqeNo", lqeNo);

        using var reader = command.ExecuteReader();
        return reader.Read() ? Map(reader) : null;
    }

    public IReadOnlyList<PlateTask> ListAll()
    {
        using var connection = _database.OpenConnection();
        using var command = connection.CreateCommand();
        command.CommandText = "SELECT * FROM PlateTasks ORDER BY Id;";

        using var reader = command.ExecuteReader();
        var result = new List<PlateTask>();
        while (reader.Read())
        {
            result.Add(Map(reader));
        }

        return result;
    }

    /// <summary>回写车牌并把状态更新为「已更新」。记录不存在时返回 false。</summary>
    public bool UpdatePlate(string lqeNo, string plateNo)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(plateNo);

        using var connection = _database.OpenConnection();
        using var command = connection.CreateCommand();
        command.CommandText = """
            UPDATE PlateTasks
            SET PlateNo = $plateNo, Status = $status, UpdatedAt = $updatedAt
            WHERE LqeNo = $lqeNo;
            """;
        command.Parameters.AddWithValue("$plateNo", plateNo.Trim());
        command.Parameters.AddWithValue("$status", PlateTaskStatus.Updated);
        command.Parameters.AddWithValue("$updatedAt", OrderRepository.ToStorage(DateTimeOffset.Now));
        command.Parameters.AddWithValue("$lqeNo", lqeNo);

        return command.ExecuteNonQuery() > 0;
    }

    private static PlateTask Map(SqliteDataReader reader) => new()
    {
        Id = reader.GetInt64(reader.GetOrdinal("Id")),
        LqeNo = reader.GetString(reader.GetOrdinal("LqeNo")),
        Destination = reader.GetString(reader.GetOrdinal("Destination")),
        PackageCount = reader.GetInt32(reader.GetOrdinal("PackageCount")),
        WeightKg = (decimal)reader.GetDouble(reader.GetOrdinal("WeightKg")),
        PlateNo = reader.IsDBNull(reader.GetOrdinal("PlateNo")) ? null : reader.GetString(reader.GetOrdinal("PlateNo")),
        Status = reader.GetString(reader.GetOrdinal("Status")),
        CreatedAt = DateTimeOffset.Parse(reader.GetString(reader.GetOrdinal("CreatedAt")), CultureInfo.InvariantCulture),
        UpdatedAt = reader.IsDBNull(reader.GetOrdinal("UpdatedAt"))
            ? null
            : DateTimeOffset.Parse(reader.GetString(reader.GetOrdinal("UpdatedAt")), CultureInfo.InvariantCulture),
    };
}

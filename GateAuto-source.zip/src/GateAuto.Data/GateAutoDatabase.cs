using Microsoft.Data.Sqlite;

namespace GateAuto.Data;

/// <summary>SQLite 数据库入口：负责建立连接、初始化表结构。</summary>
public sealed class GateAutoDatabase
{
    private const string Schema = """
        CREATE TABLE IF NOT EXISTS Orders (
            Id          INTEGER PRIMARY KEY AUTOINCREMENT,
            Platform    TEXT NOT NULL DEFAULT '關務物流',
            ApplyNo     TEXT NOT NULL,
            SourceNo    TEXT NOT NULL,
            ExitType    TEXT NOT NULL DEFAULT '',
            CargoType   TEXT NOT NULL DEFAULT '',
            VendorCode  TEXT NOT NULL DEFAULT '',
            LqeNo       TEXT NULL,
            PlateNo     TEXT NULL,
            Status      TEXT NOT NULL DEFAULT '待建單',
            CreatedAt   TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS PlateTasks (
            Id           INTEGER PRIMARY KEY AUTOINCREMENT,
            LqeNo        TEXT NOT NULL UNIQUE,
            Destination  TEXT NOT NULL DEFAULT '',
            PackageCount INTEGER NOT NULL DEFAULT 0,
            WeightKg     REAL NOT NULL DEFAULT 0,
            PlateNo      TEXT NULL,
            Status       TEXT NOT NULL DEFAULT '待派車',
            CreatedAt    TEXT NOT NULL,
            UpdatedAt    TEXT NULL
        );

        CREATE INDEX IF NOT EXISTS IX_PlateTasks_Status ON PlateTasks (Status);
        """;

    public GateAutoDatabase(string databasePath)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(databasePath);

        DatabasePath = Path.GetFullPath(databasePath);
        ConnectionString = new SqliteConnectionStringBuilder
        {
            DataSource = DatabasePath,
            ForeignKeys = true,
        }.ToString();
    }

    public string DatabasePath { get; }

    public string ConnectionString { get; }

    public SqliteConnection OpenConnection()
    {
        var connection = new SqliteConnection(ConnectionString);
        connection.Open();
        return connection;
    }

    /// <summary>建立数据库文件与表结构，可重复调用。</summary>
    public void Initialize()
    {
        var directory = Path.GetDirectoryName(DatabasePath);
        if (!string.IsNullOrEmpty(directory))
        {
            Directory.CreateDirectory(directory);
        }

        using var connection = OpenConnection();
        using var command = connection.CreateCommand();
        command.CommandText = Schema;
        command.ExecuteNonQuery();

        EnsurePlatformColumn(connection);
    }

    /// <summary>
    /// 旧库升级：Orders 表补充 Platform 列，并把唯一键从「申请编号」改为「平台 + 申请编号」，
    /// 让两个平台中编号相同的订单互不覆盖。
    /// </summary>
    private static void EnsurePlatformColumn(SqliteConnection connection)
    {
        if (!HasColumn(connection, "Orders", "Platform"))
        {
            using var alter = connection.CreateCommand();
            alter.CommandText = "ALTER TABLE Orders ADD COLUMN Platform TEXT NOT NULL DEFAULT '關務物流';";
            alter.ExecuteNonQuery();
        }

        using var index = connection.CreateCommand();
        index.CommandText = """
            DROP INDEX IF EXISTS IX_Orders_ApplyNo;
            CREATE UNIQUE INDEX IF NOT EXISTS IX_Orders_Platform_ApplyNo ON Orders (Platform, ApplyNo);
            """;
        index.ExecuteNonQuery();
    }

    private static bool HasColumn(SqliteConnection connection, string table, string column)
    {
        using var command = connection.CreateCommand();
        command.CommandText = $"PRAGMA table_info({table});";

        using var reader = command.ExecuteReader();
        while (reader.Read())
        {
            if (string.Equals(reader.GetString(1), column, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }
        }

        return false;
    }
}
